/**
 * 
 */
package com.bt.nga.jsonBean;

/**
 * @author Ajit Pawar
 *
 */
public class AccessDetails {

	 private String NxE1T1Indicator;
	 private String CircuitSpeed;
	 private String delivery_Type;
	 private String SuppliersCircuitID;
	 private String supplier_Name;
	 private String circuit_Id;
	 private String access_Model;
	 private String glob_ckt_Id;
	 private String xDSL_Type;
	 private String x_Down_Bdwidth;
	 private String x_Up_Bdwidht;
	 private String x_NTE_Framing;
	 private String access_Type;
	 private String service_Variant;
	 private String hVPN;
	 private String acc_Tech;
	 private String hVPN_Version;

	public AccessDetails() {
		// TODO Auto-generated constructor stub
	}

	public AccessDetails(String nxE1T1Indicator, String circuitSpeed, String delivery_Type, String suppliersCircuitID,
			String supplier_Name, String circuit_Id, String access_Model, String glob_ckt_Id, String xDSL_Type,
			String x_Down_Bdwidth, String x_Up_Bdwidht, String x_NTE_Framing, String access_Type,
			String service_Variant, String hVPN, String acc_Tech, String hVPN_Version) {
		super();
		NxE1T1Indicator = nxE1T1Indicator;
		CircuitSpeed = circuitSpeed;
		this.delivery_Type = delivery_Type;
		SuppliersCircuitID = suppliersCircuitID;
		this.supplier_Name = supplier_Name;
		this.circuit_Id = circuit_Id;
		this.access_Model = access_Model;
		this.glob_ckt_Id = glob_ckt_Id;
		this.xDSL_Type = xDSL_Type;
		this.x_Down_Bdwidth = x_Down_Bdwidth;
		this.x_Up_Bdwidht = x_Up_Bdwidht;
		this.x_NTE_Framing = x_NTE_Framing;
		this.access_Type = access_Type;
		this.service_Variant = service_Variant;
		this.hVPN = hVPN;
		this.acc_Tech = acc_Tech;
		this.hVPN_Version = hVPN_Version;
	}

	public String getNxE1T1Indicator() {
		return NxE1T1Indicator;
	}

	public void setNxE1T1Indicator(String nxE1T1Indicator) {
		NxE1T1Indicator = nxE1T1Indicator;
	}

	public String getCircuitSpeed() {
		return CircuitSpeed;
	}

	public void setCircuitSpeed(String circuitSpeed) {
		CircuitSpeed = circuitSpeed;
	}

	public String getDelivery_Type() {
		return delivery_Type;
	}

	public void setDelivery_Type(String delivery_Type) {
		this.delivery_Type = delivery_Type;
	}

	public String getSuppliersCircuitID() {
		return SuppliersCircuitID;
	}

	public void setSuppliersCircuitID(String suppliersCircuitID) {
		SuppliersCircuitID = suppliersCircuitID;
	}

	public String getSupplier_Name() {
		return supplier_Name;
	}

	public void setSupplier_Name(String supplier_Name) {
		this.supplier_Name = supplier_Name;
	}

	public String getCircuit_Id() {
		return circuit_Id;
	}

	public void setCircuit_Id(String circuit_Id) {
		this.circuit_Id = circuit_Id;
	}

	public String getAccess_Model() {
		return access_Model;
	}

	public void setAccess_Model(String access_Model) {
		this.access_Model = access_Model;
	}

	public String getGlob_ckt_Id() {
		return glob_ckt_Id;
	}

	public void setGlob_ckt_Id(String glob_ckt_Id) {
		this.glob_ckt_Id = glob_ckt_Id;
	}

	public String getxDSL_Type() {
		return xDSL_Type;
	}

	public void setxDSL_Type(String xDSL_Type) {
		this.xDSL_Type = xDSL_Type;
	}

	public String getX_Down_Bdwidth() {
		return x_Down_Bdwidth;
	}

	public void setX_Down_Bdwidth(String x_Down_Bdwidth) {
		this.x_Down_Bdwidth = x_Down_Bdwidth;
	}

	public String getX_Up_Bdwidht() {
		return x_Up_Bdwidht;
	}

	public void setX_Up_Bdwidht(String x_Up_Bdwidht) {
		this.x_Up_Bdwidht = x_Up_Bdwidht;
	}

	public String getX_NTE_Framing() {
		return x_NTE_Framing;
	}

	public void setX_NTE_Framing(String x_NTE_Framing) {
		this.x_NTE_Framing = x_NTE_Framing;
	}

	public String getAccess_Type() {
		return access_Type;
	}

	public void setAccess_Type(String access_Type) {
		this.access_Type = access_Type;
	}

	public String getService_Variant() {
		return service_Variant;
	}

	public void setService_Variant(String service_Variant) {
		this.service_Variant = service_Variant;
	}

	public String gethVPN() {
		return hVPN;
	}

	public void sethVPN(String hVPN) {
		this.hVPN = hVPN;
	}

	public String getAcc_Tech() {
		return acc_Tech;
	}

	public void setAcc_Tech(String acc_Tech) {
		this.acc_Tech = acc_Tech;
	}

	public String gethVPN_Version() {
		return hVPN_Version;
	}

	public void sethVPN_Version(String hVPN_Version) {
		this.hVPN_Version = hVPN_Version;
	}

}
