package com.bt.nga.xmlBean;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="order-form")
public class OrderForm {
	
	    private Properties properties;

	    private Object object;
	    
	    @XmlAttribute
	    private String version="1.3";

	    public Properties getProperties ()
	    {
	        return properties;
	    }

	    public void setProperties (Properties properties)
	    {
	        this.properties = properties;
	    }

	    public Object getObject ()
	    {
	        return object;
	    }

	    public void setObject (Object object)
	    {
	        this.object = object;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [properties = "+properties+", object = "+object+", version = "+version+"]";
	    }
	}
