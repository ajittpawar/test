/**
 * 
 */
package com.bt.nga.dao;

import org.apache.log4j.Logger;

/**
 * @author Sagar Chavan
 * @aim To provide simple DAO strutcure	
 * @created Nov 29, 2016 
 * @modified Nov 29, 2016
 * @modified_by Sagar Chavan
 * @description 
 */
public class SampleDao {

	private final static Logger logger = Logger.getLogger(SampleDao.class);
}
