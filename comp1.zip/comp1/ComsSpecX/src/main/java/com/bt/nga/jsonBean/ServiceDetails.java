/**
 * 
 */
package com.bt.nga.jsonBean;

/**
 * @author Ajit Pawar
 *
 */
public class ServiceDetails {
	private String order_no;
	private String site_id;
	private String service_no;
	private String order_type;
	private String a_end;
	private TechnicalDetails technicalData;
	
	
	
	
	public ServiceDetails(){

	}

	public ServiceDetails(String order_no, String site_id, String service_no, String order_type, String a_end){
		this.order_no = order_no;
		this.site_id = site_id;
		this.service_no = service_no;
		this.order_type = order_type;
		this.a_end = a_end;
	}
	public String getOrder_no() {
		return order_no;
	}
	public void setOrder_no(String order_no) {
		this.order_no = order_no;
	}

	public String getSite_id() {
		return site_id;
	}
	public void setSite_id(String site_id) {
		this.site_id = site_id;
	}

	public String getService_no() {
		return service_no;
	}
	public void setService_no(String service_no) {
		this.service_no = service_no;
	}

	public String getOrder_type() {
		return order_type;
	}
	public void setOrder_type(String order_type) {
		this.order_type = order_type;
	}

	public String getA_end() {
		return a_end;
	}
	public void setA_end(String a_end) {
		this.a_end = a_end;
	}

	/**
	 * @return the technicalData
	 */
	public TechnicalDetails getTechnicalData() {
		return technicalData;
	}

	/**
	 * @param technicalData the technicalData to set
	 */
	public void setTechnicalData(TechnicalDetails technicalData) {
		this.technicalData = technicalData;
	}
}
