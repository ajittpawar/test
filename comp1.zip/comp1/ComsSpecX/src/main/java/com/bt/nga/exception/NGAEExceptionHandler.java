package com.bt.nga.exception;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * @author Sagar Chavan
 * @aim To handle all kind of exception in ComSpec	
 * @created Nov 29, 2016 
 * @modified Nov 29, 2016
 * @modified_by Sagar Chavan
 * @description It provides different error response with respective to exception type
 */


@ControllerAdvice
public class NGAEExceptionHandler extends ResponseEntityExceptionHandler {

	private final static Logger logger = Logger.getLogger(NGAEExceptionHandler.class);
	
	@Autowired private ErrorResponse response;	
	
	
	@ExceptionHandler({ InvalidRequestException.class })
	protected ResponseEntity<Object> handleInvalidRequest(InvalidRequestException e, WebRequest request) {
		
		logger.error("Exception Caught : InvalidRequestException");
		
		response = new ErrorResponse();
		response.setMessage(e.getMessage());
		response.setCode(e.getCode().toString());
		return handleExceptionInternal(e, response,null, HttpStatus.UNPROCESSABLE_ENTITY, request);
	}
	
	
	@ExceptionHandler({ InternalProcessingError.class })
	protected ResponseEntity<Object> handleInternalProcessingError(InternalProcessingError e, WebRequest request) {
		
		logger.error("Exception Caught : InternalProcessingError");
		
		
		response.setMessage(e.getMessage());
		response.setCode(e.getCode());
		return handleExceptionInternal(e, response,null, HttpStatus.UNPROCESSABLE_ENTITY, request);
	}
	
	
	//For all types of exception
	@ExceptionHandler({ Exception.class })
	protected ResponseEntity<Object> handleGenericExceptions(Exception e, WebRequest request) {
		
		logger.error("Exception Caught : InternalProcessingError");
		
		response.setMessage(e.getMessage());
		response.setCode(e.getCause().getMessage());
		return handleExceptionInternal(e, response,null, HttpStatus.INTERNAL_SERVER_ERROR, request);
	}

}