package com.bt.nga.jsonBean;
/**
 * @author Ajit Pawar
 *
 */
public class GeneralDetails {
	
	private String   address;
	private String   post_code;
	private String   city;
	private String   country;
	private String   location;
	private String   phone;
	private String   selling_country;
	private String   cfg_Info;
	private String   email;
	private String   order_mnger;
	private String   order_mnger_phone;
	private String    order_mnger_email;
	private String   project_mnger;
	private String   project_mnger_email;
	private String   contact1;
	private String   contact1_phone;
	private String   contact1_mobile;
	private String   contact1_email;
	private String   contact2;
	private String   contact2_phone;
	private String   contact2_mobile;
	private String   contact2_email;
	private String   region;
	private String    team;
	private String   state;
	private String   nonClasscOrdNo;
	private String   designCode;
	private String   serviceObjId;
	private String    classicOrderTitle;
	private String   mgmtType;

	
	public GeneralDetails(String address, String post_code, String city, String country, String location, String phone,
			String selling_country, String cfg_Info, String email, String order_mnger, String order_mnger_phone,
			String order_mnger_email, String project_mnger, String project_mnger_email, String contact1,
			String contact1_phone, String contact1_mobile, String contact1_email, String contact2,
			String contact2_phone, String contact2_mobile, String contact2_email, String region, String team,
			String state, String nonClasscOrdNo, String designCode, String serviceObjId, String classicOrderTitle,
			String mgmtType) {
		super();
		this.address = address;
		this.post_code = post_code;
		this.city = city;
		this.country = country;
		this.location = location;
		this.phone = phone;
		this.selling_country = selling_country;
		this.cfg_Info = cfg_Info;
		this.email = email;
		this.order_mnger = order_mnger;
		this.order_mnger_phone = order_mnger_phone;
		this.order_mnger_email = order_mnger_email;
		this.project_mnger = project_mnger;
		this.project_mnger_email = project_mnger_email;
		this.contact1 = contact1;
		this.contact1_phone = contact1_phone;
		this.contact1_mobile = contact1_mobile;
		this.contact1_email = contact1_email;
		this.contact2 = contact2;
		this.contact2_phone = contact2_phone;
		this.contact2_mobile = contact2_mobile;
		this.contact2_email = contact2_email;
		this.region = region;
		this.team = team;
		this.state = state;
		this.nonClasscOrdNo = nonClasscOrdNo;
		this.designCode = designCode;
		this.serviceObjId = serviceObjId;
		this.classicOrderTitle = classicOrderTitle;
		this.mgmtType = mgmtType;
	}


	public GeneralDetails() {
		// TODO Auto-generated constructor stub
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getPost_code() {
		return post_code;
	}


	public void setPost_code(String post_code) {
		this.post_code = post_code;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getSelling_country() {
		return selling_country;
	}


	public void setSelling_country(String selling_country) {
		this.selling_country = selling_country;
	}


	public String getCfg_Info() {
		return cfg_Info;
	}


	public void setCfg_Info(String cfg_Info) {
		this.cfg_Info = cfg_Info;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getOrder_mnger() {
		return order_mnger;
	}


	public void setOrder_mnger(String order_mnger) {
		this.order_mnger = order_mnger;
	}


	public String getOrder_mnger_phone() {
		return order_mnger_phone;
	}


	public void setOrder_mnger_phone(String order_mnger_phone) {
		this.order_mnger_phone = order_mnger_phone;
	}


	public String getOrder_mnger_email() {
		return order_mnger_email;
	}


	public void setOrder_mnger_email(String order_mnger_email) {
		this.order_mnger_email = order_mnger_email;
	}


	public String getProject_mnger() {
		return project_mnger;
	}


	public void setProject_mnger(String project_mnger) {
		this.project_mnger = project_mnger;
	}


	public String getProject_mnger_email() {
		return project_mnger_email;
	}


	public void setProject_mnger_email(String project_mnger_email) {
		this.project_mnger_email = project_mnger_email;
	}


	public String getContact1() {
		return contact1;
	}


	public void setContact1(String contact1) {
		this.contact1 = contact1;
	}


	public String getContact1_phone() {
		return contact1_phone;
	}


	public void setContact1_phone(String contact1_phone) {
		this.contact1_phone = contact1_phone;
	}


	public String getContact1_mobile() {
		return contact1_mobile;
	}


	public void setContact1_mobile(String contact1_mobile) {
		this.contact1_mobile = contact1_mobile;
	}


	public String getContact1_email() {
		return contact1_email;
	}


	public void setContact1_email(String contact1_email) {
		this.contact1_email = contact1_email;
	}


	public String getContact2() {
		return contact2;
	}


	public void setContact2(String contact2) {
		this.contact2 = contact2;
	}


	public String getContact2_phone() {
		return contact2_phone;
	}


	public void setContact2_phone(String contact2_phone) {
		this.contact2_phone = contact2_phone;
	}


	public String getContact2_mobile() {
		return contact2_mobile;
	}


	public void setContact2_mobile(String contact2_mobile) {
		this.contact2_mobile = contact2_mobile;
	}


	public String getContact2_email() {
		return contact2_email;
	}


	public void setContact2_email(String contact2_email) {
		this.contact2_email = contact2_email;
	}


	public String getRegion() {
		return region;
	}


	public void setRegion(String region) {
		this.region = region;
	}


	public String getTeam() {
		return team;
	}


	public void setTeam(String team) {
		this.team = team;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getNonClasscOrdNo() {
		return nonClasscOrdNo;
	}


	public void setNonClasscOrdNo(String nonClasscOrdNo) {
		this.nonClasscOrdNo = nonClasscOrdNo;
	}


	public String getDesignCode() {
		return designCode;
	}


	public void setDesignCode(String designCode) {
		this.designCode = designCode;
	}


	public String getServiceObjId() {
		return serviceObjId;
	}


	public void setServiceObjId(String serviceObjId) {
		this.serviceObjId = serviceObjId;
	}


	public String getClassicOrderTitle() {
		return classicOrderTitle;
	}


	public void setClassicOrderTitle(String classicOrderTitle) {
		this.classicOrderTitle = classicOrderTitle;
	}


	public String getMgmtType() {
		return mgmtType;
	}


	public void setMgmtType(String mgmtType) {
		this.mgmtType = mgmtType;
	}

}
