/**
 * 
 */
package com.bt.nga.jsonBean;

/**
 * @author Sagar Chavan
 *
 */
public class ISDNDetails {

	/**
	 * 
	 */
	public ISDNDetails() {
		// TODO Auto-generated constructor stub
	}
	
	private String isdnSwitchType;
	private String   password;
	private String   spid1_1;
	private String   ISDN_Nr_2;
	private String   ISDNInterface_3;
	private String   Spid2_3;
	private String   Spid1_4;
	private String   dialer_IP_HUB;
	private String   dialer;
	private String   localName;
	private String   ISDNInterface_1;
	private String   Spid2_1;
	private String   Spid1_2;
	private String   ISDN_Nr_3;
	private String   ISDNInterface_4;
	private String   Spid2_4;
	private String   dialer_IP_SPOKE;
	private String   loopback20_IP;
	private String   remoteName;
	private String   ISDN_Nr_1;
	private String   ISDNInterface_2;
	private String   Spid2_2;
	private String   Spid1_3;
	private String   ISDN_Nr_4;
	private String   DialerInterface;
	private String   DialerIP_Mask;
	public String getIsdnSwitchType() {
		return isdnSwitchType;
	}
	public void setIsdnSwitchType(String isdnSwitchType) {
		this.isdnSwitchType = isdnSwitchType;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSpid1_1() {
		return spid1_1;
	}
	public void setSpid1_1(String spid1_1) {
		this.spid1_1 = spid1_1;
	}
	public String getISDN_Nr_2() {
		return ISDN_Nr_2;
	}
	public void setISDN_Nr_2(String iSDN_Nr_2) {
		ISDN_Nr_2 = iSDN_Nr_2;
	}
	public String getISDNInterface_3() {
		return ISDNInterface_3;
	}
	public void setISDNInterface_3(String iSDNInterface_3) {
		ISDNInterface_3 = iSDNInterface_3;
	}
	public String getSpid2_3() {
		return Spid2_3;
	}
	public void setSpid2_3(String spid2_3) {
		Spid2_3 = spid2_3;
	}
	public String getSpid1_4() {
		return Spid1_4;
	}
	public void setSpid1_4(String spid1_4) {
		Spid1_4 = spid1_4;
	}
	public String getDialer_IP_HUB() {
		return dialer_IP_HUB;
	}
	public void setDialer_IP_HUB(String dialer_IP_HUB) {
		this.dialer_IP_HUB = dialer_IP_HUB;
	}
	public String getDialer() {
		return dialer;
	}
	public void setDialer(String dialer) {
		this.dialer = dialer;
	}
	public String getLocalName() {
		return localName;
	}
	public void setLocalName(String localName) {
		this.localName = localName;
	}
	public String getISDNInterface_1() {
		return ISDNInterface_1;
	}
	public void setISDNInterface_1(String iSDNInterface_1) {
		ISDNInterface_1 = iSDNInterface_1;
	}
	public String getSpid2_1() {
		return Spid2_1;
	}
	public void setSpid2_1(String spid2_1) {
		Spid2_1 = spid2_1;
	}
	public String getSpid1_2() {
		return Spid1_2;
	}
	public void setSpid1_2(String spid1_2) {
		Spid1_2 = spid1_2;
	}
	public String getISDN_Nr_3() {
		return ISDN_Nr_3;
	}
	public void setISDN_Nr_3(String iSDN_Nr_3) {
		ISDN_Nr_3 = iSDN_Nr_3;
	}
	public String getISDNInterface_4() {
		return ISDNInterface_4;
	}
	public void setISDNInterface_4(String iSDNInterface_4) {
		ISDNInterface_4 = iSDNInterface_4;
	}
	public String getSpid2_4() {
		return Spid2_4;
	}
	public void setSpid2_4(String spid2_4) {
		Spid2_4 = spid2_4;
	}
	public String getDialer_IP_SPOKE() {
		return dialer_IP_SPOKE;
	}
	public void setDialer_IP_SPOKE(String dialer_IP_SPOKE) {
		this.dialer_IP_SPOKE = dialer_IP_SPOKE;
	}
	public String getLoopback20_IP() {
		return loopback20_IP;
	}
	public void setLoopback20_IP(String loopback20_IP) {
		this.loopback20_IP = loopback20_IP;
	}
	public String getRemoteName() {
		return remoteName;
	}
	public void setRemoteName(String remoteName) {
		this.remoteName = remoteName;
	}
	public String getISDN_Nr_1() {
		return ISDN_Nr_1;
	}
	public void setISDN_Nr_1(String iSDN_Nr_1) {
		ISDN_Nr_1 = iSDN_Nr_1;
	}
	public String getISDNInterface_2() {
		return ISDNInterface_2;
	}
	public void setISDNInterface_2(String iSDNInterface_2) {
		ISDNInterface_2 = iSDNInterface_2;
	}
	public String getSpid2_2() {
		return Spid2_2;
	}
	public void setSpid2_2(String spid2_2) {
		Spid2_2 = spid2_2;
	}
	public String getSpid1_3() {
		return Spid1_3;
	}
	public void setSpid1_3(String spid1_3) {
		Spid1_3 = spid1_3;
	}
	public String getISDN_Nr_4() {
		return ISDN_Nr_4;
	}
	public void setISDN_Nr_4(String iSDN_Nr_4) {
		ISDN_Nr_4 = iSDN_Nr_4;
	}
	public String getDialerInterface() {
		return DialerInterface;
	}
	public void setDialerInterface(String dialerInterface) {
		DialerInterface = dialerInterface;
	}
	public String getDialerIP_Mask() {
		return DialerIP_Mask;
	}
	public void setDialerIP_Mask(String dialerIP_Mask) {
		DialerIP_Mask = dialerIP_Mask;
	}


}
