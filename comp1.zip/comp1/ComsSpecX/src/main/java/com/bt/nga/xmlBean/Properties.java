package com.bt.nga.xmlBean;

import javax.xml.bind.annotation.XmlAttribute;

public class Properties
{
	@XmlAttribute(name="type-id")
    public String typeId="string";

	@Override
    public String toString()
    {
        return "ClassPojo [type-id = "+typeId+"]";
    }
}