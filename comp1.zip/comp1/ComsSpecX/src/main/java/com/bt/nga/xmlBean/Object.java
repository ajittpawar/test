package com.bt.nga.xmlBean;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Object
{
    private Operation operation;

    private String name="";

    @XmlAttribute(name="type-id")
    public String typeId="urn:bt/ece:dslhooks";

    private Attribute[] attribute;

    private Collection[] collection;
    
    public Operation getOperation ()
    {
        return operation;
    }

    public void setOperation (Operation operation)
    {
        this.operation = operation;
    }

    public String getName ()
    {
        return name;
    }
    @XmlAttribute
    public void setName (String name)
    {
        this.name = name;
    }
    
	public Attribute[] getAttribute ()
    {
        return attribute;
    }

    public void setAttribute (Attribute[] attribute)
    {
        this.attribute = attribute;
    }

    public Collection[] getCollection ()
    {
        return collection;
    }

    public void setCollection (Collection[] collection)
    {
        this.collection = collection;
    }
    
    @Override
    public String toString()
    {
        return "ClassPojo [operation = "+operation+", name = "+name+", type-id = "+typeId+", attribute = "+attribute+"]";
    }
}
