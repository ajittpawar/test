package com.bt.nga.dao;



import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.bt.nga.entity.serviceno.TechDetails;
import com.bt.nga.util.hibernate.HibernateUtil;



/**
 * TechDetails DAO
 * @author 611221504
 *
 */
@Repository("techDetailsDAO")
@EnableTransactionManagement
@Transactional
public class TechDetailsDAO {
	
	private final static Logger logger = Logger.getLogger(TechDetailsDAO.class);

	@Autowired
	private HibernateUtil serviceDAO;

	
	
	/**
	 * To get the lost of TechDetails
	 * @return TechDetails
	 */
	@SuppressWarnings("unchecked")
	@ExceptionHandler
	public List<TechDetails> listTechDetails() {
		logger.info("In ListTechDetails method");
		Session session = serviceDAO.getSessionFactory().getCurrentSession();
		logger.debug("Session Object is:"+session);
		List<TechDetails> techDetailsList=session.createCriteria(TechDetails.class).list();

		return techDetailsList;
	}

	public void addTechDetails(TechDetails techDetails) {
		Session session = serviceDAO.getSessionFactory().getCurrentSession();
		session.persist(techDetails);
		logger.info("TechDetails saved successfully, TechDetails Details="+techDetails);
	}

	
	public TechDetails getTechDetailsID(int id) {
		Session session = serviceDAO.getSessionFactory().getCurrentSession();
		TechDetails p = (TechDetails) session.load(TechDetails.class, new Integer(id));
		logger.info("TechDetails loaded successfully, TechDetails details="+p);
		return p;
	}

	public void removeTechDetails(int id) {
		Session session = serviceDAO.getSessionFactory().getCurrentSession();
		TechDetails p = (TechDetails) session.load(TechDetails.class, new Integer(id));
		if(null != p){
			session.delete(p);
		}
		logger.info("TechDetails deleted successfully, TechDetails details="+p);
	}

	public HibernateUtil getServiceDAO() {
		return serviceDAO;
	}

	public void setServiceDAO(HibernateUtil serviceDAO) {
		this.serviceDAO = serviceDAO;
	}

}
