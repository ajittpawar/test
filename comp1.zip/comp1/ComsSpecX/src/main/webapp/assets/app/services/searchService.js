
(function(){
    
    comspecApp.factory('searchService', ['$http', function($http) {
    	var resultData = {};
        return {
			searchOrder:function (search){
            return $http.get('OrderDetails?orderId='+search.orderId+'&customerText='+search.customerText);
			},
			setResult: function(data){
				resultData = data;
			},
			getResult: function(){
				return resultData;
			},
			getOrderDetails:function (search){
				return $http.get('assets/json/ordersearch.json');
			},
			getSeacrhVisibility:function (search){
				return $http.get('assets/json/ordersearchvisibility.json');
			},
			saveSeacrhGeneral:function (data){
				return $http.post('assets/json/ordersearchvisibility.json', data);
			}
        };
    } ]);
    
})();