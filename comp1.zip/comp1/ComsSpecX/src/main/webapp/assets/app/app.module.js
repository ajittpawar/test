

	/*angular.element(document).ready(function() {
		angular.bootstrap(document.getElementById('entryPoint'), [ 'comspecApp' ]);
	});*/
