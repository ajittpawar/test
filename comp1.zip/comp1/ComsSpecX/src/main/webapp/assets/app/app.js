
var comspecApp = angular.module('ComspecApp', [ "ui.router", "ui.bootstrap", "angularSpinner","ngAnimate", "ngStorage", "toastr" ]);

comspecApp.config(function($stateProvider, $urlRouterProvider) {
	// For any unmatched url, redirect to /state1
	$urlRouterProvider.otherwise("/search");
	// Now set up the states
	$stateProvider
	.state('login', {
		authenticate : false,
		url : "/login",
		templateUrl : "assets/app/views/login/login.html",
		controller : 'loginCtrl'
	})
	.state('logout',{
		authenticate : false,
		url : '/logout',
		controller : ["$state","loginService",function($state,loginService) {
			if (loginService
					.logout()) {
				$state.go('login');
			}
		} ]
	})
	.state('search',{											
		url : "/search",
		templateUrl : "assets/app/views/search/search.html",
		controller : 'searchCtrl'
	})
	.state('searchResult',{
		url : "/searchResult",
		templateUrl : "assets/app/views/search-result/search-result.html",
		controller : 'searchResultCtrl'
	})
	.state('searchProcess',{
		url : "/searchProcess",
		templateUrl : "assets/app/views/search-process/search-process.html",
		controller : 'searchProcessCtrl'
	})
	.state('home.SearchByFlowID',{
		authenticate : true,
		url : "/SearchByFlowID",
		templateUrl : "assets/app/views/flowid/searchByFlowId.html",
		controller : 'searchByFlowIdCtrl'
	})
	.state('home.SearchByErrorCode',{
		authenticate : true,
		url : "/SearchByErrorCode",
		templateUrl : "assets/app/views/errorcode/searchByError.html",
		controller : 'searchByErrorCtrl'
	})
	.state('home.SearchByBulkFeed',{
		authenticate : true,
		url : "/SearchByBulkFeed",
		templateUrl : "assets/app/views/bulkfield/searchByBulkFeed.html",
		controller : 'searchByBulkFeedCtrl'
	});

});
