/**
 * Search Controller
 */

(function () {

	comspecApp.controller('searchCtrl', ['$scope', 'searchService', '$state', '$filter', 'toastr', '$window', function($scope, searchService, $state, $filter, toastr, $window){
		$scope.loading = false;
		$scope.search = {};

		$scope.searchFn = function () {
			searchService.searchOrder($scope.search).then(function (response) {
				$scope.loading = false;
				$scope.searchResponse = response.data;
				searchService.setResult(response.data);
				$state.go('searchResult');
			}, function(error) {
				$scope.loading = false;
				toastr.error('Error :' + response.data.message);
				console.log(error);
			});
		}

	}]);

})();