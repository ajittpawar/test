
(function () {

	comspecApp.controller('searchProcessCtrl', ['$scope', 'searchService', '$state', function($scope, searchService, $state){

		$scope.mainTabs = {TECHNICAL:1, DOCUMENTATION:2, OVERVIEW:3, CUSTOMER:4, HISTORY:5, BASIC:6};
		$scope.subTabs = {GENERAL:1, PE:2, ACCESS:3, CPE:4, COS:5, ISDN:6, CUSTOMER:7, NONS:8, REPORTING:9, CWAN:10, FINANCE:11, FRF:12};

		$scope.activeMainTab = $scope.mainTabs.TECHNICAL; //Set default tab
		$scope.activeSubTab = $scope.subTabs.GENERAL; //Set default sub tab

		function loadSearchProcessServices() {
			searchService.getSeacrhVisibility({}).then(function (response) {
				$scope.searchVisibility = response.data.technicalData;
			},function(error) {

			});

			searchService.getOrderDetails({}).then(function (response) {
				$scope.searchProcess = response.data.technicalData;
			},function(error) {

			});
		}

		loadSearchProcessServices();

		$scope.setActiveMainTab = function(tabName) {
			$scope.activeMainTab = tabName;
		};

		$scope.setActiveSubTab = function(tabName) {
			$scope.activeSubTab = tabName;
		};

	}]);

})();

