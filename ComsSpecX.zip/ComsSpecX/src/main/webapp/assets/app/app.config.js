/**
 * 
 */

(function() {
	comspecApp.config(function(toastrConfig) {
		angular.extend(toastrConfig, {
			closeButton : true,
			progressBar : true
		});
	});
	
	/*toastr.options = {
			  "closeButton": false,
			  "debug": false,
			  "newestOnTop": false,
			  "progressBar": false,
			  "positionClass": "toast-top-center",
			  "preventDuplicates": false,
			  "onclick": null,
			  "showDuration": "300",
			  "hideDuration": "1000",
			  "timeOut": "5000",
			  "extendedTimeOut": "1000",
			  "showEasing": "swing",
			  "hideEasing": "linear",
			  "showMethod": "fadeIn",
			  "hideMethod": "fadeOut"
			}*/
	
	comspecApp.run(function ($rootScope, $state, loginService) {
	    $rootScope.$on('$stateChangeStart',
	            function (event, toState, toParams, fromState, fromParams) {
	                if (toState.authenticate && !loginService.isLogedin()) {
	                    $state.go('login');
	                    event.preventDefault();
	                    // transitionTo() promise will be rejected with 
	                    // a 'transition prevented' error
	                }
	            });
	});
	
})();