
(function(){
    
    comspecApp.factory('searchService', ['$http', function($http) {
    	var resultData = {};
        return {
			searchOrder:function (search){
                return $http.get('OrderDetails?orderId='+search.orderId+'&customerText='+search.customerText);
			},
			setResult: function(data){
				resultData = data;
			},
			getResult: function(){
				return resultData;
			},
			getOrderDetails:function (data){
				return $http.get('assets/json/ordersearch.json');
				//return $http.get('TechDetails?ServiceID='+data.serviceId);  
			},
			getSeacrhVisibility:function (data){
				return $http.get('assets/json/ordersearchvisibility.json');
				//return $http.get('feildDetails?ServiceID='+data.serviceId);
			},
			saveTechnicalGeneral:function (data){
				return $http.post('assets/json/ordersearchvisibility.json', data);
				//return $http.post('GeneralInfo/'+data.serviceId, data);
			},
			savePass1Configuration:function (data){
				return $http.post('assets/json/ordersearchvisibility.json', data);
				//return $http.post('CreateBaseConfig', data);
			}
        };
    } ]);
    
})();