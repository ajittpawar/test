
(function () {

	comspecApp.controller('technicalTabCtrl', ['$scope', 'searchService', '$state','toastr','$timeout', function($scope, searchService, $state, toastr, $timeout){

		function loadSearchProcessServices() {
			searchService.getSeacrhVisibility({}).then(function (response) {
				$scope.searchVisibility = response.data.technicalData;
			},function(error) {

			});
			$scope.getProcessDetails(true);
		}

		$scope.getProcessDetails = function(primaryDetails) {
			searchService.getOrderDetails({}).then(function (response) {
				$scope.searchProcess = response.data.technicalData;
			},function(error) {

			});
		};

		loadSearchProcessServices();
		
		$scope.setActiveSubTab = function(tabName) {
			$scope.activeSubTab = tabName;
		};

		$scope.setActiveTechnicalTab = function(tabName) {
			$scope.activeTechnicalTab = tabName;
		};

		$scope.saveGeneralInfo = function() {
			var data = {general_Info: $scope.searchProcess.general_info};
			searchService.saveTechnicalGeneral(data).then(function (response) {
				toastr.success('Success :');
			},function(error) {
				toastr.error('Error :');
			});
		};
		
		$scope.downloadConfiguration = function(text) {
			var a = document.createElement("a");
			var file = new Blob([text], {type:"text/plain"});
			a.href = URL.createObjectURL(file);
			a.onclick = destroyClickedElement;
			a.download = "pass1-config.txt";
			a.style.display = "none";
			document.body.appendChild(a);
			a.click();
		}
		
		function destroyClickedElement(event) {
		   document.body.removeChild(event.target);
		}

	}]);

})();

