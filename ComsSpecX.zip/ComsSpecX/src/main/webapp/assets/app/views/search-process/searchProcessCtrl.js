
(function () {

	comspecApp.controller('searchProcessCtrl', ['$scope', 'searchService', '$state', 'toastr', function($scope, searchService, $state, toastr){

		$scope.mainTabs = {TECHNICAL:1, DOCUMENTATION:2, OVERVIEW:3, CUSTOMER:4, HISTORY:5, BASIC:6};
		$scope.subTabs = {GENERAL:1, PE:2, ACCESS:3, CPE:4, COS:5, ISDN:6, CUSTOMER:7, NONS:8, REPORTING:9, CWAN:10, FINANCE:11, FRF:12};
		$scope.technicalTabs = {PRIMARY:1, SECONDARY:2};
		$scope.pass1Config = false;

		$scope.activeMainTab = $scope.mainTabs.TECHNICAL; //Set default tab
		$scope.activeSubTab = $scope.subTabs.GENERAL; //Set default sub tab
		$scope.activeTechnicalTab = $scope.technicalTabs.PRIMARY;

		$scope.setActiveMainTab = function(tabName) {
			$scope.pass1Config = false;
			$scope.activeMainTab = tabName;
		};
		
		$scope.setPass1Configuration = function() {
			searchService.savePass1Configuration($scope.searchProcess).then(function (response) {
				$scope.pass1ConfigText = response;
				$scope.pass1Config = true;
				$("html, body").animate({ scrollTop: 0 }, "slow");
				toastr.success('Success :');
			},function(error) {
				$scope.pass1Config = false;
				toastr.error('Error :');
			});
		};
		
	}]);

})();

