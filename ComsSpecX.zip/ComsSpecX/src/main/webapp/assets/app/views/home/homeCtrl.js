/**
 * Home Controller
 * @returns {undefined}
 */

(function(){

	comspecApp.controller('homeCtrl', ['$scope', 'loginService', function($scope, loginService){
		$scope.userName = loginService.getUserName();
	}]);

})();

