/**
 * 
 */
package com.bt.nga.config.beanFactory;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.bt.nga.service.SampleService;
import com.bt.nga.service.SampleServiceImpl;

/**
 * @author Sagar Chavan
 * @aim 	
 * @created Nov 29, 2016 
 * @modified Nov 29, 2016
 * @modified_by Sagar Chavan
 * @description 
 */

@Configuration
public class ServiceBeanGenerator {
	private final static Logger logger = Logger.getLogger(ServiceBeanGenerator.class);
	
	
	@Bean(name="sampleService")
	@Scope("singleton")
	public SampleService sampleService(){
		 logger.debug("Generating SampleService bean ");
			SampleService sampleService = new SampleServiceImpl();
			sampleService.setServiceName("Test Service");
			return sampleService;
	}
}
