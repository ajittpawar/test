/**
 * 
 */
package com.bt.nga.jsonBean;

/**
 * @author Ajit Pawar
 *
 */
public class CPEDetails {

	 private String bgp_AS;
	 private String asset_Tag;
	 private String cpe_Id;
	 private String service_Type;
	 private String mngd_Device;
	 private String mgmt_IP;
	 private String wan_Card;
	 private String router_Type;
	 private String iOS;
	 private String hostname;
	 private String OoB_Mngmt_Nr;
	 private String monitoring_Sys;
	 private String iPv6_Mgmt_IP;
	 private String hostname_Extn;
	 private String serviceTest_Date;
	 private String onsiteTest_Date;

	public CPEDetails() {
		// TODO Auto-generated constructor stub
	}

	public CPEDetails(String bgp_AS, String asset_Tag, String cpe_Id, String service_Type, String mngd_Device,
			String mgmt_IP, String wan_Card, String router_Type, String iOS, String hostname, String ooB_Mngmt_Nr,
			String monitoring_Sys, String iPv6_Mgmt_IP_mnger, String hostname_Extn, String serviceTest_Date,
			String onsiteTest_Date) {
		super();
		this.bgp_AS = bgp_AS;
		this.asset_Tag = asset_Tag;
		this.cpe_Id = cpe_Id;
		this.service_Type = service_Type;
		this.mngd_Device = mngd_Device;
		this.mgmt_IP = mgmt_IP;
		this.wan_Card = wan_Card;
		this.router_Type = router_Type;
		this.iOS = iOS;
		this.hostname = hostname;
		OoB_Mngmt_Nr = ooB_Mngmt_Nr;
		this.monitoring_Sys = monitoring_Sys;
		this.iPv6_Mgmt_IP = iPv6_Mgmt_IP_mnger;
		this.hostname_Extn = hostname_Extn;
		this.serviceTest_Date = serviceTest_Date;
		this.onsiteTest_Date = onsiteTest_Date;
	}

	public String getBgp_AS() {
		return bgp_AS;
	}

	public void setBgp_AS(String bgp_AS) {
		this.bgp_AS = bgp_AS; 
	}

	public String getAsset_Tag() {
		return asset_Tag;
	}

	public void setAsset_Tag(String asset_Tag) {
		this.asset_Tag = asset_Tag;
	}

	public String getCpe_Id() {
		return cpe_Id;
	}

	public void setCpe_Id(String cpe_Id) {
		this.cpe_Id = cpe_Id;
	}

	public String getService_Type() {
		return service_Type;
	}

	public void setService_Type(String service_Type) {
		this.service_Type = service_Type;
	}

	public String getMngd_Device() {
		return mngd_Device;
	}

	public void setMngd_Device(String mngd_Device) {
		this.mngd_Device = mngd_Device;
	}

	public String getMgmt_IP() {
		return mgmt_IP;
	}

	public void setMgmt_IP(String mgmt_IP) {
		this.mgmt_IP = mgmt_IP;
	}

	public String getWan_Card() {
		return wan_Card;
	}

	public void setWan_Card(String wan_Card) {
		this.wan_Card = wan_Card;
	}

	public String getRouter_Type() {
		return router_Type;
	}

	public void setRouter_Type(String router_Type) {
		this.router_Type = router_Type;
	}

	public String getiOS() {
		return iOS;
	}

	public void setiOS(String iOS) {
		this.iOS = iOS;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public String getOoB_Mngmt_Nr() {
		return OoB_Mngmt_Nr;
	}

	public void setOoB_Mngmt_Nr(String ooB_Mngmt_Nr) {
		OoB_Mngmt_Nr = ooB_Mngmt_Nr;
	}

	public String getMonitoring_Sys() {
		return monitoring_Sys;
	}

	public void setMonitoring_Sys(String monitoring_Sys) {
		this.monitoring_Sys = monitoring_Sys;
	}

	public String getiPv6_Mgmt_IP() {
		return iPv6_Mgmt_IP;
	}

	public void setiPv6_Mgmt_IP(String iPv6_Mgmt_IP) {
		this.iPv6_Mgmt_IP = iPv6_Mgmt_IP;
	}

	public String getHostname_Extn() {
		return hostname_Extn;
	}

	public void setHostname_Extn(String hostname_Extn) {
		this.hostname_Extn = hostname_Extn;
	}

	public String getServiceTest_Date() {
		return serviceTest_Date;
	}

	public void setServiceTest_Date(String serviceTest_Date) {
		this.serviceTest_Date = serviceTest_Date;
	}

	public String getOnsiteTest_Date() {
		return onsiteTest_Date;
	}

	public void setOnsiteTest_Date(String onsiteTest_Date) {
		this.onsiteTest_Date = onsiteTest_Date;
	}

}
