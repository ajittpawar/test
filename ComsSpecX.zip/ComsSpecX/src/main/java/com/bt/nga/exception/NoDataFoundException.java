package com.bt.nga.exception;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * @author Sagar Chavan
 * @aim To generate error response if exception occurs	
 * @created Nov 30, 2016 
 * @modified Nov 30, 2016
 * @modified_by Sagar Chavan
 * @description This exception should be thrown if we don't find data for particular request
 */


@Component
@Scope("prototype")
public class NoDataFoundException extends RuntimeException {
    /**
	 * 
	 */
	private static final long serialVersionUID = -5004829409647983053L;
	private String msg;
    private String code;


	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public NoDataFoundException(String message, String code) {
		super(message);
		this.code=code;
        this.msg=message;
    	
         
    }

   
}