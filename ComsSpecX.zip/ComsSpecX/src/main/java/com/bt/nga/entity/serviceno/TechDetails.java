package com.bt.nga.entity.serviceno;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="TECH_DETAILS")
public class TechDetails {

		@Id
		@Column(name="id")
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		private int id;
		
		
		@Column(name="PROD_CUST_ID")
		private String prod_cust_id;

		

		@Column(name="PROD_CUST_NAME")
		private String prod_cust_name;
		
		

		@Column(name="ORDER_SITE_ID")
		private String order_site_id;

		@Column(name="CLASSIC_ORDER_NO")
		private String classic_order_no;

		@Column(name="CLASSIC_ORDER_TYPE")
		private String classic_order_type;

		@Column(name="CLASSIC_ORDER_CREATE_DATE")
		private String classic_order_create_date;

		@Column(name="SITE_ADDRESS")
		private String site_address;

		@Column(name="SITE_POSTAL_CODE")
		private String site_postal_code;
		
		@Column(name="SITE_CITY")
		private String site_city;

		@Column(name="SITE_COUNTRY")
		private String site_country;

				
		@Column(name="SERVICE_NO")
		private String service_no;
		
		@Column(name="SiteName")
		private String sitename;
		
		@Column(name="ConfigurationSpecialistPhoneNr")
		private String configurationSpecialistPhoneNr;
		
		@Column(name="PuneConfigurationSpecialist")
		private String puneConfigurationSpecialist;
		
		@Column(name="PuneConfigSpecialistPhNr")
		private String puneConfigSpecialistPhNr;
		
		@Column(name="PuneConfigSpecialistEmail")
		private String puneConfigSpecialistEmail;
		
		@Column(name="SellingCountry")
		private String sellingCountry;
		
		@Column(name="Configuration_Specialist")
		private String configuration_specialist;
		
		
		@Column(name="Configuration_SpecialistEmail")
		private String configuration_specialistEmail;

		@Column(name="OrderManager")
		private String orderManager;
		
		@Column(name="OrderManagerPhoneNr")
		private String orderManagerPhoneNr;
		
		@Column(name="OrderManagerEmail")
		private String orderManagerEmail;
		
		@Column(name="ProjectManager")
		private String projectManager;
		
		@Column(name="ProjectManagerEmail")
		private String projectManagerEmail;
		
		@Column(name="AccountManager")
		private String accountManager;
		
		@Column(name="1_CustomerName")
		private String customerName_1;
		
		@Column(name="1_Phone_Nr_")
		private String phone_Nr_1;
		
		
		@Column(name="1_CelularPhone_Nr_")
		private String celularPhone_Nr_1;
		
		@Column(name="1_Email")
		private String email_1;
		
		@Column(name="2_CustomerName")
		private String customerName_2;
		
		@Column(name="2_Phone_Nr")
		private String phone_Nr_2;
		
		
		@Column(name="2_CelularPhone_Nr")
		private String celularPhone_Nr_2;
		
		@Column(name="2_Email")
		private String email_2;
	
		@Column(name="APOPNodeAddress")
		private String apop_node_address;
		
		@Column(name="IPClearAccPELoopbackAddress")
		private String ip_clearAccPELoopbackAddress;
		
		@Column(name="InterfaceDescriptor")
		private String interfaceDescriptor;
		
		@Column(name="KLMNumber")
		private String klm_number;
		
		@Column(name="No_oftimeslotsrequired")
		private String no_oftimeslotsrequired;
		
		@Column(name="NodeId")
		private String nodeId;
		
		@Column(name="PEColour")
		private String pe_colour;
		
		@Column(name="PEInterfaceIPAddress")
		private String pe_interfaceIPAddress;

		@Column(name="PERouterType")
		private String perouterType;

		@Column(name="PhysicalInterface")
		private String physicalInterface;

		@Column(name="PortAllocation")
		private String portAllocation;

		@Column(name="PortDeliveryType")
		private String portDeliveryType;

		@Column(name="PortHWType")
		private String portHWType;
		
		@Column(name="PortNo")
		private String portNo;
		
		@Column(name="PortType")
		private String portType;
		
		@Column(name="Resilienttype")
		private String resilienttype;
		
		@Column(name="SlotNo_")
		private String slotNo;
		
		@Column(name="Speed_Fullportspeed")
		private String speed_Fullportspeed;
		
		@Column(name="Sub_interfaceID")
		private String sub_interfaceID;
		
		@Column(name="Sub_rateSpeed")
		private String sub_rateSpeed;
		
		@Column(name="FRF_16ID")
		private String frf_16id;
		
		@Column(name="FRF_16Node")
		private String frf_16node;
		
		@Column(name="FRF_16Port")
		private String frf_16port;
		
		@Column(name="FRF_16Slot")
		private String frf_16slot;

		@Column(name="FRF_16SubratePortSpeed")
		private String frf_16subratePortSpeed;

		@Column(name="PortsinFRF_16")
		private String portsinFRF_16;

		@Column(name="CustomerVPNIndex")
		private String customerVPNIndex;

		@Column(name="Primary_Secondary")
		private String primary_Secondary;

		@Column(name="Resilience")
		private String resilience;

		@Column(name="RoutingType")
		private String routingType;

		@Column(name="TotalInformationRate_kbps")
		private String totalInformationRate_kbps;

		@Column(name="VPNConnectionName")
		private String vpn_ConnectionName;

		@Column(name="NxE1T1Indicator")
		private String nxE1T1Indicator;

		@Column(name="PE_Loopback200_IP")
		private String pe_loopback200_IP;

		@Column(name="VPNName")
		private String vpnName;

		@Column(name="AccBeaCircNTEFram_Str_CustEnd")
		private String accBeaCircNTEFram_Str_CustEnd;

		@Column(name="AccBearCctNTEFram_Str_POPEnd")
		private String accBearCctNTEFram_Str_POPEnd;

		@Column(name="acBeCiNTEOp_ElctrIntTyp_CuEnd")
		private String acBeCiNTEOp_ElctrIntTyp_CuEnd;

		@Column(name="AccBeaCircNTEPhyConn_CustEnd")
		private String accBeaCircNTEPhyConn_CustEnd;

		@Column(name="AccessBearerCircuitSpeed")
		private String accessBearerCircuitSpeed;

		@Column(name="AccCircResilience_DiversityTyp")
		private String accCircResilience_DiversityTyp;

		@Column(name="AccessDeliveryType")
		private String accessDeliveryType;

		@Column(name="AcPOP_NodCh_Trib_Timslt_KLMdet")
		private String acPOP_NodCh_Trib_Timslt_KLMdet;

		@Column(name="AccessSuppliersCircuitID")
		private String accessSuppliersCircuitID;

		@Column(name="AccessSuppliersName_TelcoName")
		private String accessSuppliersName_TelcoName;

		@Column(name="AccessSuppliersQuoteReference")
		private String accessSuppliersQuoteReference;

		@Column(name="ChannalisedCircuitID")
		private String channalisedCircuitID;

		@Column(name="CircuitServiceID")
		private String circuitServiceID;

		@Column(name="ChannelGroup")
		private String channelGroup;

		@Column(name="Channelised")
		private String channelised;

		@Column(name="AutonomousSystem_ASNumber")
		private String autonomousSystem_ASNumber;

		@Column(name="ActualInstallationDate")
		private String actualInstallationDate;

		@Column(name="AssetTagNo_")
		private String AssetTagNo_;

		@Column(name="CALL_OFF_AGENT_NAME")
		private String call_off_agent_name;

		@Column(name="CPEID")
		private String cpeid;

		@Column(name="CPEUsage")
		private String cpeUsage;

		@Column(name="Installer")
		private String installer;

		@Column(name="LocalSupplierName")
		private String localSupplierName;

		@Column(name="Maintainer")
		private String maintainer;

		@Column(name="ManagedDeviceName")
		private String managedDeviceName;

		@Column(name="Management_LoopbackIPAddress")
		private String management_LoopbackIPAddress;

		@Column(name="CPECARD_PartDescription")
		private String cpeCard_partDescription;

		@Column(name="CPEFIRMWARE_PartDescription")
		private String cpe_firmware_partDescription;

		@Column(name="CPE_PartDescription")
		private String cpe_partDescription;

		@Column(name="CPEFirmware_Type")
		private String cpeFirmware_Type;

		@Column(name="CPESoftware_PartDescription")
		private String cpe_software_PartDescription;

		@Column(name="Speed_Fullportspeed_2")
		private String speed_fullportspeed_2;

		@Column(name="WANInterfaceType")
		private String wan_interfaceType;

		@Column(name="WANInterfacePort")
		private String wan_interfacePort;
		
		@Column(name="WANInterfaceDLCI")
		private String wan_interfaceDLCI;

		
		@Column(name="WANInterfaceIP")
		private String wan_interfaceIP;

		@Column(name="WANInterfaceMask")
		private String wan_interfaceMask;

		@Column(name="WANIPNext_Hop")
		private String wan_iPNext_Hop;

		@Column(name="IPSecHubIP")
		private String ip_secHubIP;

		@Column(name="IPSecSpokeIP")
		private String ip_secSpokeIP;

		@Column(name="IPSecPre_SharedKey")
		private String ip_secPre_SharedKey;

		@Column(name="Final_Host_Name")
		private String final_Host_Name;

		@Column(name="PEP2PIP")
		private String pep2pip;

		@Column(name="CEP2PIP")
		private String cep2pip;

		@Column(name="BGP_Network_statement_1")
		private String bgp_network_statement_1;

		@Column(name="BGP_Mask_statement_1")
		private String bgp_mask_statement_1;

		@Column(name="AFEffectivePlanningBandwidth")
		private String afeffectivePlanningBandwidth;

		@Column(name="ClassAF1CIPR")
		private String classAF1CIPR;

		@Column(name="ClassAF1MIPR")
		private String classAF1MIPR;

		@Column(name="ClassAF2CIPR")
		private String classAF2CIPR;

		@Column(name="ClassAF2MIPR")
		private String classAF2MIPR;

		@Column(name="ClassAF3CIPR")
		private String classAF3CIPR;

		@Column(name="ClassAF3MIPR")
		private String classAF3MIPR;

		@Column(name="ClassAF4CIPR")
		private String classAF4CIPR;

		@Column(name="ClassAF4MIPR")
		private String classAF4MIPR;

		@Column(name="ClassDEMIPR")
		private String classDEMIPR;

		@Column(name="ClassEFCIPR")
		private String classEFCIPR;

		@Column(name="ClassMGTCIPR")
		private String classMGTCIPR;

		@Column(name="ClassMGTMIPR")
		private String classMGTMIPR;

		@Column(name="CoSModel")
		private String coSModel;

		@Column(name="CoSBleaching")
		private String coSBleaching;

		@Column(name="CoSCustomisationlevel")
		private String coSCustomisationlevel;

		@Column(name="CoSEnabled")
		private String coSEnabled;

		@Column(name="CoSInterworking")
		private String coSInterworking;

		@Column(name="CoSTemplate")
		private String coSTemplate;

		@Column(name="DERemarking")
		private String deRemarking;

		@Column(name="EFRemarking")
		private String efRemarking;

		@Column(name="MultimediaAFSelection")
		private String multimediaAFSelection;

		@Column(name="CoSAssignment")
		private String coSAssignment;

		@Column(name="ISDNSwitchType")
		private String isDNSwitchType;

		@Column(name="LocalName")
		private String localName;

		@Column(name="RemoteName")
		private String remoteName;

		@Column(name="Password")
		private String password;

		@Column(name="DialerGroup")
		private String dialerGroup;

		@Column(name="1_ISDNInterface")
		private String isDNInterface_1;

		@Column(name="1_ISDN_Nr")
		private String isDN_Nr_1;

		@Column(name="1_Spid1")
		private String spid1_1;

		@Column(name="1_Spid2")
		private String spid2_1;
		
		@Column(name="2_ISDNInterface")
		private String isDNInterface_2;

		@Column(name="2_ISDN_Nr")
		private String isDN_Nr_2;

		@Column(name="2_Spid1")
		private String spid1_2;

		@Column(name="2_Spid2")
		private String spid2_2;

		
		@Column(name="3_ISDNInterface")
		private String isDNInterface_3;

		@Column(name="3_ISDN_Nr")
		private String isDN_Nr_3;

		@Column(name="3_Spid1")
		private String spid1_3;

		@Column(name="3_Spid2")
		private String spid2_3;
		
		@Column(name="4_ISDNInterface")
		private String isDNInterface_4;

		@Column(name="4_ISDN_Nr")
		private String isDN_Nr_4;

		@Column(name="4_Spid1")
		private String spid1_4;

		@Column(name="4_Spid2")
		private String spid2_4;
		
		@Column(name="DialerInterface")
		private String dialerInterface;

		@Column(name="Dialer_Interface_IP_HUB")
		private String dialer_Interface_IP_HUB;

		@Column(name="DialerInterface_IP_SPOKE")
		private String dialerInterface_IP_SPOKE;

		@Column(name="DialerInterfaceIP_Mask")
		private String dialerInterfaceIP_Mask;

		@Column(name="Dialer_Channels")
		private String dialer_channels;

		@Column(name="DialerString")
		private String dialerString;

		@Column(name="Loopback20_IP")
		private String loopback20_IP;

		@Column(name="Field1")
		private String field1;

		@Column(name="Field2")
		private String field2;

		@Column(name="Field3")
		private String field3;

		@Column(name="Field4")
		private String field4;

		@Column(name="Field5")
		private String field5;

		@Column(name="Field6")
		private String field6;

		@Column(name="Field7")
		private String field7;

		@Column(name="Field8")
		private String field8;

		@Column(name="Field9")
		private String field9;

		@Column(name="Field10")
		private String field10;

		@Column(name="Field11")
		private String field11;

		@Column(name="Field12")
		private String field12;

		@Column(name="Field13")
		private String field13;

		@Column(name="Field14")
		private String field14;

		@Column(name="Field15")
		private String field15;

		@Column(name="Field16")
		private String field16;

		@Column(name="Field17")
		private String field17;

		@Column(name="Field18")
		private String field18;

		@Column(name="Field19")
		private String field19;

		@Column(name="Field20")
		private String field20;

		@Column(name="Field21")
		private String field21;

		@Column(name="Field22")
		private String field22;

		@Column(name="Field23")
		private String field23;

		@Column(name="Field24")
		private String field24;

		@Column(name="Field25")
		private String field25;

		@Column(name="Field26")
		private String field26;

		@Column(name="Field27")
		private String field27;

		@Column(name="Field28")
		private String field28;

		@Column(name="Field29")
		private String field29;

		@Column(name="Field30")
		private String field30;

		@Column(name="Field31")
		private String field31;

		@Column(name="Field32")
		private String field32;

		@Column(name="Field33")
		private String field33;

		@Column(name="Field34")
		private String field34;

		@Column(name="Field35")
		private String field35;

		@Column(name="Field36")
		private String field36;

		@Column(name="Field37")
		private String field37;

		@Column(name="Field38")
		private String field38;

		@Column(name="Field39")
		private String field39;

		@Column(name="Field40")
		private String field40;

		@Column(name="Field41")
		private String field41;

		@Column(name="Field42")
		private String field42;

		@Column(name="Field43")
		private String field43;

		@Column(name="Field44")
		private String field44;

		@Column(name="Field45")
		private String field45;

		@Column(name="Field46")
		private String field46;

		@Column(name="Field47")
		private String field47;

		@Column(name="Field48")
		private String field48;

		@Column(name="Field49")
		private String field49;

		@Column(name="Field50")
		private String field50;

		@Column(name="Field51")
		private String field51;

		@Column(name="Field52")
		private String field52;

		@Column(name="Field53")
		private String field53;

		@Column(name="Field54")
		private String field54;

		@Column(name="Field55")
		private String field55;

		@Column(name="Field56")
		private String field56;

		@Column(name="Field57")
		private String field57;

		@Column(name="Field58")
		private String field58;

		@Column(name="Field59")
		private String field59;

		@Column(name="Field60")
		private String field60;

		@Column(name="Field61")
		private String field61;

		@Column(name="Field62")
		private String field62;

		@Column(name="Field63")
		private String field63;

		@Column(name="Field64")
		private String field64;

		@Column(name="Field65")
		private String field65;

		@Column(name="Field66")
		private String field66;

		@Column(name="Field67")
		private String field67;

		@Column(name="Field68")
		private String field68;

		@Column(name="Field69")
		private String field69;

		@Column(name="Field70")
		private String field70;

		@Column(name="Field71")
		private String field71;

		@Column(name="Field72")
		private String field72;

		@Column(name="Field73")
		private String field73;

		@Column(name="Field74")
		private String field74;

		@Column(name="Field75")
		private String field75;

		@Column(name="Field76")
		private String field76;

		@Column(name="Field77")
		private String field77;

		@Column(name="Field78")
		private String field78;

		@Column(name="Field79")
		private String field79;

		@Column(name="Field80")
		private String field80;

		@Column(name="REGION")
		private String region;

		@Column(name="CONFIGTEAM")
		private String configteam;

		@Column(name="1_LANInterface")
		private String lanInterface_1;

		@Column(name="1_LANPort")
		private String lanPort_1;

		@Column(name="1_LANNet")
		private String lanNet_1;

		@Column(name="1_LANIP")
		private String lanIP_1;

		@Column(name="1_LANMask")
		private String lanMask_1;

		@Column(name="1_LANWildcardMask")
		private String lanWildcardMask_1;

		@Column(name="1_VirtualIP")
		private String virtualIP_1;


		
		
		
		
		
		
		
		
		

		@Column(name="2_LANInterface")
		private String lanInterface_2;

		@Column(name="2_LANPort")
		private String lanPort_2;

		@Column(name="2_LANNet")
		private String lanNet_2;

		@Column(name="2_LANIP")
		private String lanIP_2;

		@Column(name="2_LANMask")
		private String lanMask_2;

		@Column(name="2_LANWildcardMask")
		private String lanWildcardMask_2;

		@Column(name="2_VirtualIP")
		private String virtualIP_2;
		
		

		@Column(name="3_LANInterface")
		private String lanInterface_3;

		@Column(name="3_LANPort")
		private String lanPort_3;

		@Column(name="3_LANNet")
		private String lanNet_3;

		@Column(name="3_LANIP")
		private String lanIP_3;

		@Column(name="3_LANMask")
		private String lanMask_3;

		@Column(name="3_LANWildcardMask")
		private String lanWildcardMask_3;

		@Column(name="3_VirtualIP")
		private String virtualIP_3;
		
		@Column(name="RoutingType_2")
		private String routingType_2;

		@Column(name="1_NetworkIPs_StaticRoutes")
		private String networkIPs_StaticRoutes_1;

		@Column(name="1_NetworkMask_StaticRoutes")
		private String networkMask_StaticRoutes_1;

		@Column(name="1_LANNxt_HopIP_forstaticroute")
		private String lanNxt_HopIP_forstaticroute_1;


		
		
		
		
		
		@Column(name="2_NetworkIPs_StaticRoutes")
		private String networkIPs_StaticRoutes_2;

		@Column(name="2_NetworkMask_StaticRoutes")
		private String networkMask_StaticRoutes_2;

		@Column(name="2_LANNxt_HopIP_forstaticroute")
		private String lanNxt_HopIP_forstaticroute_2;

		@Column(name="3_NetworkIPs_StaticRoutes")
		private String networkIPs_StaticRoutes_3;

		@Column(name="3_NetworkMask_StaticRoutes")
		private String networkMask_StaticRoutes_3;

		@Column(name="3_LANNxt_HopIP_forstarticroute")
		private String lanNxt_HopIP_forstaticroute_3;
		
		@Column(name="4_NetworkIPs_StaticRoutes")
		private String networkIPs_StaticRoutes_4;

		@Column(name="4_NetworkMask_StaticRoutes")
		private String networkMask_StaticRoutes_4;

		@Column(name="4_LANNxt_HopIP_forstarticroute")
		private String lanNxt_HopIP_forstaticroute_4;

		@Column(name="5_NetworkIPs_StaticRoutes")
		private String networkIPs_StaticRoutes_5;

		@Column(name="5_NetworkMask_StaticRoutes")
		private String networkMask_StaticRoutes_5;

		@Column(name="5_LANNxt_HopIP_forstarticroute")
		private String lanNxt_HopIP_forstaticroute_5;


		@Column(name="PROJ_LEADER_FIRST_NAME")
		private String proj_lead_first_name;

		@Column(name="PROJ_LEADER_LAST_NAME")
		private String proj_lead_last_name;

		@Column(name="PROJ_COORD_FIRST_NAME")
		private String proj_coord_first_name;

		@Column(name="PROJ_COORD_LAST_NAME")
		private String proj_cord_last_name;

		@Column(name="CLASSIC_ORDER_CREATE_DATE_2")
		private String classic_order_create_date_2;

		@Column(name="KPI_CCD")
		private String kpi_ccd;

		@Column(name="KPI_CRD")
		private String kpi_crd;

		@Column(name="KPI_ICD")
		private String kpi_icd;

		@Column(name="KPI_SCHEDULED_INSTALL")
		private String kpi_schedule_install;

		@Column(name="PROD_STATUS")
		private String prod_status;

		@Column(name="INSTALL_DATE")
		private String installDate;

		@Column(name="AccOrdRaisedbyBTwithSuppDate")
		private String accOrdRaisedbyBTwithSuppDate;

		@Column(name="AccSuppInstallCompleteDate")
		private String accSuppInstallCompleteDate;

		@Column(name="AccSuppCommitDeliveryDate")
		private String accSuppCommitDeliveryDate;

		@Column(name="AccSuppOrderApprovedDate")
		private String accSuppOrderApprovedDate;

		@Column(name="Acccircrequiredbydate")
		private String acccircrequiredbydate;

		@Column(name="DateAccSuppadvBTofAcCompletion")
		private String dateAccSuppadvBTofAcCompletion;

		@Column(name="DateAccSuppInformBTofCmtDelDt")
		private String dateAccSuppInformBTofCmtDelDt;

		@Column(name="DateOrderRcvdwiththeAccSupp")
		private String dateOrderRcvdwiththeAccSupp;

		@Column(name="CPE_ActualInstallationDate")
		private String cpe_actualInstallationDate;

		@Column(name="CPE_DateOrdRaisedbyBTwithSupp")
		private String cpe_dateOrdRaisedbyBTwithSupp;

		@Column(name="CPE_DeliveredtoSiteDate")
		private String cpe_deliveredtoSiteDate;

		@Column(name="CPE_PlannedInstallationDate")
		private String cpe_plannedInstallationDate;

		@Column(name="PreRTTDatGatIVsrBsCnfAmplfrbRt")
		private String preRTTDatGatIVsrBsCnfAmplfrbRt;

		@Column(name="RTTCEInstAndFinCnfLdAmpfrbOrng")
		private String rttce_instAndFinCnfLdAmpfrbOrng;

		@Column(name="Migration_Ampelfarbe_Gelb")
		private String migration_Ampelfarbe_Gelb;

		@Column(name="Monitoring_Ampelfarbe_Green_ID")
		private String monitoring_Ampelfarbe_Green_ID;

		@Column(name="CHANGE_ID")
		private String change_id;

		@Column(name="INSERT_DATE")
		private String insert_date;

		@Column(name="TIMESTAMP")
		private String timestamp;

		@Column(name="CCT_Pri_Sec")
		private String cct_pri_sec;

		@Column(name="1_LAN_Helper_1")
		private String _1_LAN_Helper_1;

		@Column(name="1_LAN_Helper_2")
		private String _1_LAN_Helper_2;

		@Column(name="1_NEXT_HOP_INTERFACE")
		private String _1_NEXT_HOP_INTERFACE;


		
		
		
		@Column(name="2_LAN_Helper_1")
		private String _2_LAN_Helper_1;

		@Column(name="2_LAN_Helper_2")
		private String _2_LAN_Helper_2;

		@Column(name="2_NEXT_HOP_INTERFACE")
		private String _2_NEXT_HOP_INTERFACE;

		@Column(name="3_LAN_Helper_1")
		private String _3_LAN_Helper_1;

		@Column(name="3_LAN_Helper_2")
		private String _3_LAN_Helper_2;

		@Column(name="3_NEXT_HOP_INTERFACE")
		private String _3_NEXT_HOP_INTERFACE;

		@Column(name="4_NEXT_HOP_INTERFACE")
		private String _4_NEXT_HOP_INTERFACE;

		@Column(name="AccBeaCircNTEFram_Str_CustEn")
		private String accBeaCircNTEFram_Str_CustEn;

		@Column(name="Access_Model")
		private String access_Model;

		@Column(name="CE_VCI")
		private String ce_vci;

		@Column(name="CE_VPI")
		private String ce_vpi;

		@Column(name="EMPTY_LINE")
		private String empty_line;

		@Column(name="PE_VCI")
		private String pe_vci;

		@Column(name="PE_VPI")
		private String pe_vpi;

		@Column(name="Project_Manager_Phone")
		private String project_Manager_Phone;

		@Column(name="SNMP_Community")
		private String snmp_community;

		@Column(name="SNMP_Read_Access")
		private String snmp_read_access;

		@Column(name="SNMP_Server_IP_1")
		private String snmp_server_ip_1;

		@Column(name="SNMP_Server_IP_2")
		private String snmp_server_ip_2;

		@Column(name="SNMP_Server_Mask_1")
		private String snmp_server_mask_1;


		@Column(name="SNMP_Server_Mask_2")
		private String snmp_server_mask_2;
		
		@Column(name="SNR_EXTENSION")
		private String snr_extension;

		@Column(name="xDSL_Downstream_bandwidth")
		private String xDSL_Downstream_bandwidth;

		@Column(name="xDSL_NTE_Framing_Structure")
		private String xDSL_NTE_Framing_Structure;

		@Column(name="xDSL_Type")
		private String xDSL_Type;

		@Column(name="AccBeaCirNTEOp_ElctrIntTyp_CuE")
		private String accBeaCirNTEOp_ElctrIntTyp_CuE;

		@Column(name="5_NEXT_HOP_INTERFACE")
		private String next_hop_interface_5;

		@Column(name="EMPTY_FIELD")
		private String empty_field;

		@Column(name="Global_M1400_Circuit_ID")
		private String global_m1400_circuit_id;

		@Column(name="ppp_hostname")
		private String ppp_hostname;

		@Column(name="ppp_password")
		private String ppp_password;

		@Column(name="PE_VLAN")
		private String pe_vlan;


		@Column(name="download_speed")
		private String download_speed;

		@Column(name="upload_speed")
		private String upload_speed;

		@Column(name="IPSec_password")
		private String ipSec_password;

		@Column(name="IPSec_username")
		private String ipSec_username;

		@Column(name="IPSecGroupKey")
		private String ipSecGroupKey;

		
		@Column(name="WANInterfaceMAC")
		private String wanInterfaceMAC;

		@Column(name="SITE_STATE")
		private String site_state;

		@Column(name="PE_VPIVCI")
		private String pe_vpivci;

		@Column(name="1_NetworkWilds_StaticRoutes")
		private String networkWilds_staticRoutes_1;
		

		@Column(name="2_NetworkWilds_StaticRoutes")
		private String networkWilds_staticRoutes_2;
		

		@Column(name="3_NetworkWilds_StaticRoutes")
		private String networkWilds_staticRoutes_3;

		@Column(name="notes")
		private String notes;

		@Column(name="ic_id")
		private String ic_id;

		@Column(name="sc_id")
		private String sc_id;

		@Column(name="product_id")
		private String product_id;

		@Column(name="router_id")
		private String router_id;

		@Column(name="ic_name")
		private String ic_name;

		@Column(name="4_NetworkWilds_StaticRoutes")
		private String networkWilds_staticRoutes_4;
		

		@Column(name="5_NetworkWilds_StaticRoutes")
		private String networkWilds_staticRoutes_5;

		@Column(name="LINK_ORDER_NO")
		private String link_order_no;

		@Column(name="Telnet_Host1")
		private String telnet_host1;

		@Column(name="xDSL_Upstream_bandwidth")
		private String xDSL_Upstream_bandwidth;

		@Column(name="OoB_MngmtNr")
		private String oob_mngmtNr;

		@Column(name="MonitoringSystem")
		private String monitoringSystem;

		@Column(name="Non_Classic_OrderNr")
		private String non_Classic_OrderNr;

		@Column(name="CoSClassificationType")
		private String coSClassificationType;

		
		@Column(name="PE_SupportRequest")
		private String pe_supportRequest;

		@Column(name="acn_design_code")
		private String acn_design_code;

		@Column(name="PE_DLCI")
		private String pe_dlci;

		@Column(name="TEST_NEW_FIELD")
		private String test_new_field;

		@Column(name="GPOP_Node_ID")
		private String gpop_node_id;

		@Column(name="GPOP_Node_Address")
		private String gpop_node_address;

		@Column(name="AccessType")
		private String accessType;

		@Column(name="ServiceVariant")
		private String serviceVariant;

		
		@Column(name="IPv6_Mngmt_Loopback_IPAddress")
		private String ipv6_Mngmt_Loopback_IPAddress;

		@Column(name="IPv6_PEP2PIP")
		private String ipv6_PEP2PIP;

		@Column(name="IPv6_CEP2PIP")
		private String ipv6_CEP2PIP;

		@Column(name="IPv6_PE_Loopback200_IP")
		private String ipv6_PE_Loopback200_IP;

		@Column(name="IPv6_1_LANInterface")
		private String ipv6_1_LANInterface;

		@Column(name="IPv6_1_LANIP")
		private String ipv6_1_LANIP;

		@Column(name="IPv6_1_LANMask_Lengh")
		private String ipv6_1_LANMask_Lengh;

		@Column(name="IPv6_1_VirtualIP")
		private String ipv6_1_VirtualIP;

		@Column(name="IPv6_1_LANPort")
		private String ipv6_1_LANPort;

		@Column(name="IPv6_1_LANSubNet")
		private String ipv6_1_LANSubNet;

		@Column(name="IPv6_1_LANWildcardMask")
		private String ipv6_1_LANWildcardMask;

		@Column(name="IPv6_1_LAN_Helper_1")
		private String ipv6_1_LAN_Helper_1;


		@Column(name="IPv6_1_LAN_Helper_2")
		private String ipv6_1_LAN_Helper_2;
		
		@Column(name="VPN_Connection_IP_Versions")
		private String vpn_connection_ip_versions;

		@Column(name="Customer_VPN_ID")
		private String customer_vpn_id;

		@Column(name="Customer_VPN_Index")
		private String customer_vpn_index;

		@Column(name="VPN_Connectivity_Mode")
		private String vpn_connectivity_Mode;

		@Column(name="BGP_Maximum_Prefix_Range_Name")
		private String bgp_maximum_prefix_range_name;

		@Column(name="BGP_Max_Prefix_Range_Name_IPv6")
		private String bgp_max_prefix_range_name_ipv6;

		@Column(name="Service_Ownership")
		private String service_ownership;

		@Column(name="SERVICE_OBJID")
		private String service_objid;

		@Column(name="VPN_Connection_Type_Extranet")
		private String vpn_connection_type_extranet;

		@Column(name="VPN_Connection_Type_Enterprise")
		private String vpn_connection_type_enterprise;

		@Column(name="Multicast_Services")
		private String multicast_services;

		@Column(name="BT_Sub_Order_Type")
		private String bt_sub_order_type;

		@Column(name="ComSpecActivationFlag")
		private String comSpecActivationFlag;

		@Column(name="Service_Name")
		private String service_Name;

		@Column(name="CLASSIC_ORDER_TITLE")
		private String classic_order_title;

		@Column(name="HYBRID_VPN")
		private String hybrid_vpn;

		@Column(name="ACCESS_TECHNOLOGY")
		private String access_technology;

		@Column(name="ManagementType")
		private String managementType;

		@Column(name="Full_Service_CPETest_schd_date")
		private String full_service_CPETest_schd_date;

		@Column(name="On_Site_CPE_ConnTest_schd_date")
		private String on_site_cpe_connTest_schd_date;

		@Column(name="ModifyType")
		private String modifyType;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getProd_cust_id() {
			return prod_cust_id;
		}

		public void setProd_cust_id(String prod_cust_id) {
			this.prod_cust_id = prod_cust_id;
		}

		public String getProd_cust_name() {
			return prod_cust_name;
		}

		public void setProd_cust_name(String prod_cust_name) {
			this.prod_cust_name = prod_cust_name;
		}

		public String getOrder_site_id() {
			return order_site_id;
		}

		public void setOrder_site_id(String order_site_id) {
			this.order_site_id = order_site_id;
		}

		public String getClassic_order_no() {
			return classic_order_no;
		}

		public void setClassic_order_no(String classic_order_no) {
			this.classic_order_no = classic_order_no;
		}

		public String getClassic_order_type() {
			return classic_order_type;
		}

		public void setClassic_order_type(String classic_order_type) {
			this.classic_order_type = classic_order_type;
		}

		public String getClassic_order_create_date() {
			return classic_order_create_date;
		}

		public void setClassic_order_create_date(String classic_order_create_date) {
			this.classic_order_create_date = classic_order_create_date;
		}

		public String getSite_address() {
			return site_address;
		}

		public void setSite_address(String site_address) {
			this.site_address = site_address;
		}

		public String getSite_postal_code() {
			return site_postal_code;
		}

		public void setSite_postal_code(String site_postal_code) {
			this.site_postal_code = site_postal_code;
		}

		public String getSite_city() {
			return site_city;
		}

		public void setSite_city(String site_city) {
			this.site_city = site_city;
		}

		public String getSite_country() {
			return site_country;
		}

		public void setSite_country(String site_country) {
			this.site_country = site_country;
		}

		public String getService_no() {
			return service_no;
		}

		public void setService_no(String service_no) {
			this.service_no = service_no;
		}

		public String getSitename() {
			return sitename;
		}

		public void setSitename(String sitename) {
			this.sitename = sitename;
		}

		public String getConfigurationSpecialistPhoneNr() {
			return configurationSpecialistPhoneNr;
		}

		public void setConfigurationSpecialistPhoneNr(String configurationSpecialistPhoneNr) {
			this.configurationSpecialistPhoneNr = configurationSpecialistPhoneNr;
		}

		public String getPuneConfigurationSpecialist() {
			return puneConfigurationSpecialist;
		}

		public void setPuneConfigurationSpecialist(String puneConfigurationSpecialist) {
			this.puneConfigurationSpecialist = puneConfigurationSpecialist;
		}

		public String getPuneConfigSpecialistPhNr() {
			return puneConfigSpecialistPhNr;
		}

		public void setPuneConfigSpecialistPhNr(String puneConfigSpecialistPhNr) {
			this.puneConfigSpecialistPhNr = puneConfigSpecialistPhNr;
		}

		public String getPuneConfigSpecialistEmail() {
			return puneConfigSpecialistEmail;
		}

		public void setPuneConfigSpecialistEmail(String puneConfigSpecialistEmail) {
			this.puneConfigSpecialistEmail = puneConfigSpecialistEmail;
		}

		public String getSellingCountry() {
			return sellingCountry;
		}

		public void setSellingCountry(String sellingCountry) {
			this.sellingCountry = sellingCountry;
		}

		public String getConfiguration_specialist() {
			return configuration_specialist;
		}

		public void setConfiguration_specialist(String configuration_specialist) {
			this.configuration_specialist = configuration_specialist;
		}

		public String getConfiguration_specialistEmail() {
			return configuration_specialistEmail;
		}

		public void setConfiguration_specialistEmail(String configuration_specialistEmail) {
			this.configuration_specialistEmail = configuration_specialistEmail;
		}

		public String getOrderManager() {
			return orderManager;
		}

		public void setOrderManager(String orderManager) {
			this.orderManager = orderManager;
		}

		public String getOrderManagerPhoneNr() {
			return orderManagerPhoneNr;
		}

		public void setOrderManagerPhoneNr(String orderManagerPhoneNr) {
			this.orderManagerPhoneNr = orderManagerPhoneNr;
		}

		public String getOrderManagerEmail() {
			return orderManagerEmail;
		}

		public void setOrderManagerEmail(String orderManagerEmail) {
			this.orderManagerEmail = orderManagerEmail;
		}

		public String getProjectManager() {
			return projectManager;
		}

		public void setProjectManager(String projectManager) {
			this.projectManager = projectManager;
		}

		public String getProjectManagerEmail() {
			return projectManagerEmail;
		}

		public void setProjectManagerEmail(String projectManagerEmail) {
			this.projectManagerEmail = projectManagerEmail;
		}

		public String getAccountManager() {
			return accountManager;
		}

		public void setAccountManager(String accountManager) {
			this.accountManager = accountManager;
		}

		public String getCustomerName_1() {
			return customerName_1;
		}

		public void setCustomerName_1(String customerName_1) {
			this.customerName_1 = customerName_1;
		}

		public String getPhone_Nr_1() {
			return phone_Nr_1;
		}

		public void setPhone_Nr_1(String phone_Nr_1) {
			this.phone_Nr_1 = phone_Nr_1;
		}

		public String getCelularPhone_Nr_1() {
			return celularPhone_Nr_1;
		}

		public void setCelularPhone_Nr_1(String celularPhone_Nr_1) {
			this.celularPhone_Nr_1 = celularPhone_Nr_1;
		}

		public String getEmail_1() {
			return email_1;
		}

		public void setEmail_1(String email_1) {
			this.email_1 = email_1;
		}

		public String getCustomerName_2() {
			return customerName_2;
		}

		public void setCustomerName_2(String customerName_2) {
			this.customerName_2 = customerName_2;
		}

		public String getPhone_Nr_2() {
			return phone_Nr_2;
		}

		public void setPhone_Nr_2(String phone_Nr_2) {
			this.phone_Nr_2 = phone_Nr_2;
		}

		public String getCelularPhone_Nr_2() {
			return celularPhone_Nr_2;
		}

		public void setCelularPhone_Nr_2(String celularPhone_Nr_2) {
			this.celularPhone_Nr_2 = celularPhone_Nr_2;
		}

		public String getEmail_2() {
			return email_2;
		}

		public void setEmail_2(String email_2) {
			this.email_2 = email_2;
		}

		public String getApop_node_address() {
			return apop_node_address;
		}

		public void setApop_node_address(String apop_node_address) {
			this.apop_node_address = apop_node_address;
		}

		public String getIp_clearAccPELoopbackAddress() {
			return ip_clearAccPELoopbackAddress;
		}

		public void setIp_clearAccPELoopbackAddress(String ip_clearAccPELoopbackAddress) {
			this.ip_clearAccPELoopbackAddress = ip_clearAccPELoopbackAddress;
		}

		public String getInterfaceDescriptor() {
			return interfaceDescriptor;
		}

		public void setInterfaceDescriptor(String interfaceDescriptor) {
			this.interfaceDescriptor = interfaceDescriptor;
		}

		public String getKlm_number() {
			return klm_number;
		}

		public void setKlm_number(String klm_number) {
			this.klm_number = klm_number;
		}

		public String getNo_oftimeslotsrequired() {
			return no_oftimeslotsrequired;
		}

		public void setNo_oftimeslotsrequired(String no_oftimeslotsrequired) {
			this.no_oftimeslotsrequired = no_oftimeslotsrequired;
		}

		public String getNodeId() {
			return nodeId;
		}

		public void setNodeId(String nodeId) {
			this.nodeId = nodeId;
		}

		public String getPe_colour() {
			return pe_colour;
		}

		public void setPe_colour(String pe_colour) {
			this.pe_colour = pe_colour;
		}

		public String getPe_interfaceIPAddress() {
			return pe_interfaceIPAddress;
		}

		public void setPe_interfaceIPAddress(String pe_interfaceIPAddress) {
			this.pe_interfaceIPAddress = pe_interfaceIPAddress;
		}

		public String getPerouterType() {
			return perouterType;
		}

		public void setPerouterType(String perouterType) {
			this.perouterType = perouterType;
		}

		public String getPhysicalInterface() {
			return physicalInterface;
		}

		public void setPhysicalInterface(String physicalInterface) {
			this.physicalInterface = physicalInterface;
		}

		public String getPortAllocation() {
			return portAllocation;
		}

		public void setPortAllocation(String portAllocation) {
			this.portAllocation = portAllocation;
		}

		public String getPortDeliveryType() {
			return portDeliveryType;
		}

		public void setPortDeliveryType(String portDeliveryType) {
			this.portDeliveryType = portDeliveryType;
		}

		public String getPortHWType() {
			return portHWType;
		}

		public void setPortHWType(String portHWType) {
			this.portHWType = portHWType;
		}

		public String getPortNo() {
			return portNo;
		}

		public void setPortNo(String portNo) {
			this.portNo = portNo;
		}

		public String getPortType() {
			return portType;
		}

		public void setPortType(String portType) {
			this.portType = portType;
		}

		public String getResilienttype() {
			return resilienttype;
		}

		public void setResilienttype(String resilienttype) {
			this.resilienttype = resilienttype;
		}

		public String getSlotNo() {
			return slotNo;
		}

		public void setSlotNo(String slotNo) {
			this.slotNo = slotNo;
		}

		public String getSpeed_Fullportspeed() {
			return speed_Fullportspeed;
		}

		public void setSpeed_Fullportspeed(String speed_Fullportspeed) {
			this.speed_Fullportspeed = speed_Fullportspeed;
		}

		public String getSub_interfaceID() {
			return sub_interfaceID;
		}

		public void setSub_interfaceID(String sub_interfaceID) {
			this.sub_interfaceID = sub_interfaceID;
		}

		public String getSub_rateSpeed() {
			return sub_rateSpeed;
		}

		public void setSub_rateSpeed(String sub_rateSpeed) {
			this.sub_rateSpeed = sub_rateSpeed;
		}

		public String getFrf_16id() {
			return frf_16id;
		}

		public void setFrf_16id(String frf_16id) {
			this.frf_16id = frf_16id;
		}

		public String getFrf_16node() {
			return frf_16node;
		}

		public void setFrf_16node(String frf_16node) {
			this.frf_16node = frf_16node;
		}

		public String getFrf_16port() {
			return frf_16port;
		}

		public void setFrf_16port(String frf_16port) {
			this.frf_16port = frf_16port;
		}

		public String getFrf_16slot() {
			return frf_16slot;
		}

		public void setFrf_16slot(String frf_16slot) {
			this.frf_16slot = frf_16slot;
		}

		public String getFrf_16subratePortSpeed() {
			return frf_16subratePortSpeed;
		}

		public void setFrf_16subratePortSpeed(String frf_16subratePortSpeed) {
			this.frf_16subratePortSpeed = frf_16subratePortSpeed;
		}

		public String getPortsinFRF_16() {
			return portsinFRF_16;
		}

		public void setPortsinFRF_16(String portsinFRF_16) {
			this.portsinFRF_16 = portsinFRF_16;
		}

		public String getCustomerVPNIndex() {
			return customerVPNIndex;
		}

		public void setCustomerVPNIndex(String customerVPNIndex) {
			this.customerVPNIndex = customerVPNIndex;
		}

		public String getPrimary_Secondary() {
			return primary_Secondary;
		}

		public void setPrimary_Secondary(String primary_Secondary) {
			this.primary_Secondary = primary_Secondary;
		}

		public String getResilience() {
			return resilience;
		}

		public void setResilience(String resilience) {
			this.resilience = resilience;
		}

		public String getRoutingType() {
			return routingType;
		}

		public void setRoutingType(String routingType) {
			this.routingType = routingType;
		}

		public String getTotalInformationRate_kbps() {
			return totalInformationRate_kbps;
		}

		public void setTotalInformationRate_kbps(String totalInformationRate_kbps) {
			this.totalInformationRate_kbps = totalInformationRate_kbps;
		}

		public String getVpn_ConnectionName() {
			return vpn_ConnectionName;
		}

		public void setVpn_ConnectionName(String vpn_ConnectionName) {
			this.vpn_ConnectionName = vpn_ConnectionName;
		}

		public String getNxE1T1Indicator() {
			return nxE1T1Indicator;
		}

		public void setNxE1T1Indicator(String nxE1T1Indicator) {
			this.nxE1T1Indicator = nxE1T1Indicator;
		}

		public String getPe_loopback200_IP() {
			return pe_loopback200_IP;
		}

		public void setPe_loopback200_IP(String pe_loopback200_IP) {
			this.pe_loopback200_IP = pe_loopback200_IP;
		}

		public String getVpnName() {
			return vpnName;
		}

		public void setVpnName(String vpnName) {
			this.vpnName = vpnName;
		}

		public String getAccBeaCircNTEFram_Str_CustEnd() {
			return accBeaCircNTEFram_Str_CustEnd;
		}

		public void setAccBeaCircNTEFram_Str_CustEnd(String accBeaCircNTEFram_Str_CustEnd) {
			this.accBeaCircNTEFram_Str_CustEnd = accBeaCircNTEFram_Str_CustEnd;
		}

		public String getAccBearCctNTEFram_Str_POPEnd() {
			return accBearCctNTEFram_Str_POPEnd;
		}

		public void setAccBearCctNTEFram_Str_POPEnd(String accBearCctNTEFram_Str_POPEnd) {
			this.accBearCctNTEFram_Str_POPEnd = accBearCctNTEFram_Str_POPEnd;
		}

		public String getAcBeCiNTEOp_ElctrIntTyp_CuEnd() {
			return acBeCiNTEOp_ElctrIntTyp_CuEnd;
		}

		public void setAcBeCiNTEOp_ElctrIntTyp_CuEnd(String acBeCiNTEOp_ElctrIntTyp_CuEnd) {
			this.acBeCiNTEOp_ElctrIntTyp_CuEnd = acBeCiNTEOp_ElctrIntTyp_CuEnd;
		}

		public String getAccBeaCircNTEPhyConn_CustEnd() {
			return accBeaCircNTEPhyConn_CustEnd;
		}

		public void setAccBeaCircNTEPhyConn_CustEnd(String accBeaCircNTEPhyConn_CustEnd) {
			this.accBeaCircNTEPhyConn_CustEnd = accBeaCircNTEPhyConn_CustEnd;
		}

		public String getAccessBearerCircuitSpeed() {
			return accessBearerCircuitSpeed;
		}

		public void setAccessBearerCircuitSpeed(String accessBearerCircuitSpeed) {
			this.accessBearerCircuitSpeed = accessBearerCircuitSpeed;
		}

		public String getAccCircResilience_DiversityTyp() {
			return accCircResilience_DiversityTyp;
		}

		public void setAccCircResilience_DiversityTyp(String accCircResilience_DiversityTyp) {
			this.accCircResilience_DiversityTyp = accCircResilience_DiversityTyp;
		}

		public String getAccessDeliveryType() {
			return accessDeliveryType;
		}

		public void setAccessDeliveryType(String accessDeliveryType) {
			this.accessDeliveryType = accessDeliveryType;
		}

		public String getAcPOP_NodCh_Trib_Timslt_KLMdet() {
			return acPOP_NodCh_Trib_Timslt_KLMdet;
		}

		public void setAcPOP_NodCh_Trib_Timslt_KLMdet(String acPOP_NodCh_Trib_Timslt_KLMdet) {
			this.acPOP_NodCh_Trib_Timslt_KLMdet = acPOP_NodCh_Trib_Timslt_KLMdet;
		}

		public String getAccessSuppliersCircuitID() {
			return accessSuppliersCircuitID;
		}

		public void setAccessSuppliersCircuitID(String accessSuppliersCircuitID) {
			this.accessSuppliersCircuitID = accessSuppliersCircuitID;
		}

		public String getAccessSuppliersName_TelcoName() {
			return accessSuppliersName_TelcoName;
		}

		public void setAccessSuppliersName_TelcoName(String accessSuppliersName_TelcoName) {
			this.accessSuppliersName_TelcoName = accessSuppliersName_TelcoName;
		}

		public String getAccessSuppliersQuoteReference() {
			return accessSuppliersQuoteReference;
		}

		public void setAccessSuppliersQuoteReference(String accessSuppliersQuoteReference) {
			this.accessSuppliersQuoteReference = accessSuppliersQuoteReference;
		}

		public String getChannalisedCircuitID() {
			return channalisedCircuitID;
		}

		public void setChannalisedCircuitID(String channalisedCircuitID) {
			this.channalisedCircuitID = channalisedCircuitID;
		}

		public String getCircuitServiceID() {
			return circuitServiceID;
		}

		public void setCircuitServiceID(String circuitServiceID) {
			this.circuitServiceID = circuitServiceID;
		}

		public String getChannelGroup() {
			return channelGroup;
		}

		public void setChannelGroup(String channelGroup) {
			this.channelGroup = channelGroup;
		}

		public String getChannelised() {
			return channelised;
		}

		public void setChannelised(String channelised) {
			this.channelised = channelised;
		}

		public String getAutonomousSystem_ASNumber() {
			return autonomousSystem_ASNumber;
		}

		public void setAutonomousSystem_ASNumber(String autonomousSystem_ASNumber) {
			this.autonomousSystem_ASNumber = autonomousSystem_ASNumber;
		}

		public String getActualInstallationDate() {
			return actualInstallationDate;
		}

		public void setActualInstallationDate(String actualInstallationDate) {
			this.actualInstallationDate = actualInstallationDate;
		}

		public String getAssetTagNo_() {
			return AssetTagNo_;
		}

		public void setAssetTagNo_(String assetTagNo_) {
			AssetTagNo_ = assetTagNo_;
		}

		public String getCall_off_agent_name() {
			return call_off_agent_name;
		}

		public void setCall_off_agent_name(String call_off_agent_name) {
			this.call_off_agent_name = call_off_agent_name;
		}

		public String getCpeid() {
			return cpeid;
		}

		public void setCpeid(String cpeid) {
			this.cpeid = cpeid;
		}

		public String getCpeUsage() {
			return cpeUsage;
		}

		public void setCpeUsage(String cpeUsage) {
			this.cpeUsage = cpeUsage;
		}

		public String getInstaller() {
			return installer;
		}

		public void setInstaller(String installer) {
			this.installer = installer;
		}

		public String getLocalSupplierName() {
			return localSupplierName;
		}

		public void setLocalSupplierName(String localSupplierName) {
			this.localSupplierName = localSupplierName;
		}

		public String getMaintainer() {
			return maintainer;
		}

		public void setMaintainer(String maintainer) {
			this.maintainer = maintainer;
		}

		public String getManagedDeviceName() {
			return managedDeviceName;
		}

		public void setManagedDeviceName(String managedDeviceName) {
			this.managedDeviceName = managedDeviceName;
		}

		public String getManagement_LoopbackIPAddress() {
			return management_LoopbackIPAddress;
		}

		public void setManagement_LoopbackIPAddress(String management_LoopbackIPAddress) {
			this.management_LoopbackIPAddress = management_LoopbackIPAddress;
		}

		public String getCpeCard_partDescription() {
			return cpeCard_partDescription;
		}

		public void setCpeCard_partDescription(String cpeCard_partDescription) {
			this.cpeCard_partDescription = cpeCard_partDescription;
		}

		public String getCpe_firmware_partDescription() {
			return cpe_firmware_partDescription;
		}

		public void setCpe_firmware_partDescription(String cpe_firmware_partDescription) {
			this.cpe_firmware_partDescription = cpe_firmware_partDescription;
		}

		public String getCpe_partDescription() {
			return cpe_partDescription;
		}

		public void setCpe_partDescription(String cpe_partDescription) {
			this.cpe_partDescription = cpe_partDescription;
		}

		public String getCpeFirmware_Type() {
			return cpeFirmware_Type;
		}

		public void setCpeFirmware_Type(String cpeFirmware_Type) {
			this.cpeFirmware_Type = cpeFirmware_Type;
		}

		public String getCpe_software_PartDescription() {
			return cpe_software_PartDescription;
		}

		public void setCpe_software_PartDescription(String cpe_software_PartDescription) {
			this.cpe_software_PartDescription = cpe_software_PartDescription;
		}

		public String getSpeed_fullportspeed_2() {
			return speed_fullportspeed_2;
		}

		public void setSpeed_fullportspeed_2(String speed_fullportspeed_2) {
			this.speed_fullportspeed_2 = speed_fullportspeed_2;
		}

		public String getWan_interfaceType() {
			return wan_interfaceType;
		}

		public void setWan_interfaceType(String wan_interfaceType) {
			this.wan_interfaceType = wan_interfaceType;
		}

		public String getWan_interfacePort() {
			return wan_interfacePort;
		}

		public void setWan_interfacePort(String wan_interfacePort) {
			this.wan_interfacePort = wan_interfacePort;
		}

		public String getWan_interfaceDLCI() {
			return wan_interfaceDLCI;
		}

		public void setWan_interfaceDLCI(String wan_interfaceDLCI) {
			this.wan_interfaceDLCI = wan_interfaceDLCI;
		}

		public String getWan_interfaceIP() {
			return wan_interfaceIP;
		}

		public void setWan_interfaceIP(String wan_interfaceIP) {
			this.wan_interfaceIP = wan_interfaceIP;
		}

		public String getWan_interfaceMask() {
			return wan_interfaceMask;
		}

		public void setWan_interfaceMask(String wan_interfaceMask) {
			this.wan_interfaceMask = wan_interfaceMask;
		}

		public String getWan_iPNext_Hop() {
			return wan_iPNext_Hop;
		}

		public void setWan_iPNext_Hop(String wan_iPNext_Hop) {
			this.wan_iPNext_Hop = wan_iPNext_Hop;
		}

		public String getIp_secHubIP() {
			return ip_secHubIP;
		}

		public void setIp_secHubIP(String ip_secHubIP) {
			this.ip_secHubIP = ip_secHubIP;
		}

		public String getIp_secSpokeIP() {
			return ip_secSpokeIP;
		}

		public void setIp_secSpokeIP(String ip_secSpokeIP) {
			this.ip_secSpokeIP = ip_secSpokeIP;
		}

		public String getIp_secPre_SharedKey() {
			return ip_secPre_SharedKey;
		}

		public void setIp_secPre_SharedKey(String ip_secPre_SharedKey) {
			this.ip_secPre_SharedKey = ip_secPre_SharedKey;
		}

		public String getFinal_Host_Name() {
			return final_Host_Name;
		}

		public void setFinal_Host_Name(String final_Host_Name) {
			this.final_Host_Name = final_Host_Name;
		}

		public String getPep2pip() {
			return pep2pip;
		}

		public void setPep2pip(String pep2pip) {
			this.pep2pip = pep2pip;
		}

		public String getCep2pip() {
			return cep2pip;
		}

		public void setCep2pip(String cep2pip) {
			this.cep2pip = cep2pip;
		}

		public String getBgp_network_statement_1() {
			return bgp_network_statement_1;
		}

		public void setBgp_network_statement_1(String bgp_network_statement_1) {
			this.bgp_network_statement_1 = bgp_network_statement_1;
		}

		public String getBgp_mask_statement_1() {
			return bgp_mask_statement_1;
		}

		public void setBgp_mask_statement_1(String bgp_mask_statement_1) {
			this.bgp_mask_statement_1 = bgp_mask_statement_1;
		}

		public String getAfeffectivePlanningBandwidth() {
			return afeffectivePlanningBandwidth;
		}

		public void setAfeffectivePlanningBandwidth(String afeffectivePlanningBandwidth) {
			this.afeffectivePlanningBandwidth = afeffectivePlanningBandwidth;
		}

		public String getClassAF1CIPR() {
			return classAF1CIPR;
		}

		public void setClassAF1CIPR(String classAF1CIPR) {
			this.classAF1CIPR = classAF1CIPR;
		}

		public String getClassAF1MIPR() {
			return classAF1MIPR;
		}

		public void setClassAF1MIPR(String classAF1MIPR) {
			this.classAF1MIPR = classAF1MIPR;
		}

		public String getClassAF2CIPR() {
			return classAF2CIPR;
		}

		public void setClassAF2CIPR(String classAF2CIPR) {
			this.classAF2CIPR = classAF2CIPR;
		}

		public String getClassAF2MIPR() {
			return classAF2MIPR;
		}

		public void setClassAF2MIPR(String classAF2MIPR) {
			this.classAF2MIPR = classAF2MIPR;
		}

		public String getClassAF3CIPR() {
			return classAF3CIPR;
		}

		public void setClassAF3CIPR(String classAF3CIPR) {
			this.classAF3CIPR = classAF3CIPR;
		}

		public String getClassAF3MIPR() {
			return classAF3MIPR;
		}

		public void setClassAF3MIPR(String classAF3MIPR) {
			this.classAF3MIPR = classAF3MIPR;
		}

		public String getClassAF4CIPR() {
			return classAF4CIPR;
		}

		public void setClassAF4CIPR(String classAF4CIPR) {
			this.classAF4CIPR = classAF4CIPR;
		}

		public String getClassAF4MIPR() {
			return classAF4MIPR;
		}

		public void setClassAF4MIPR(String classAF4MIPR) {
			this.classAF4MIPR = classAF4MIPR;
		}

		public String getClassDEMIPR() {
			return classDEMIPR;
		}

		public void setClassDEMIPR(String classDEMIPR) {
			this.classDEMIPR = classDEMIPR;
		}

		public String getClassEFCIPR() {
			return classEFCIPR;
		}

		public void setClassEFCIPR(String classEFCIPR) {
			this.classEFCIPR = classEFCIPR;
		}

		public String getClassMGTCIPR() {
			return classMGTCIPR;
		}

		public void setClassMGTCIPR(String classMGTCIPR) {
			this.classMGTCIPR = classMGTCIPR;
		}

		public String getClassMGTMIPR() {
			return classMGTMIPR;
		}

		public void setClassMGTMIPR(String classMGTMIPR) {
			this.classMGTMIPR = classMGTMIPR;
		}

		public String getCoSModel() {
			return coSModel;
		}

		public void setCoSModel(String coSModel) {
			this.coSModel = coSModel;
		}

		public String getCoSBleaching() {
			return coSBleaching;
		}

		public void setCoSBleaching(String coSBleaching) {
			this.coSBleaching = coSBleaching;
		}

		public String getCoSCustomisationlevel() {
			return coSCustomisationlevel;
		}

		public void setCoSCustomisationlevel(String coSCustomisationlevel) {
			this.coSCustomisationlevel = coSCustomisationlevel;
		}

		public String getCoSEnabled() {
			return coSEnabled;
		}

		public void setCoSEnabled(String coSEnabled) {
			this.coSEnabled = coSEnabled;
		}

		public String getCoSInterworking() {
			return coSInterworking;
		}

		public void setCoSInterworking(String coSInterworking) {
			this.coSInterworking = coSInterworking;
		}

		public String getCoSTemplate() {
			return coSTemplate;
		}

		public void setCoSTemplate(String coSTemplate) {
			this.coSTemplate = coSTemplate;
		}

		public String getDeRemarking() {
			return deRemarking;
		}

		public void setDeRemarking(String deRemarking) {
			this.deRemarking = deRemarking;
		}

		public String getEfRemarking() {
			return efRemarking;
		}

		public void setEfRemarking(String efRemarking) {
			this.efRemarking = efRemarking;
		}

		public String getMultimediaAFSelection() {
			return multimediaAFSelection;
		}

		public void setMultimediaAFSelection(String multimediaAFSelection) {
			this.multimediaAFSelection = multimediaAFSelection;
		}

		public String getCoSAssignment() {
			return coSAssignment;
		}

		public void setCoSAssignment(String coSAssignment) {
			this.coSAssignment = coSAssignment;
		}

		public String getIsDNSwitchType() {
			return isDNSwitchType;
		}

		public void setIsDNSwitchType(String isDNSwitchType) {
			this.isDNSwitchType = isDNSwitchType;
		}

		public String getLocalName() {
			return localName;
		}

		public void setLocalName(String localName) {
			this.localName = localName;
		}

		public String getRemoteName() {
			return remoteName;
		}

		public void setRemoteName(String remoteName) {
			this.remoteName = remoteName;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public String getDialerGroup() {
			return dialerGroup;
		}

		public void setDialerGroup(String dialerGroup) {
			this.dialerGroup = dialerGroup;
		}

		public String getIsDNInterface_1() {
			return isDNInterface_1;
		}

		public void setIsDNInterface_1(String isDNInterface_1) {
			this.isDNInterface_1 = isDNInterface_1;
		}

		public String getIsDN_Nr_1() {
			return isDN_Nr_1;
		}

		public void setIsDN_Nr_1(String isDN_Nr_1) {
			this.isDN_Nr_1 = isDN_Nr_1;
		}

		public String getSpid1_1() {
			return spid1_1;
		}

		public void setSpid1_1(String spid1_1) {
			this.spid1_1 = spid1_1;
		}

		public String getSpid2_1() {
			return spid2_1;
		}

		public void setSpid2_1(String spid2_1) {
			this.spid2_1 = spid2_1;
		}

		public String getIsDNInterface_2() {
			return isDNInterface_2;
		}

		public void setIsDNInterface_2(String isDNInterface_2) {
			this.isDNInterface_2 = isDNInterface_2;
		}

		public String getIsDN_Nr_2() {
			return isDN_Nr_2;
		}

		public void setIsDN_Nr_2(String isDN_Nr_2) {
			this.isDN_Nr_2 = isDN_Nr_2;
		}

		public String getSpid1_2() {
			return spid1_2;
		}

		public void setSpid1_2(String spid1_2) {
			this.spid1_2 = spid1_2;
		}

		public String getSpid2_2() {
			return spid2_2;
		}

		public void setSpid2_2(String spid2_2) {
			this.spid2_2 = spid2_2;
		}

		public String getIsDNInterface_3() {
			return isDNInterface_3;
		}

		public void setIsDNInterface_3(String isDNInterface_3) {
			this.isDNInterface_3 = isDNInterface_3;
		}

		public String getIsDN_Nr_3() {
			return isDN_Nr_3;
		}

		public void setIsDN_Nr_3(String isDN_Nr_3) {
			this.isDN_Nr_3 = isDN_Nr_3;
		}

		public String getSpid1_3() {
			return spid1_3;
		}

		public void setSpid1_3(String spid1_3) {
			this.spid1_3 = spid1_3;
		}

		public String getSpid2_3() {
			return spid2_3;
		}

		public void setSpid2_3(String spid2_3) {
			this.spid2_3 = spid2_3;
		}

		public String getIsDNInterface_4() {
			return isDNInterface_4;
		}

		public void setIsDNInterface_4(String isDNInterface_4) {
			this.isDNInterface_4 = isDNInterface_4;
		}

		public String getIsDN_Nr_4() {
			return isDN_Nr_4;
		}

		public void setIsDN_Nr_4(String isDN_Nr_4) {
			this.isDN_Nr_4 = isDN_Nr_4;
		}

		public String getSpid1_4() {
			return spid1_4;
		}

		public void setSpid1_4(String spid1_4) {
			this.spid1_4 = spid1_4;
		}

		public String getSpid2_4() {
			return spid2_4;
		}

		public void setSpid2_4(String spid2_4) {
			this.spid2_4 = spid2_4;
		}

		public String getDialerInterface() {
			return dialerInterface;
		}

		public void setDialerInterface(String dialerInterface) {
			this.dialerInterface = dialerInterface;
		}

		public String getDialer_Interface_IP_HUB() {
			return dialer_Interface_IP_HUB;
		}

		public void setDialer_Interface_IP_HUB(String dialer_Interface_IP_HUB) {
			this.dialer_Interface_IP_HUB = dialer_Interface_IP_HUB;
		}

		public String getDialerInterface_IP_SPOKE() {
			return dialerInterface_IP_SPOKE;
		}

		public void setDialerInterface_IP_SPOKE(String dialerInterface_IP_SPOKE) {
			this.dialerInterface_IP_SPOKE = dialerInterface_IP_SPOKE;
		}

		public String getDialerInterfaceIP_Mask() {
			return dialerInterfaceIP_Mask;
		}

		public void setDialerInterfaceIP_Mask(String dialerInterfaceIP_Mask) {
			this.dialerInterfaceIP_Mask = dialerInterfaceIP_Mask;
		}

		public String getDialer_channels() {
			return dialer_channels;
		}

		public void setDialer_channels(String dialer_channels) {
			this.dialer_channels = dialer_channels;
		}

		public String getDialerString() {
			return dialerString;
		}

		public void setDialerString(String dialerString) {
			this.dialerString = dialerString;
		}

		public String getLoopback20_IP() {
			return loopback20_IP;
		}

		public void setLoopback20_IP(String loopback20_IP) {
			this.loopback20_IP = loopback20_IP;
		}

		public String getField1() {
			return field1;
		}

		public void setField1(String field1) {
			this.field1 = field1;
		}

		public String getField2() {
			return field2;
		}

		public void setField2(String field2) {
			this.field2 = field2;
		}

		public String getField3() {
			return field3;
		}

		public void setField3(String field3) {
			this.field3 = field3;
		}

		public String getField4() {
			return field4;
		}

		public void setField4(String field4) {
			this.field4 = field4;
		}

		public String getField5() {
			return field5;
		}

		public void setField5(String field5) {
			this.field5 = field5;
		}

		public String getField6() {
			return field6;
		}

		public void setField6(String field6) {
			this.field6 = field6;
		}

		public String getField7() {
			return field7;
		}

		public void setField7(String field7) {
			this.field7 = field7;
		}

		public String getField8() {
			return field8;
		}

		public void setField8(String field8) {
			this.field8 = field8;
		}

		public String getField9() {
			return field9;
		}

		public void setField9(String field9) {
			this.field9 = field9;
		}

		public String getField10() {
			return field10;
		}

		public void setField10(String field10) {
			this.field10 = field10;
		}

		public String getField11() {
			return field11;
		}

		public void setField11(String field11) {
			this.field11 = field11;
		}

		public String getField12() {
			return field12;
		}

		public void setField12(String field12) {
			this.field12 = field12;
		}

		public String getField13() {
			return field13;
		}

		public void setField13(String field13) {
			this.field13 = field13;
		}

		public String getField14() {
			return field14;
		}

		public void setField14(String field14) {
			this.field14 = field14;
		}

		public String getField15() {
			return field15;
		}

		public void setField15(String field15) {
			this.field15 = field15;
		}

		public String getField16() {
			return field16;
		}

		public void setField16(String field16) {
			this.field16 = field16;
		}

		public String getField17() {
			return field17;
		}

		public void setField17(String field17) {
			this.field17 = field17;
		}

		public String getField18() {
			return field18;
		}

		public void setField18(String field18) {
			this.field18 = field18;
		}

		public String getField19() {
			return field19;
		}

		public void setField19(String field19) {
			this.field19 = field19;
		}

		public String getField20() {
			return field20;
		}

		public void setField20(String field20) {
			this.field20 = field20;
		}

		public String getField21() {
			return field21;
		}

		public void setField21(String field21) {
			this.field21 = field21;
		}

		public String getField22() {
			return field22;
		}

		public void setField22(String field22) {
			this.field22 = field22;
		}

		public String getField23() {
			return field23;
		}

		public void setField23(String field23) {
			this.field23 = field23;
		}

		public String getField24() {
			return field24;
		}

		public void setField24(String field24) {
			this.field24 = field24;
		}

		public String getField25() {
			return field25;
		}

		public void setField25(String field25) {
			this.field25 = field25;
		}

		public String getField26() {
			return field26;
		}

		public void setField26(String field26) {
			this.field26 = field26;
		}

		public String getField27() {
			return field27;
		}

		public void setField27(String field27) {
			this.field27 = field27;
		}

		public String getField28() {
			return field28;
		}

		public void setField28(String field28) {
			this.field28 = field28;
		}

		public String getField29() {
			return field29;
		}

		public void setField29(String field29) {
			this.field29 = field29;
		}

		public String getField30() {
			return field30;
		}

		public void setField30(String field30) {
			this.field30 = field30;
		}

		public String getField31() {
			return field31;
		}

		public void setField31(String field31) {
			this.field31 = field31;
		}

		public String getField32() {
			return field32;
		}

		public void setField32(String field32) {
			this.field32 = field32;
		}

		public String getField33() {
			return field33;
		}

		public void setField33(String field33) {
			this.field33 = field33;
		}

		public String getField34() {
			return field34;
		}

		public void setField34(String field34) {
			this.field34 = field34;
		}

		public String getField35() {
			return field35;
		}

		public void setField35(String field35) {
			this.field35 = field35;
		}

		public String getField36() {
			return field36;
		}

		public void setField36(String field36) {
			this.field36 = field36;
		}

		public String getField37() {
			return field37;
		}

		public void setField37(String field37) {
			this.field37 = field37;
		}

		public String getField38() {
			return field38;
		}

		public void setField38(String field38) {
			this.field38 = field38;
		}

		public String getField39() {
			return field39;
		}

		public void setField39(String field39) {
			this.field39 = field39;
		}

		public String getField40() {
			return field40;
		}

		public void setField40(String field40) {
			this.field40 = field40;
		}

		public String getField41() {
			return field41;
		}

		public void setField41(String field41) {
			this.field41 = field41;
		}

		public String getField42() {
			return field42;
		}

		public void setField42(String field42) {
			this.field42 = field42;
		}

		public String getField43() {
			return field43;
		}

		public void setField43(String field43) {
			this.field43 = field43;
		}

		public String getField44() {
			return field44;
		}

		public void setField44(String field44) {
			this.field44 = field44;
		}

		public String getField45() {
			return field45;
		}

		public void setField45(String field45) {
			this.field45 = field45;
		}

		public String getField46() {
			return field46;
		}

		public void setField46(String field46) {
			this.field46 = field46;
		}

		public String getField47() {
			return field47;
		}

		public void setField47(String field47) {
			this.field47 = field47;
		}

		public String getField48() {
			return field48;
		}

		public void setField48(String field48) {
			this.field48 = field48;
		}

		public String getField49() {
			return field49;
		}

		public void setField49(String field49) {
			this.field49 = field49;
		}

		public String getField50() {
			return field50;
		}

		public void setField50(String field50) {
			this.field50 = field50;
		}

		public String getField51() {
			return field51;
		}

		public void setField51(String field51) {
			this.field51 = field51;
		}

		public String getField52() {
			return field52;
		}

		public void setField52(String field52) {
			this.field52 = field52;
		}

		public String getField53() {
			return field53;
		}

		public void setField53(String field53) {
			this.field53 = field53;
		}

		public String getField54() {
			return field54;
		}

		public void setField54(String field54) {
			this.field54 = field54;
		}

		public String getField55() {
			return field55;
		}

		public void setField55(String field55) {
			this.field55 = field55;
		}

		public String getField56() {
			return field56;
		}

		public void setField56(String field56) {
			this.field56 = field56;
		}

		public String getField57() {
			return field57;
		}

		public void setField57(String field57) {
			this.field57 = field57;
		}

		public String getField58() {
			return field58;
		}

		public void setField58(String field58) {
			this.field58 = field58;
		}

		public String getField59() {
			return field59;
		}

		public void setField59(String field59) {
			this.field59 = field59;
		}

		public String getField60() {
			return field60;
		}

		public void setField60(String field60) {
			this.field60 = field60;
		}

		public String getField61() {
			return field61;
		}

		public void setField61(String field61) {
			this.field61 = field61;
		}

		public String getField62() {
			return field62;
		}

		public void setField62(String field62) {
			this.field62 = field62;
		}

		public String getField63() {
			return field63;
		}

		public void setField63(String field63) {
			this.field63 = field63;
		}

		public String getField64() {
			return field64;
		}

		public void setField64(String field64) {
			this.field64 = field64;
		}

		public String getField65() {
			return field65;
		}

		public void setField65(String field65) {
			this.field65 = field65;
		}

		public String getField66() {
			return field66;
		}

		public void setField66(String field66) {
			this.field66 = field66;
		}

		public String getField67() {
			return field67;
		}

		public void setField67(String field67) {
			this.field67 = field67;
		}

		public String getField68() {
			return field68;
		}

		public void setField68(String field68) {
			this.field68 = field68;
		}

		public String getField69() {
			return field69;
		}

		public void setField69(String field69) {
			this.field69 = field69;
		}

		public String getField70() {
			return field70;
		}

		public void setField70(String field70) {
			this.field70 = field70;
		}

		public String getField71() {
			return field71;
		}

		public void setField71(String field71) {
			this.field71 = field71;
		}

		public String getField72() {
			return field72;
		}

		public void setField72(String field72) {
			this.field72 = field72;
		}

		public String getField73() {
			return field73;
		}

		public void setField73(String field73) {
			this.field73 = field73;
		}

		public String getField74() {
			return field74;
		}

		public void setField74(String field74) {
			this.field74 = field74;
		}

		public String getField75() {
			return field75;
		}

		public void setField75(String field75) {
			this.field75 = field75;
		}

		public String getField76() {
			return field76;
		}

		public void setField76(String field76) {
			this.field76 = field76;
		}

		public String getField77() {
			return field77;
		}

		public void setField77(String field77) {
			this.field77 = field77;
		}

		public String getField78() {
			return field78;
		}

		public void setField78(String field78) {
			this.field78 = field78;
		}

		public String getField79() {
			return field79;
		}

		public void setField79(String field79) {
			this.field79 = field79;
		}

		public String getField80() {
			return field80;
		}

		public void setField80(String field80) {
			this.field80 = field80;
		}

		public String getRegion() {
			return region;
		}

		public void setRegion(String region) {
			this.region = region;
		}

		public String getConfigteam() {
			return configteam;
		}

		public void setConfigteam(String configteam) {
			this.configteam = configteam;
		}

		public String getLanInterface_1() {
			return lanInterface_1;
		}

		public void setLanInterface_1(String lanInterface_1) {
			this.lanInterface_1 = lanInterface_1;
		}

		public String getLanPort_1() {
			return lanPort_1;
		}

		public void setLanPort_1(String lanPort_1) {
			this.lanPort_1 = lanPort_1;
		}

		public String getLanNet_1() {
			return lanNet_1;
		}

		public void setLanNet_1(String lanNet_1) {
			this.lanNet_1 = lanNet_1;
		}

		public String getLanIP_1() {
			return lanIP_1;
		}

		public void setLanIP_1(String lanIP_1) {
			this.lanIP_1 = lanIP_1;
		}

		public String getLanMask_1() {
			return lanMask_1;
		}

		public void setLanMask_1(String lanMask_1) {
			this.lanMask_1 = lanMask_1;
		}

		public String getLanWildcardMask_1() {
			return lanWildcardMask_1;
		}

		public void setLanWildcardMask_1(String lanWildcardMask_1) {
			this.lanWildcardMask_1 = lanWildcardMask_1;
		}

		public String getVirtualIP_1() {
			return virtualIP_1;
		}

		public void setVirtualIP_1(String virtualIP_1) {
			this.virtualIP_1 = virtualIP_1;
		}

		public String getLanInterface_2() {
			return lanInterface_2;
		}

		public void setLanInterface_2(String lanInterface_2) {
			this.lanInterface_2 = lanInterface_2;
		}

		public String getLanPort_2() {
			return lanPort_2;
		}

		public void setLanPort_2(String lanPort_2) {
			this.lanPort_2 = lanPort_2;
		}

		public String getLanNet_2() {
			return lanNet_2;
		}

		public void setLanNet_2(String lanNet_2) {
			this.lanNet_2 = lanNet_2;
		}

		public String getLanIP_2() {
			return lanIP_2;
		}

		public void setLanIP_2(String lanIP_2) {
			this.lanIP_2 = lanIP_2;
		}

		public String getLanMask_2() {
			return lanMask_2;
		}

		public void setLanMask_2(String lanMask_2) {
			this.lanMask_2 = lanMask_2;
		}

		public String getLanWildcardMask_2() {
			return lanWildcardMask_2;
		}

		public void setLanWildcardMask_2(String lanWildcardMask_2) {
			this.lanWildcardMask_2 = lanWildcardMask_2;
		}

		public String getVirtualIP_2() {
			return virtualIP_2;
		}

		public void setVirtualIP_2(String virtualIP_2) {
			this.virtualIP_2 = virtualIP_2;
		}

		public String getLanInterface_3() {
			return lanInterface_3;
		}

		public void setLanInterface_3(String lanInterface_3) {
			this.lanInterface_3 = lanInterface_3;
		}

		public String getLanPort_3() {
			return lanPort_3;
		}

		public void setLanPort_3(String lanPort_3) {
			this.lanPort_3 = lanPort_3;
		}

		public String getLanNet_3() {
			return lanNet_3;
		}

		public void setLanNet_3(String lanNet_3) {
			this.lanNet_3 = lanNet_3;
		}

		public String getLanIP_3() {
			return lanIP_3;
		}

		public void setLanIP_3(String lanIP_3) {
			this.lanIP_3 = lanIP_3;
		}

		public String getLanMask_3() {
			return lanMask_3;
		}

		public void setLanMask_3(String lanMask_3) {
			this.lanMask_3 = lanMask_3;
		}

		public String getLanWildcardMask_3() {
			return lanWildcardMask_3;
		}

		public void setLanWildcardMask_3(String lanWildcardMask_3) {
			this.lanWildcardMask_3 = lanWildcardMask_3;
		}

		public String getVirtualIP_3() {
			return virtualIP_3;
		}

		public void setVirtualIP_3(String virtualIP_3) {
			this.virtualIP_3 = virtualIP_3;
		}

		public String getRoutingType_2() {
			return routingType_2;
		}

		public void setRoutingType_2(String routingType_2) {
			this.routingType_2 = routingType_2;
		}

		public String getNetworkIPs_StaticRoutes_1() {
			return networkIPs_StaticRoutes_1;
		}

		public void setNetworkIPs_StaticRoutes_1(String networkIPs_StaticRoutes_1) {
			this.networkIPs_StaticRoutes_1 = networkIPs_StaticRoutes_1;
		}

		public String getNetworkMask_StaticRoutes_1() {
			return networkMask_StaticRoutes_1;
		}

		public void setNetworkMask_StaticRoutes_1(String networkMask_StaticRoutes_1) {
			this.networkMask_StaticRoutes_1 = networkMask_StaticRoutes_1;
		}

		public String getLanNxt_HopIP_forstaticroute_1() {
			return lanNxt_HopIP_forstaticroute_1;
		}

		public void setLanNxt_HopIP_forstaticroute_1(String lanNxt_HopIP_forstaticroute_1) {
			this.lanNxt_HopIP_forstaticroute_1 = lanNxt_HopIP_forstaticroute_1;
		}

		public String getNetworkIPs_StaticRoutes_2() {
			return networkIPs_StaticRoutes_2;
		}

		public void setNetworkIPs_StaticRoutes_2(String networkIPs_StaticRoutes_2) {
			this.networkIPs_StaticRoutes_2 = networkIPs_StaticRoutes_2;
		}

		public String getNetworkMask_StaticRoutes_2() {
			return networkMask_StaticRoutes_2;
		}

		public void setNetworkMask_StaticRoutes_2(String networkMask_StaticRoutes_2) {
			this.networkMask_StaticRoutes_2 = networkMask_StaticRoutes_2;
		}

		public String getLanNxt_HopIP_forstaticroute_2() {
			return lanNxt_HopIP_forstaticroute_2;
		}

		public void setLanNxt_HopIP_forstaticroute_2(String lanNxt_HopIP_forstaticroute_2) {
			this.lanNxt_HopIP_forstaticroute_2 = lanNxt_HopIP_forstaticroute_2;
		}

		public String getNetworkIPs_StaticRoutes_3() {
			return networkIPs_StaticRoutes_3;
		}

		public void setNetworkIPs_StaticRoutes_3(String networkIPs_StaticRoutes_3) {
			this.networkIPs_StaticRoutes_3 = networkIPs_StaticRoutes_3;
		}

		public String getNetworkMask_StaticRoutes_3() {
			return networkMask_StaticRoutes_3;
		}

		public void setNetworkMask_StaticRoutes_3(String networkMask_StaticRoutes_3) {
			this.networkMask_StaticRoutes_3 = networkMask_StaticRoutes_3;
		}

		public String getLanNxt_HopIP_forstaticroute_3() {
			return lanNxt_HopIP_forstaticroute_3;
		}

		public void setLanNxt_HopIP_forstaticroute_3(String lanNxt_HopIP_forstaticroute_3) {
			this.lanNxt_HopIP_forstaticroute_3 = lanNxt_HopIP_forstaticroute_3;
		}

		public String getNetworkIPs_StaticRoutes_4() {
			return networkIPs_StaticRoutes_4;
		}

		public void setNetworkIPs_StaticRoutes_4(String networkIPs_StaticRoutes_4) {
			this.networkIPs_StaticRoutes_4 = networkIPs_StaticRoutes_4;
		}

		public String getNetworkMask_StaticRoutes_4() {
			return networkMask_StaticRoutes_4;
		}

		public void setNetworkMask_StaticRoutes_4(String networkMask_StaticRoutes_4) {
			this.networkMask_StaticRoutes_4 = networkMask_StaticRoutes_4;
		}

		public String getLanNxt_HopIP_forstaticroute_4() {
			return lanNxt_HopIP_forstaticroute_4;
		}

		public void setLanNxt_HopIP_forstaticroute_4(String lanNxt_HopIP_forstaticroute_4) {
			this.lanNxt_HopIP_forstaticroute_4 = lanNxt_HopIP_forstaticroute_4;
		}

		public String getNetworkIPs_StaticRoutes_5() {
			return networkIPs_StaticRoutes_5;
		}

		public void setNetworkIPs_StaticRoutes_5(String networkIPs_StaticRoutes_5) {
			this.networkIPs_StaticRoutes_5 = networkIPs_StaticRoutes_5;
		}

		public String getNetworkMask_StaticRoutes_5() {
			return networkMask_StaticRoutes_5;
		}

		public void setNetworkMask_StaticRoutes_5(String networkMask_StaticRoutes_5) {
			this.networkMask_StaticRoutes_5 = networkMask_StaticRoutes_5;
		}

		public String getLanNxt_HopIP_forstaticroute_5() {
			return lanNxt_HopIP_forstaticroute_5;
		}

		public void setLanNxt_HopIP_forstaticroute_5(String lanNxt_HopIP_forstaticroute_5) {
			this.lanNxt_HopIP_forstaticroute_5 = lanNxt_HopIP_forstaticroute_5;
		}

		public String getProj_lead_first_name() {
			return proj_lead_first_name;
		}

		public void setProj_lead_first_name(String proj_lead_first_name) {
			this.proj_lead_first_name = proj_lead_first_name;
		}

		public String getProj_lead_last_name() {
			return proj_lead_last_name;
		}

		public void setProj_lead_last_name(String proj_lead_last_name) {
			this.proj_lead_last_name = proj_lead_last_name;
		}

		public String getProj_coord_first_name() {
			return proj_coord_first_name;
		}

		public void setProj_coord_first_name(String proj_coord_first_name) {
			this.proj_coord_first_name = proj_coord_first_name;
		}

		public String getProj_cord_last_name() {
			return proj_cord_last_name;
		}

		public void setProj_cord_last_name(String proj_cord_last_name) {
			this.proj_cord_last_name = proj_cord_last_name;
		}

		public String getClassic_order_create_date_2() {
			return classic_order_create_date_2;
		}

		public void setClassic_order_create_date_2(String classic_order_create_date_2) {
			this.classic_order_create_date_2 = classic_order_create_date_2;
		}

		public String getKpi_ccd() {
			return kpi_ccd;
		}

		public void setKpi_ccd(String kpi_ccd) {
			this.kpi_ccd = kpi_ccd;
		}

		public String getKpi_crd() {
			return kpi_crd;
		}

		public void setKpi_crd(String kpi_crd) {
			this.kpi_crd = kpi_crd;
		}

		public String getKpi_icd() {
			return kpi_icd;
		}

		public void setKpi_icd(String kpi_icd) {
			this.kpi_icd = kpi_icd;
		}

		public String getKpi_schedule_install() {
			return kpi_schedule_install;
		}

		public void setKpi_schedule_install(String kpi_schedule_install) {
			this.kpi_schedule_install = kpi_schedule_install;
		}

		public String getProd_status() {
			return prod_status;
		}

		public void setProd_status(String prod_status) {
			this.prod_status = prod_status;
		}

		public String getInstallDate() {
			return installDate;
		}

		public void setInstallDate(String installDate) {
			this.installDate = installDate;
		}

		public String getAccOrdRaisedbyBTwithSuppDate() {
			return accOrdRaisedbyBTwithSuppDate;
		}

		public void setAccOrdRaisedbyBTwithSuppDate(String accOrdRaisedbyBTwithSuppDate) {
			this.accOrdRaisedbyBTwithSuppDate = accOrdRaisedbyBTwithSuppDate;
		}

		public String getAccSuppInstallCompleteDate() {
			return accSuppInstallCompleteDate;
		}

		public void setAccSuppInstallCompleteDate(String accSuppInstallCompleteDate) {
			this.accSuppInstallCompleteDate = accSuppInstallCompleteDate;
		}

		public String getAccSuppCommitDeliveryDate() {
			return accSuppCommitDeliveryDate;
		}

		public void setAccSuppCommitDeliveryDate(String accSuppCommitDeliveryDate) {
			this.accSuppCommitDeliveryDate = accSuppCommitDeliveryDate;
		}

		public String getAccSuppOrderApprovedDate() {
			return accSuppOrderApprovedDate;
		}

		public void setAccSuppOrderApprovedDate(String accSuppOrderApprovedDate) {
			this.accSuppOrderApprovedDate = accSuppOrderApprovedDate;
		}

		public String getAcccircrequiredbydate() {
			return acccircrequiredbydate;
		}

		public void setAcccircrequiredbydate(String acccircrequiredbydate) {
			this.acccircrequiredbydate = acccircrequiredbydate;
		}

		public String getDateAccSuppadvBTofAcCompletion() {
			return dateAccSuppadvBTofAcCompletion;
		}

		public void setDateAccSuppadvBTofAcCompletion(String dateAccSuppadvBTofAcCompletion) {
			this.dateAccSuppadvBTofAcCompletion = dateAccSuppadvBTofAcCompletion;
		}

		public String getDateAccSuppInformBTofCmtDelDt() {
			return dateAccSuppInformBTofCmtDelDt;
		}

		public void setDateAccSuppInformBTofCmtDelDt(String dateAccSuppInformBTofCmtDelDt) {
			this.dateAccSuppInformBTofCmtDelDt = dateAccSuppInformBTofCmtDelDt;
		}

		public String getDateOrderRcvdwiththeAccSupp() {
			return dateOrderRcvdwiththeAccSupp;
		}

		public void setDateOrderRcvdwiththeAccSupp(String dateOrderRcvdwiththeAccSupp) {
			this.dateOrderRcvdwiththeAccSupp = dateOrderRcvdwiththeAccSupp;
		}

		public String getCpe_actualInstallationDate() {
			return cpe_actualInstallationDate;
		}

		public void setCpe_actualInstallationDate(String cpe_actualInstallationDate) {
			this.cpe_actualInstallationDate = cpe_actualInstallationDate;
		}

		public String getCpe_dateOrdRaisedbyBTwithSupp() {
			return cpe_dateOrdRaisedbyBTwithSupp;
		}

		public void setCpe_dateOrdRaisedbyBTwithSupp(String cpe_dateOrdRaisedbyBTwithSupp) {
			this.cpe_dateOrdRaisedbyBTwithSupp = cpe_dateOrdRaisedbyBTwithSupp;
		}

		public String getCpe_deliveredtoSiteDate() {
			return cpe_deliveredtoSiteDate;
		}

		public void setCpe_deliveredtoSiteDate(String cpe_deliveredtoSiteDate) {
			this.cpe_deliveredtoSiteDate = cpe_deliveredtoSiteDate;
		}

		public String getCpe_plannedInstallationDate() {
			return cpe_plannedInstallationDate;
		}

		public void setCpe_plannedInstallationDate(String cpe_plannedInstallationDate) {
			this.cpe_plannedInstallationDate = cpe_plannedInstallationDate;
		}

		public String getPreRTTDatGatIVsrBsCnfAmplfrbRt() {
			return preRTTDatGatIVsrBsCnfAmplfrbRt;
		}

		public void setPreRTTDatGatIVsrBsCnfAmplfrbRt(String preRTTDatGatIVsrBsCnfAmplfrbRt) {
			this.preRTTDatGatIVsrBsCnfAmplfrbRt = preRTTDatGatIVsrBsCnfAmplfrbRt;
		}

		public String getRttce_instAndFinCnfLdAmpfrbOrng() {
			return rttce_instAndFinCnfLdAmpfrbOrng;
		}

		public void setRttce_instAndFinCnfLdAmpfrbOrng(String rttce_instAndFinCnfLdAmpfrbOrng) {
			this.rttce_instAndFinCnfLdAmpfrbOrng = rttce_instAndFinCnfLdAmpfrbOrng;
		}

		public String getMigration_Ampelfarbe_Gelb() {
			return migration_Ampelfarbe_Gelb;
		}

		public void setMigration_Ampelfarbe_Gelb(String migration_Ampelfarbe_Gelb) {
			this.migration_Ampelfarbe_Gelb = migration_Ampelfarbe_Gelb;
		}

		public String getMonitoring_Ampelfarbe_Green_ID() {
			return monitoring_Ampelfarbe_Green_ID;
		}

		public void setMonitoring_Ampelfarbe_Green_ID(String monitoring_Ampelfarbe_Green_ID) {
			this.monitoring_Ampelfarbe_Green_ID = monitoring_Ampelfarbe_Green_ID;
		}

		public String getChange_id() {
			return change_id;
		}

		public void setChange_id(String change_id) {
			this.change_id = change_id;
		}

		public String getInsert_date() {
			return insert_date;
		}

		public void setInsert_date(String insert_date) {
			this.insert_date = insert_date;
		}

		public String getTimestamp() {
			return timestamp;
		}

		public void setTimestamp(String timestamp) {
			this.timestamp = timestamp;
		}

		public String getCct_pri_sec() {
			return cct_pri_sec;
		}

		public void setCct_pri_sec(String cct_pri_sec) {
			this.cct_pri_sec = cct_pri_sec;
		}

		public String get_1_LAN_Helper_1() {
			return _1_LAN_Helper_1;
		}

		public void set_1_LAN_Helper_1(String _1_LAN_Helper_1) {
			this._1_LAN_Helper_1 = _1_LAN_Helper_1;
		}

		public String get_1_LAN_Helper_2() {
			return _1_LAN_Helper_2;
		}

		public void set_1_LAN_Helper_2(String _1_LAN_Helper_2) {
			this._1_LAN_Helper_2 = _1_LAN_Helper_2;
		}

		public String get_1_NEXT_HOP_INTERFACE() {
			return _1_NEXT_HOP_INTERFACE;
		}

		public void set_1_NEXT_HOP_INTERFACE(String _1_NEXT_HOP_INTERFACE) {
			this._1_NEXT_HOP_INTERFACE = _1_NEXT_HOP_INTERFACE;
		}

		public String get_2_LAN_Helper_1() {
			return _2_LAN_Helper_1;
		}

		public void set_2_LAN_Helper_1(String _2_LAN_Helper_1) {
			this._2_LAN_Helper_1 = _2_LAN_Helper_1;
		}

		public String get_2_LAN_Helper_2() {
			return _2_LAN_Helper_2;
		}

		public void set_2_LAN_Helper_2(String _2_LAN_Helper_2) {
			this._2_LAN_Helper_2 = _2_LAN_Helper_2;
		}

		public String get_2_NEXT_HOP_INTERFACE() {
			return _2_NEXT_HOP_INTERFACE;
		}

		public void set_2_NEXT_HOP_INTERFACE(String _2_NEXT_HOP_INTERFACE) {
			this._2_NEXT_HOP_INTERFACE = _2_NEXT_HOP_INTERFACE;
		}

		public String get_3_LAN_Helper_1() {
			return _3_LAN_Helper_1;
		}

		public void set_3_LAN_Helper_1(String _3_LAN_Helper_1) {
			this._3_LAN_Helper_1 = _3_LAN_Helper_1;
		}

		public String get_3_LAN_Helper_2() {
			return _3_LAN_Helper_2;
		}

		public void set_3_LAN_Helper_2(String _3_LAN_Helper_2) {
			this._3_LAN_Helper_2 = _3_LAN_Helper_2;
		}

		public String get_3_NEXT_HOP_INTERFACE() {
			return _3_NEXT_HOP_INTERFACE;
		}

		public void set_3_NEXT_HOP_INTERFACE(String _3_NEXT_HOP_INTERFACE) {
			this._3_NEXT_HOP_INTERFACE = _3_NEXT_HOP_INTERFACE;
		}

		public String get_4_NEXT_HOP_INTERFACE() {
			return _4_NEXT_HOP_INTERFACE;
		}

		public void set_4_NEXT_HOP_INTERFACE(String _4_NEXT_HOP_INTERFACE) {
			this._4_NEXT_HOP_INTERFACE = _4_NEXT_HOP_INTERFACE;
		}

		public String getAccBeaCircNTEFram_Str_CustEn() {
			return accBeaCircNTEFram_Str_CustEn;
		}

		public void setAccBeaCircNTEFram_Str_CustEn(String accBeaCircNTEFram_Str_CustEn) {
			this.accBeaCircNTEFram_Str_CustEn = accBeaCircNTEFram_Str_CustEn;
		}

		public String getAccess_Model() {
			return access_Model;
		}

		public void setAccess_Model(String access_Model) {
			this.access_Model = access_Model;
		}

		public String getCe_vci() {
			return ce_vci;
		}

		public void setCe_vci(String ce_vci) {
			this.ce_vci = ce_vci;
		}

		public String getCe_vpi() {
			return ce_vpi;
		}

		public void setCe_vpi(String ce_vpi) {
			this.ce_vpi = ce_vpi;
		}

		public String getEmpty_line() {
			return empty_line;
		}

		public void setEmpty_line(String empty_line) {
			this.empty_line = empty_line;
		}

		public String getPe_vci() {
			return pe_vci;
		}

		public void setPe_vci(String pe_vci) {
			this.pe_vci = pe_vci;
		}

		public String getPe_vpi() {
			return pe_vpi;
		}

		public void setPe_vpi(String pe_vpi) {
			this.pe_vpi = pe_vpi;
		}

		public String getProject_Manager_Phone() {
			return project_Manager_Phone;
		}

		public void setProject_Manager_Phone(String project_Manager_Phone) {
			this.project_Manager_Phone = project_Manager_Phone;
		}

		public String getSnmp_community() {
			return snmp_community;
		}

		public void setSnmp_community(String snmp_community) {
			this.snmp_community = snmp_community;
		}

		public String getSnmp_read_access() {
			return snmp_read_access;
		}

		public void setSnmp_read_access(String snmp_read_access) {
			this.snmp_read_access = snmp_read_access;
		}

		public String getSnmp_server_ip_1() {
			return snmp_server_ip_1;
		}

		public void setSnmp_server_ip_1(String snmp_server_ip_1) {
			this.snmp_server_ip_1 = snmp_server_ip_1;
		}

		public String getSnmp_server_ip_2() {
			return snmp_server_ip_2;
		}

		public void setSnmp_server_ip_2(String snmp_server_ip_2) {
			this.snmp_server_ip_2 = snmp_server_ip_2;
		}

		public String getSnmp_server_mask_1() {
			return snmp_server_mask_1;
		}

		public void setSnmp_server_mask_1(String snmp_server_mask_1) {
			this.snmp_server_mask_1 = snmp_server_mask_1;
		}

		public String getSnmp_server_mask_2() {
			return snmp_server_mask_2;
		}

		public void setSnmp_server_mask_2(String snmp_server_mask_2) {
			this.snmp_server_mask_2 = snmp_server_mask_2;
		}

		public String getSnr_extension() {
			return snr_extension;
		}

		public void setSnr_extension(String snr_extension) {
			this.snr_extension = snr_extension;
		}

		public String getxDSL_Downstream_bandwidth() {
			return xDSL_Downstream_bandwidth;
		}

		public void setxDSL_Downstream_bandwidth(String xDSL_Downstream_bandwidth) {
			this.xDSL_Downstream_bandwidth = xDSL_Downstream_bandwidth;
		}

		public String getxDSL_NTE_Framing_Structure() {
			return xDSL_NTE_Framing_Structure;
		}

		public void setxDSL_NTE_Framing_Structure(String xDSL_NTE_Framing_Structure) {
			this.xDSL_NTE_Framing_Structure = xDSL_NTE_Framing_Structure;
		}

		public String getxDSL_Type() {
			return xDSL_Type;
		}

		public void setxDSL_Type(String xDSL_Type) {
			this.xDSL_Type = xDSL_Type;
		}

		public String getAccBeaCirNTEOp_ElctrIntTyp_CuE() {
			return accBeaCirNTEOp_ElctrIntTyp_CuE;
		}

		public void setAccBeaCirNTEOp_ElctrIntTyp_CuE(String accBeaCirNTEOp_ElctrIntTyp_CuE) {
			this.accBeaCirNTEOp_ElctrIntTyp_CuE = accBeaCirNTEOp_ElctrIntTyp_CuE;
		}

		public String getNext_hop_interface_5() {
			return next_hop_interface_5;
		}

		public void setNext_hop_interface_5(String next_hop_interface_5) {
			this.next_hop_interface_5 = next_hop_interface_5;
		}

		public String getEmpty_field() {
			return empty_field;
		}

		public void setEmpty_field(String empty_field) {
			this.empty_field = empty_field;
		}

		public String getGlobal_m1400_circuit_id() {
			return global_m1400_circuit_id;
		}

		public void setGlobal_m1400_circuit_id(String global_m1400_circuit_id) {
			this.global_m1400_circuit_id = global_m1400_circuit_id;
		}

		public String getPpp_hostname() {
			return ppp_hostname;
		}

		public void setPpp_hostname(String ppp_hostname) {
			this.ppp_hostname = ppp_hostname;
		}

		public String getPpp_password() {
			return ppp_password;
		}

		public void setPpp_password(String ppp_password) {
			this.ppp_password = ppp_password;
		}

		public String getPe_vlan() {
			return pe_vlan;
		}

		public void setPe_vlan(String pe_vlan) {
			this.pe_vlan = pe_vlan;
		}

		public String getDownload_speed() {
			return download_speed;
		}

		public void setDownload_speed(String download_speed) {
			this.download_speed = download_speed;
		}

		public String getUpload_speed() {
			return upload_speed;
		}

		public void setUpload_speed(String upload_speed) {
			this.upload_speed = upload_speed;
		}

		public String getIpSec_password() {
			return ipSec_password;
		}

		public void setIpSec_password(String ipSec_password) {
			this.ipSec_password = ipSec_password;
		}

		public String getIpSec_username() {
			return ipSec_username;
		}

		public void setIpSec_username(String ipSec_username) {
			this.ipSec_username = ipSec_username;
		}

		public String getIpSecGroupKey() {
			return ipSecGroupKey;
		}

		public void setIpSecGroupKey(String ipSecGroupKey) {
			this.ipSecGroupKey = ipSecGroupKey;
		}

		public String getWanInterfaceMAC() {
			return wanInterfaceMAC;
		}

		public void setWanInterfaceMAC(String wanInterfaceMAC) {
			this.wanInterfaceMAC = wanInterfaceMAC;
		}

		public String getSite_state() {
			return site_state;
		}

		public void setSite_state(String site_state) {
			this.site_state = site_state;
		}

		public String getPe_vpivci() {
			return pe_vpivci;
		}

		public void setPe_vpivci(String pe_vpivci) {
			this.pe_vpivci = pe_vpivci;
		}

		public String getNetworkWilds_staticRoutes_1() {
			return networkWilds_staticRoutes_1;
		}

		public void setNetworkWilds_staticRoutes_1(String networkWilds_staticRoutes_1) {
			this.networkWilds_staticRoutes_1 = networkWilds_staticRoutes_1;
		}

		public String getNetworkWilds_staticRoutes_2() {
			return networkWilds_staticRoutes_2;
		}

		public void setNetworkWilds_staticRoutes_2(String networkWilds_staticRoutes_2) {
			this.networkWilds_staticRoutes_2 = networkWilds_staticRoutes_2;
		}

		public String getNetworkWilds_staticRoutes_3() {
			return networkWilds_staticRoutes_3;
		}

		public void setNetworkWilds_staticRoutes_3(String networkWilds_staticRoutes_3) {
			this.networkWilds_staticRoutes_3 = networkWilds_staticRoutes_3;
		}

		public String getNotes() {
			return notes;
		}

		public void setNotes(String notes) {
			this.notes = notes;
		}

		public String getIc_id() {
			return ic_id;
		}

		public void setIc_id(String ic_id) {
			this.ic_id = ic_id;
		}

		public String getSc_id() {
			return sc_id;
		}

		public void setSc_id(String sc_id) {
			this.sc_id = sc_id;
		}

		public String getProduct_id() {
			return product_id;
		}

		public void setProduct_id(String product_id) {
			this.product_id = product_id;
		}

		public String getRouter_id() {
			return router_id;
		}

		public void setRouter_id(String router_id) {
			this.router_id = router_id;
		}

		public String getIc_name() {
			return ic_name;
		}

		public void setIc_name(String ic_name) {
			this.ic_name = ic_name;
		}

		public String getNetworkWilds_staticRoutes_4() {
			return networkWilds_staticRoutes_4;
		}

		public void setNetworkWilds_staticRoutes_4(String networkWilds_staticRoutes_4) {
			this.networkWilds_staticRoutes_4 = networkWilds_staticRoutes_4;
		}

		public String getNetworkWilds_staticRoutes_5() {
			return networkWilds_staticRoutes_5;
		}

		public void setNetworkWilds_staticRoutes_5(String networkWilds_staticRoutes_5) {
			this.networkWilds_staticRoutes_5 = networkWilds_staticRoutes_5;
		}

		public String getLink_order_no() {
			return link_order_no;
		}

		public void setLink_order_no(String link_order_no) {
			this.link_order_no = link_order_no;
		}

		public String getTelnet_host1() {
			return telnet_host1;
		}

		public void setTelnet_host1(String telnet_host1) {
			this.telnet_host1 = telnet_host1;
		}

		public String getxDSL_Upstream_bandwidth() {
			return xDSL_Upstream_bandwidth;
		}

		public void setxDSL_Upstream_bandwidth(String xDSL_Upstream_bandwidth) {
			this.xDSL_Upstream_bandwidth = xDSL_Upstream_bandwidth;
		}

		public String getOob_mngmtNr() {
			return oob_mngmtNr;
		}

		public void setOob_mngmtNr(String oob_mngmtNr) {
			this.oob_mngmtNr = oob_mngmtNr;
		}

		public String getMonitoringSystem() {
			return monitoringSystem;
		}

		public void setMonitoringSystem(String monitoringSystem) {
			this.monitoringSystem = monitoringSystem;
		}

		public String getNon_Classic_OrderNr() {
			return non_Classic_OrderNr;
		}

		public void setNon_Classic_OrderNr(String non_Classic_OrderNr) {
			this.non_Classic_OrderNr = non_Classic_OrderNr;
		}

		public String getCoSClassificationType() {
			return coSClassificationType;
		}

		public void setCoSClassificationType(String coSClassificationType) {
			this.coSClassificationType = coSClassificationType;
		}

		public String getPe_supportRequest() {
			return pe_supportRequest;
		}

		public void setPe_supportRequest(String pe_supportRequest) {
			this.pe_supportRequest = pe_supportRequest;
		}

		public String getAcn_design_code() {
			return acn_design_code;
		}

		public void setAcn_design_code(String acn_design_code) {
			this.acn_design_code = acn_design_code;
		}

		public String getPe_dlci() {
			return pe_dlci;
		}

		public void setPe_dlci(String pe_dlci) {
			this.pe_dlci = pe_dlci;
		}

		public String getTest_new_field() {
			return test_new_field;
		}

		public void setTest_new_field(String test_new_field) {
			this.test_new_field = test_new_field;
		}

		public String getGpop_node_id() {
			return gpop_node_id;
		}

		public void setGpop_node_id(String gpop_node_id) {
			this.gpop_node_id = gpop_node_id;
		}

		public String getGpop_node_address() {
			return gpop_node_address;
		}

		public void setGpop_node_address(String gpop_node_address) {
			this.gpop_node_address = gpop_node_address;
		}

		public String getAccessType() {
			return accessType;
		}

		public void setAccessType(String accessType) {
			this.accessType = accessType;
		}

		public String getServiceVariant() {
			return serviceVariant;
		}

		public void setServiceVariant(String serviceVariant) {
			this.serviceVariant = serviceVariant;
		}

		public String getIpv6_Mngmt_Loopback_IPAddress() {
			return ipv6_Mngmt_Loopback_IPAddress;
		}

		public void setIpv6_Mngmt_Loopback_IPAddress(String ipv6_Mngmt_Loopback_IPAddress) {
			this.ipv6_Mngmt_Loopback_IPAddress = ipv6_Mngmt_Loopback_IPAddress;
		}

		public String getIpv6_PEP2PIP() {
			return ipv6_PEP2PIP;
		}

		public void setIpv6_PEP2PIP(String ipv6_PEP2PIP) {
			this.ipv6_PEP2PIP = ipv6_PEP2PIP;
		}

		public String getIpv6_CEP2PIP() {
			return ipv6_CEP2PIP;
		}

		public void setIpv6_CEP2PIP(String ipv6_CEP2PIP) {
			this.ipv6_CEP2PIP = ipv6_CEP2PIP;
		}

		public String getIpv6_PE_Loopback200_IP() {
			return ipv6_PE_Loopback200_IP;
		}

		public void setIpv6_PE_Loopback200_IP(String ipv6_PE_Loopback200_IP) {
			this.ipv6_PE_Loopback200_IP = ipv6_PE_Loopback200_IP;
		}

		public String getIpv6_1_LANInterface() {
			return ipv6_1_LANInterface;
		}

		public void setIpv6_1_LANInterface(String ipv6_1_LANInterface) {
			this.ipv6_1_LANInterface = ipv6_1_LANInterface;
		}

		public String getIpv6_1_LANIP() {
			return ipv6_1_LANIP;
		}

		public void setIpv6_1_LANIP(String ipv6_1_LANIP) {
			this.ipv6_1_LANIP = ipv6_1_LANIP;
		}

		public String getIpv6_1_LANMask_Lengh() {
			return ipv6_1_LANMask_Lengh;
		}

		public void setIpv6_1_LANMask_Lengh(String ipv6_1_LANMask_Lengh) {
			this.ipv6_1_LANMask_Lengh = ipv6_1_LANMask_Lengh;
		}

		public String getIpv6_1_VirtualIP() {
			return ipv6_1_VirtualIP;
		}

		public void setIpv6_1_VirtualIP(String ipv6_1_VirtualIP) {
			this.ipv6_1_VirtualIP = ipv6_1_VirtualIP;
		}

		public String getIpv6_1_LANPort() {
			return ipv6_1_LANPort;
		}

		public void setIpv6_1_LANPort(String ipv6_1_LANPort) {
			this.ipv6_1_LANPort = ipv6_1_LANPort;
		}

		public String getIpv6_1_LANSubNet() {
			return ipv6_1_LANSubNet;
		}

		public void setIpv6_1_LANSubNet(String ipv6_1_LANSubNet) {
			this.ipv6_1_LANSubNet = ipv6_1_LANSubNet;
		}

		public String getIpv6_1_LANWildcardMask() {
			return ipv6_1_LANWildcardMask;
		}

		public void setIpv6_1_LANWildcardMask(String ipv6_1_LANWildcardMask) {
			this.ipv6_1_LANWildcardMask = ipv6_1_LANWildcardMask;
		}

		public String getIpv6_1_LAN_Helper_1() {
			return ipv6_1_LAN_Helper_1;
		}

		public void setIpv6_1_LAN_Helper_1(String ipv6_1_LAN_Helper_1) {
			this.ipv6_1_LAN_Helper_1 = ipv6_1_LAN_Helper_1;
		}

		public String getIpv6_1_LAN_Helper_2() {
			return ipv6_1_LAN_Helper_2;
		}

		public void setIpv6_1_LAN_Helper_2(String ipv6_1_LAN_Helper_2) {
			this.ipv6_1_LAN_Helper_2 = ipv6_1_LAN_Helper_2;
		}

		public String getVpn_connection_ip_versions() {
			return vpn_connection_ip_versions;
		}

		public void setVpn_connection_ip_versions(String vpn_connection_ip_versions) {
			this.vpn_connection_ip_versions = vpn_connection_ip_versions;
		}

		public String getCustomer_vpn_id() {
			return customer_vpn_id;
		}

		public void setCustomer_vpn_id(String customer_vpn_id) {
			this.customer_vpn_id = customer_vpn_id;
		}

		public String getCustomer_vpn_index() {
			return customer_vpn_index;
		}

		public void setCustomer_vpn_index(String customer_vpn_index) {
			this.customer_vpn_index = customer_vpn_index;
		}

		public String getVpn_connectivity_Mode() {
			return vpn_connectivity_Mode;
		}

		public void setVpn_connectivity_Mode(String vpn_connectivity_Mode) {
			this.vpn_connectivity_Mode = vpn_connectivity_Mode;
		}

		public String getBgp_maximum_prefix_range_name() {
			return bgp_maximum_prefix_range_name;
		}

		public void setBgp_maximum_prefix_range_name(String bgp_maximum_prefix_range_name) {
			this.bgp_maximum_prefix_range_name = bgp_maximum_prefix_range_name;
		}

		public String getBgp_max_prefix_range_name_ipv6() {
			return bgp_max_prefix_range_name_ipv6;
		}

		public void setBgp_max_prefix_range_name_ipv6(String bgp_max_prefix_range_name_ipv6) {
			this.bgp_max_prefix_range_name_ipv6 = bgp_max_prefix_range_name_ipv6;
		}

		public String getService_ownership() {
			return service_ownership;
		}

		public void setService_ownership(String service_ownership) {
			this.service_ownership = service_ownership;
		}

		public String getService_objid() {
			return service_objid;
		}

		public void setService_objid(String service_objid) {
			this.service_objid = service_objid;
		}

		public String getVpn_connection_type_extranet() {
			return vpn_connection_type_extranet;
		}

		public void setVpn_connection_type_extranet(String vpn_connection_type_extranet) {
			this.vpn_connection_type_extranet = vpn_connection_type_extranet;
		}

		public String getVpn_connection_type_enterprise() {
			return vpn_connection_type_enterprise;
		}

		public void setVpn_connection_type_enterprise(String vpn_connection_type_enterprise) {
			this.vpn_connection_type_enterprise = vpn_connection_type_enterprise;
		}

		public String getMulticast_services() {
			return multicast_services;
		}

		public void setMulticast_services(String multicast_services) {
			this.multicast_services = multicast_services;
		}

		public String getBt_sub_order_type() {
			return bt_sub_order_type;
		}

		public void setBt_sub_order_type(String bt_sub_order_type) {
			this.bt_sub_order_type = bt_sub_order_type;
		}

		public String getComSpecActivationFlag() {
			return comSpecActivationFlag;
		}

		public void setComSpecActivationFlag(String comSpecActivationFlag) {
			this.comSpecActivationFlag = comSpecActivationFlag;
		}

		public String getService_Name() {
			return service_Name;
		}

		public void setService_Name(String service_Name) {
			this.service_Name = service_Name;
		}

		public String getClassic_order_title() {
			return classic_order_title;
		}

		public void setClassic_order_title(String classic_order_title) {
			this.classic_order_title = classic_order_title;
		}

		public String getHybrid_vpn() {
			return hybrid_vpn;
		}

		public void setHybrid_vpn(String hybrid_vpn) {
			this.hybrid_vpn = hybrid_vpn;
		}

		public String getAccess_technology() {
			return access_technology;
		}

		public void setAccess_technology(String access_technology) {
			this.access_technology = access_technology;
		}

		public String getManagementType() {
			return managementType;
		}

		public void setManagementType(String managementType) {
			this.managementType = managementType;
		}

		public String getFull_service_CPETest_schd_date() {
			return full_service_CPETest_schd_date;
		}

		public void setFull_service_CPETest_schd_date(String full_service_CPETest_schd_date) {
			this.full_service_CPETest_schd_date = full_service_CPETest_schd_date;
		}

		public String getOn_site_cpe_connTest_schd_date() {
			return on_site_cpe_connTest_schd_date;
		}

		public void setOn_site_cpe_connTest_schd_date(String on_site_cpe_connTest_schd_date) {
			this.on_site_cpe_connTest_schd_date = on_site_cpe_connTest_schd_date;
		}

		public String getModifyType() {
			return modifyType;
		}

		public void setModifyType(String modifyType) {
			this.modifyType = modifyType;
		}
		

}
