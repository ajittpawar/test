/**
 * 
 */
package com.bt.nga.jsonBean;

/**
 * @author Ajit Pawar
 *
 */
public class CustWanDetails {

	private String   interFace;
	private String   port;
	private String   vlanId;
	private String   interfaceIp;
	private String   mask;
	private String   nextHop;
	private String   husbIp;
	private String   spokeIp;
	private String   sharedKey;
	private String   pe_Ip;
	private String   ce_Ip ;
	private String   ce_Vpi ;
	private String   ce_Vci;
	private String   ppp_host;
	private String   ppp_passwd;
	private String   dwld_speed;
	private String   upld_speed;
	private String   ipSec_Passwd;
	private String   ipSec_Usr;
	private String   ipSec_GKey;
	private String   mac_Address;
	private String   ipV6_PE_IP;
	private String   ipV6_CE_IP;

	public CustWanDetails() {
		// TODO Auto-generated constructor stub
	}

	public CustWanDetails(String interFace, String port, String vlanId, String interfaceIp, String mask, String nextHop,
			String husbIp, String spokeIp, String sharedKey, String pe_Ip, String ce_Ip, String ce_Vpi, String ce_Vci,
			String ppp_host, String ppp_passwd, String dwld_speed, String upld_speed, String ipSec_Passwd,
			String ipSec_Usr, String ipSec_GKey, String mac_Address, String ipV6_PE_IP, String ipV6_CE_IP) {
		super();
		this.interFace = interFace;
		this.port = port;
		this.vlanId = vlanId;
		this.interfaceIp = interfaceIp;
		this.mask = mask;
		this.nextHop = nextHop;
		this.husbIp = husbIp;
		this.spokeIp = spokeIp;
		this.sharedKey = sharedKey;
		this.pe_Ip = pe_Ip;
		this.ce_Ip = ce_Ip;
		this.ce_Vpi = ce_Vpi;
		this.ce_Vci = ce_Vci;
		this.ppp_host = ppp_host;
		this.ppp_passwd = ppp_passwd;
		this.dwld_speed = dwld_speed;
		this.upld_speed = upld_speed;
		this.ipSec_Passwd = ipSec_Passwd;
		this.ipSec_Usr = ipSec_Usr;
		this.ipSec_GKey = ipSec_GKey;
		this.mac_Address = mac_Address;
		this.ipV6_PE_IP = ipV6_PE_IP;
		this.ipV6_CE_IP = ipV6_CE_IP;
	}

	public String getInterFace() {
		return interFace;
	}

	public void setInterFace(String interFace) {
		this.interFace = interFace;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getVlanId() {
		return vlanId;
	}

	public void setVlanId(String vlanId) {
		this.vlanId = vlanId;
	}

	public String getInterfaceIp() {
		return interfaceIp;
	}

	public void setInterfaceIp(String interfaceIp) {
		this.interfaceIp = interfaceIp;
	}

	public String getMask() {
		return mask;
	}

	public void setMask(String mask) {
		this.mask = mask;
	}

	public String getNextHop() {
		return nextHop;
	}

	public void setNextHop(String nextHop) {
		this.nextHop = nextHop;
	}

	public String getHusbIp() {
		return husbIp;
	}

	public void setHusbIp(String husbIp) {
		this.husbIp = husbIp;
	}

	public String getSpokeIp() {
		return spokeIp;
	}

	public void setSpokeIp(String spokeIp) {
		this.spokeIp = spokeIp;
	}

	public String getSharedKey() {
		return sharedKey;
	}

	public void setSharedKey(String sharedKey) {
		this.sharedKey = sharedKey;
	}

	public String getPe_Ip() {
		return pe_Ip;
	}

	public void setPe_Ip(String pe_Ip) {
		this.pe_Ip = pe_Ip;
	}

	public String getCe_Ip() {
		return ce_Ip;
	}

	public void setCe_Ip(String ce_Ip) {
		this.ce_Ip = ce_Ip;
	}

	public String getCe_Vpi() {
		return ce_Vpi;
	}

	public void setCe_Vpi(String ce_Vpi) {
		this.ce_Vpi = ce_Vpi;
	}

	public String getCe_Vci() {
		return ce_Vci;
	}

	public void setCe_Vci(String ce_Vci) {
		this.ce_Vci = ce_Vci;
	}

	public String getPpp_host() {
		return ppp_host;
	}

	public void setPpp_host(String ppp_host) {
		this.ppp_host = ppp_host;
	}

	public String getPpp_passwd() {
		return ppp_passwd;
	}

	public void setPpp_passwd(String ppp_passwd) {
		this.ppp_passwd = ppp_passwd;
	}

	public String getDwld_speed() {
		return dwld_speed;
	}

	public void setDwld_speed(String dwld_speed) {
		this.dwld_speed = dwld_speed;
	}

	public String getUpld_speed() {
		return upld_speed;
	}

	public void setUpld_speed(String upld_speed) {
		this.upld_speed = upld_speed;
	}

	public String getIpSec_Passwd() {
		return ipSec_Passwd;
	}

	public void setIpSec_Passwd(String ipSec_Passwd) {
		this.ipSec_Passwd = ipSec_Passwd;
	}

	public String getIpSec_Usr() {
		return ipSec_Usr;
	}

	public void setIpSec_Usr(String ipSec_Usr) {
		this.ipSec_Usr = ipSec_Usr;
	}

	public String getIpSec_GKey() {
		return ipSec_GKey;
	}

	public void setIpSec_GKey(String ipSec_GKey) {
		this.ipSec_GKey = ipSec_GKey;
	}

	public String getMac_Address() {
		return mac_Address;
	}

	public void setMac_Address(String mac_Address) {
		this.mac_Address = mac_Address;
	}

	public String getIpV6_PE_IP() {
		return ipV6_PE_IP;
	}

	public void setIpV6_PE_IP(String ipV6_PE_IP) {
		this.ipV6_PE_IP = ipV6_PE_IP;
	}

	public String getIpV6_CE_IP() {
		return ipV6_CE_IP;
	}

	public void setIpV6_CE_IP(String ipV6_CE_IP) {
		this.ipV6_CE_IP = ipV6_CE_IP;
	}

}
