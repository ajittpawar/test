/**
 * 
 */
package com.bt.nga.util.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author Sagar Chavan
 * @aim To provide hibernate utilities	
 * @created Nov 29, 2016 
 * @modified Nov 29, 2016
 * @modified_by Sagar Chavan
 * @description 
 */
public class HibernateUtil {
	@Autowired
	private static SessionFactory sessionFactory;
	
	
	public static synchronized SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public Session openSession() {
		return sessionFactory.openSession();
	}


}
