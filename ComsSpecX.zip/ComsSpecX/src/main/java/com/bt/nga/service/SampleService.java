/**
 * 
 */
package com.bt.nga.service;

/**
 * @author Sagar Chavan
 * @aim 	
 * @created Nov 29, 2016 
 * @modified Nov 29, 2016
 * @modified_by Sagar Chavan
 * @description 
 */
public interface SampleService {
	/**
	 * @return the serviceName
	 */
	public String getServiceName();

	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName);
}
