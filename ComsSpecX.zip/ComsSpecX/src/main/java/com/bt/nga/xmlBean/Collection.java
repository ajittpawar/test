package com.bt.nga.xmlBean;

import javax.xml.bind.annotation.XmlAttribute;

public class Collection
{
    private String name;

    @XmlAttribute(name="type-id")
    private String typeId="string";

    private Attribute[] attribute;

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public Attribute[] getAttribute ()
    {
        return attribute;
    }

    public void setAttribute (Attribute[] attribute)
    {
        this.attribute = attribute;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [name = "+name+", typeId = "+typeId+", attribute = "+attribute+"]";
    }
}

