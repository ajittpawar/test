package com.bt.nga.config.app.test;


import java.io.IOException;

import org.springframework.web.client.RestTemplate;

import com.bt.nga.entity.SampleModel;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;   
/**  
 * @author Sagar Chavan  
 */  
public class SpringRestTemplateExample {   
	
		public static void main(String args[]) throws JsonParseException, JsonMappingException, IOException {   

	final String uri  = "http://10.54.9.198:61000/RTEJMSClientService/rte/trigger";   
	ObjectMapper mapper = new ObjectMapper();


	RestTemplate restTemplate = new RestTemplate();   
	String json ="";
	json = restTemplate.postForObject(uri,json, String.class);
	
	//SampleModel model =mapper.readValue(json, SampleModel.class);

	
	System.out.println("SampleModel Name:"+json);   

}   
		

}  

