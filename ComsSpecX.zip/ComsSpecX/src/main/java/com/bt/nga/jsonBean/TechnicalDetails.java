package com.bt.nga.jsonBean;

/**
 * @author Ajit Pawar
 *
 */
public class TechnicalDetails {
	private String service_no;
	private GeneralDetails general_info;
	private PEDetails pe_info;
	private AccessDetails access_info;
	private CPEDetails cpe_info;
	private COSDetails cos_info;
	private ISDNDetails isdn_bkup;
	//private CustLanDetails cust_lan;
	private StandardDetails std_info;
	private ReportingDetails reporting_info;
	private CustWanDetails cust_wan;
	private FinanceDetails finance_vertical;
	private FrFDetails frf_16_info;
		
	public TechnicalDetails() {
		
	}
	
	public TechnicalDetails(String service_no, GeneralDetails general_info, PEDetails pe_info,
			AccessDetails access_info, CPEDetails cpe_info, COSDetails cos_info, ISDNDetails isdn_bkup,
			StandardDetails std_info, ReportingDetails reporting_info, CustWanDetails cust_wan,
			FinanceDetails finance_vertical, FrFDetails frf_16_info) {
		super();
		this.service_no = service_no;
		this.general_info = general_info;
		this.pe_info = pe_info;
		this.access_info = access_info;
		this.cpe_info = cpe_info;
		this.cos_info = cos_info;
		this.isdn_bkup = isdn_bkup;
		//this.cust_lan = cust_lan;
		this.std_info = std_info;
		this.reporting_info = reporting_info;
		this.cust_wan = cust_wan;
		this.finance_vertical = finance_vertical;
		this.frf_16_info = frf_16_info;
	}

	public String getService_no() {
		return service_no;
	}
	public void setService_no(String service_no) {
		this.service_no = service_no;
	}

	public GeneralDetails getGeneral_info() {
		return general_info;
	}
	public void setGeneral_info(GeneralDetails general_info) {
		this.general_info = general_info;
	}

	public PEDetails getPe_info() {
		return pe_info;
	}
	public void setPe_info(PEDetails pe_info) {
		this.pe_info = pe_info;
	}

	public AccessDetails getAccess_info() {
		return access_info;
	}
	public void setAccess_info(AccessDetails access_info) {
		this.access_info = access_info;
	}

	public CPEDetails getCpe_info() {
		return cpe_info;
	}
	public void setCpe_info(CPEDetails cpe_info) {
		this.cpe_info = cpe_info;
	}

	public COSDetails getCos_info() {
		return cos_info;
	}
	public void setCos_info(COSDetails cos_info) {
		this.cos_info = cos_info;
	}

	public ISDNDetails getIsdn_bkup() {
		return isdn_bkup;
	}
	public void setIsdn_bkup(ISDNDetails isdn_bkup) {
		this.isdn_bkup = isdn_bkup;
	}

	/*public CustLanDetails getCust_lan() {
		return cust_lan;
	}
	public void setCust_lan(CustLanDetails cust_lan) {
		this.cust_lan = cust_lan;
	}*/

	public StandardDetails getStd_info() {
		return std_info;
	}
	public void setStd_info(StandardDetails std_info) {
		this.std_info = std_info;
	}

	public ReportingDetails getReporting_info() {
		return reporting_info;
	}
	public void setReporting_info(ReportingDetails reporting_info) {
		this.reporting_info = reporting_info;
	}

	public CustWanDetails getCust_wan() {
		return cust_wan;
	}
	public void setCust_wan(CustWanDetails cust_wan) {
		this.cust_wan = cust_wan;
	}

	public FinanceDetails getFinance_vertical() {
		return finance_vertical;
	}
	public void setFinance_vertical(FinanceDetails finance_vertical) {
		this.finance_vertical = finance_vertical;
	}

	public FrFDetails getFrf_16_info() {
		return frf_16_info;
	}
	public void setFrf_16_info(FrFDetails frf_16_info) {
		this.frf_16_info = frf_16_info;
	}

	

}
