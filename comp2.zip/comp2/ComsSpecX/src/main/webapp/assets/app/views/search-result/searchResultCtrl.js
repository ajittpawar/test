
(function () {

	comspecApp.controller('searchResultCtrl', ['$scope', 'searchService', '$state', function($scope, searchService, $state){
		$scope.resultData = searchService.getResult();

	}]);


})();