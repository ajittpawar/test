package com.bt.nga.exception;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * @author Sagar Chavan
 * @aim To throw custom exception for invalid request	
 * @created Nov 29, 2016 
 * @modified Nov 29, 2016
 * @modified_by Sagar Chavan
 * @description 
 */

@Component
@Scope("prototype")
public class InvalidRequestException extends RuntimeException {
    /**
	 * 
	 */
	private static final long serialVersionUID = -6198690819348647927L;
	private String msg;
    private String code;


	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public InvalidRequestException(String message, String code) {
		super(message);
		this.code=code;
        this.msg=message;
    	
         
    }
	public InvalidRequestException(String message) {
		super(message);		
        this.msg=message;
    }

   
}