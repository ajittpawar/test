package com.bt.nga.config.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;


/**
 * @author Sagar Chavan
 * @aim To provide cache control strategy	
 * @created Nov 29, 2016 
 * @modified Nov 29, 2016
 * @modified_by Sagar Chavan
 * @description Adds respoce header for each request with no cache header
 */

@Component
public class CacheControllInterceptor extends HandlerInterceptorAdapter{

	private final static Logger logger = Logger.getLogger(CacheControllInterceptor.class);
	
	//before the actual handler will be executed
	public boolean preHandle(HttpServletRequest request,
		HttpServletResponse response, Object handler)
	    throws Exception {
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Design & Development By", "Er. Sagar Chavan");
		response.setHeader("Pragma", "no-cache");
		logger.debug("Header set for Cache-Control");
		return true;
	}

}
