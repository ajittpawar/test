/**
 * 
 */
package com.bt.nga.entity;

import org.springframework.stereotype.Component;

/**
 * @author Sagar Chavan
 * @aim 	
 * @created Nov 29, 2016 
 * @modified Nov 29, 2016
 * @modified_by Sagar Chavan
 * @description 
 */
@Component
public class SampleModel {

	private String modelName;

	/**
	 * 
	 */
	
	/**
	 * 
	 */
	public SampleModel() {
		// TODO Auto-generated constructor stub
	}
	
	public SampleModel(String modelName) {
		this.modelName=modelName;
	}
	
	/**
	 * @return the modelName
	 */
	public String getModelName() {
		return modelName;
	}

	/**
	 * @param modelName the modelName to set
	 */
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	
}
