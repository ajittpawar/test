package com.bt.nga.jsonBean;

/**
 * @author Ajit Pawar
 *
 */
public class StandardDetails {

	 private String   field1;
	 private String   field2;
	 private String   field3;
	 private String   field4;
	 private String   field5;
	 private String   field6;
	 private String   field77;
	 private String   field78;
	 private String   field79;
	 private String   field80;
	 private String   mfr_ID;
	 private String   mfrTotalBW ;
	 private String  linkBW;
	 private String   intf_ID;
	 private String   pe_Intf;

	public StandardDetails() {
		// TODO Auto-generated constructor stub
	}

	public StandardDetails(String field1, String field2, String field3, String field4, String field5, String field6,
			String field77, String field78, String field79, String field80, String mfr_ID, String mfrTotalBW,
			String linkBW, String intf_ID, String pe_Intf) {
		super();
		this.field1 = field1;
		this.field2 = field2;
		this.field3 = field3;
		this.field4 = field4;
		this.field5 = field5;
		this.field6 = field6;
		this.field77 = field77;
		this.field78 = field78;
		this.field79 = field79;
		this.field80 = field80;
		this.mfr_ID = mfr_ID;
		this.mfrTotalBW = mfrTotalBW;
		this.linkBW = linkBW;
		this.intf_ID = intf_ID;
		this.pe_Intf = pe_Intf;
	}

	public String getField1() {
		return field1;
	}

	public void setField1(String field1) {
		this.field1 = field1;
	}

	public String getField2() {
		return field2;
	}

	public void setField2(String field2) {
		this.field2 = field2;
	}

	public String getField3() {
		return field3;
	}

	public void setField3(String field3) {
		this.field3 = field3;
	}

	public String getField4() {
		return field4;
	}

	public void setField4(String field4) {
		this.field4 = field4;
	}

	public String getField5() {
		return field5;
	}

	public void setField5(String field5) {
		this.field5 = field5;
	}

	public String getField6() {
		return field6;
	}

	public void setField6(String field6) {
		this.field6 = field6;
	}

	public String getField77() {
		return field77;
	}

	public void setField77(String field77) {
		this.field77 = field77;
	}

	public String getField78() {
		return field78;
	}

	public void setField78(String field78) {
		this.field78 = field78;
	}

	public String getField79() {
		return field79;
	}

	public void setField79(String field79) {
		this.field79 = field79;
	}

	public String getField80() {
		return field80;
	}

	public void setField80(String field80) {
		this.field80 = field80;
	}

	public String getMfr_ID() {
		return mfr_ID;
	}

	public void setMfr_ID(String mfr_ID) {
		this.mfr_ID = mfr_ID;
	}

	public String getMfrTotalBW() {
		return mfrTotalBW;
	}

	public void setMfrTotalBW(String mfrTotalBW) {
		this.mfrTotalBW = mfrTotalBW;
	}

	public String getLinkBW() {
		return linkBW;
	}

	public void setLinkBW(String linkBW) {
		this.linkBW = linkBW;
	}

	public String getIntf_ID() {
		return intf_ID;
	}

	public void setIntf_ID(String intf_ID) {
		this.intf_ID = intf_ID;
	}

	public String getPe_Intf() {
		return pe_Intf;
	}

	public void setPe_Intf(String pe_Intf) {
		this.pe_Intf = pe_Intf;
	}

}
