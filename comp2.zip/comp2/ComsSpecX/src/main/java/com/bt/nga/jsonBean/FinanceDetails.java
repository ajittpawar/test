/**
 * 
 */
package com.bt.nga.jsonBean;

/**
 * @author Ajit Pawar
 *
 */
public class FinanceDetails {

	private String   owner;
	private String   connType_extranet;
	private String   connType_enterprise;
	private String   services;
	private String   orderType;
	private String   ServiceName;
	private String   modifyType;

	public FinanceDetails() {
		// TODO Auto-generated constructor stub
	}

	public FinanceDetails(String owner, String connType_extranet, String connType_enterprise, String services,
			String orderType, String serviceName, String modifyType) {
		super();
		this.owner = owner;
		this.connType_extranet = connType_extranet;
		this.connType_enterprise = connType_enterprise;
		this.services = services;
		this.orderType = orderType;
		ServiceName = serviceName;
		this.modifyType = modifyType;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getConnType_extranet() {
		return connType_extranet;
	}

	public void setConnType_extranet(String connType_extranet) {
		this.connType_extranet = connType_extranet;
	}

	public String getConnType_enterprise() {
		return connType_enterprise;
	}

	public void setConnType_enterprise(String connType_enterprise) {
		this.connType_enterprise = connType_enterprise;
	}

	public String getServices() {
		return services;
	}

	public void setServices(String services) {
		this.services = services;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getServiceName() {
		return ServiceName;
	}

	public void setServiceName(String serviceName) {
		ServiceName = serviceName;
	}

	public String getModifyType() {
		return modifyType;
	}

	public void setModifyType(String modifyType) {
		this.modifyType = modifyType;
	}

}
