package com.bt.nga.config.property;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.stereotype.Service;

@Service
@PropertySources({
	@PropertySource("classpath:ComSpec/Properties/mail.properties")	

})

public class MailProperty {

	//Properties for mail server
	@Value("${mailServer}")
	private String mailServer;

	@Value("${from}")
	private String from;

	public String getMailServer() {
		return mailServer;
	}

	public String getFrom() {
		return from;
	}
}
