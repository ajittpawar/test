/**
 * 
 */
package com.bt.nga.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bt.nga.entity.SampleModel;

/**
 * @author Sagar Chavan
 * @aim Sample Service class	
 * @created Nov 29, 2016 
 * @modified Nov 29, 2016
 * @modified_by Sagar Chavan
 * @description Sample Service class with @bean initialized property
 */

@Service
public class SampleServiceImpl implements SampleService{
	
	private final static Logger logger = Logger.getLogger(SampleServiceImpl.class);
	
	@Autowired private SampleModel model;
	
	private String serviceName;

	/**
	 * @return the serviceName
	 */
	public String getServiceName() {
		return "Using Service: "+serviceName+", with Model :"+model.getModelName();
	}

	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		logger.info("Setting service name: "+serviceName);
		this.serviceName = serviceName;
	}
	
}
