/**
 * 
 */
package com.bt.nga.jsonBean;

import java.util.List;

/**
 * @author Ajit Pawar
 *
 */
public class OrderSearchResult {
	private int count;
	private List<OrderDetails> ordersList;
	
	public OrderSearchResult(){
		
	}
	
	public OrderSearchResult(int count, List<OrderDetails> ordersList){
		this.count = count;
		this.ordersList = ordersList;
	}

	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	public List<OrderDetails> getOrdersList() {
		return ordersList;
	}
	public void setOrdersList(List<OrderDetails> ordersList) {
		this.ordersList = ordersList;
	}
}
