package com.bt.nga.dao;


import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.bt.nga.entity.serviceno.ServiceNO;
import com.bt.nga.util.hibernate.HibernateUtil;


/**
 * ServiceNO DAO
 * @author 611221504
 *
 */
@Repository("serviceNumberDAO")
@EnableTransactionManagement
@Transactional
public class ServiceNoDAO {
	private final static Logger logger = Logger.getLogger(ServiceNoDAO.class);

	private SessionFactory sessionFactory=null;
	
	@Autowired
	private HibernateUtil serviceDAO;

	public List<ServiceNO> listServiceNO() {

		logger.info("In ListServiceNo method");
		Session session = serviceDAO.openSession();
		logger.debug("Session Object is:"+session);
		List<ServiceNO> serviceNOList=session.createCriteria(ServiceNO.class).list();
		return serviceNOList;

	}
	

	
	public void addServiceNo(ServiceNO serviceNO) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(serviceNO);
		logger.info("ServiceNo saved successfully, ServiceNO Details="+serviceNO);
	}

	

	
	public ServiceNO getServiceNObyID(int id) {
		Session session = this.sessionFactory.getCurrentSession();		
		ServiceNO p = (ServiceNO) session.load(ServiceNO.class, new Integer(id));
		logger.info("ServiceNO loaded successfully, ServiceNO details="+p);
		return p;
	}

	public void removeServiceNO(int id) {
		Session session = this.sessionFactory.getCurrentSession();
		ServiceNO p = (ServiceNO) session.load(ServiceNO.class, new Integer(id));
		if(null != p){
			session.delete(p);
		}
		logger.info("ServiceNO deleted successfully, ServiceNO details="+p);
	}

	public HibernateUtil getServiceDAO() {
		return serviceDAO;
	}

	public void setServiceDAO(HibernateUtil serviceDAO) {
		this.serviceDAO = serviceDAO;
	}

}
