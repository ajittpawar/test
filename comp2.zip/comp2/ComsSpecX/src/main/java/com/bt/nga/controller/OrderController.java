/**
 * 
 */
package com.bt.nga.controller;

import java.util.ArrayList;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bt.nga.jsonBean.OrderSearchResult;
import com.bt.nga.jsonBean.ServiceDetails;

/**
 * @author Sagar Chavan
 * @aim To provide REST API for orders	
 * @created Nov 30, 2016 
 * @modified Nov 30, 2016
 * @modified_by Sagar Chavan
 * @description 
 */

@RestController
public class OrderController {

	@RequestMapping(value="OrderDetails",method = RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public OrderSearchResult getOrderDetails(
			@RequestParam(value="cust_Name",required=false) String cust_Name,
			@RequestParam(value="order_Id",required=false) String order_Id,
			@RequestParam(value="cpe_id", required=false)ArrayList<String> cpe_id
			){

		if (!"".equals(order_Id) || null!= cust_Name && !"".equals(cust_Name) || null!= cust_Name) {

		}
		return new OrderSearchResult();
	}

	@RequestMapping(value="TechDetails",method = RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ServiceDetails getServiceDetails(
			@RequestParam(value="ServiceID",required=false) String serviceID
			){
		return new ServiceDetails();

	}
	
	@RequestMapping(value="TechDetails",method = RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
	public String postServiceDetails(
			@RequestBody ServiceDetails serviceDetails
			){
		return "Success";

	}
	
	
}
