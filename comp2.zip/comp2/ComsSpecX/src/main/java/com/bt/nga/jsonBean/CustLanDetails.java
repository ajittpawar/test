/**
 * 
 */
package com.bt.nga.jsonBean;

/**
 * @author Sagar Chavan
 * @aim 	
 * @created Dec 1, 2016 
 * @modified Dec 1, 2016
 * @modified_by Sagar Chavan
 * @description 
 */
public class CustLanDetails {
	
	private String LANInterface_1;
	private String LANIP_1;
	private String  VirtualIP_1;
	private String LANNet_2;
	private String LANWildcardMask_2;
	private String LANPort_3;
	private String LANMask_3;
	private String RoutingType_2;
	private String  LANNext_HopIP_1;
	private String  LANNext_HopIP_2;
	private String  LANNext_HopIP_3;
	private String  LANNext_HopIP_4;
	private String  LANNext_HopIP_5;
	private String  LAN_Helper2_1;
	private String LAN_Helper3_2;
	private String SNMP_Server_IP_1;
	private String SNMP_Server_Mask_2;
	private String  IPv6_1LANInterface;
	private String  IPv6_1LANWildcardMask;
	private String  LANPort_1;
	private String  LANMask_1;
	private String  LANInterface_2;
	private String  LANIP_2;
	private String VirtualIP_2;
	private String  LANNet_3;


	private String LANWildcardMask_3;
	private String NetworkIPs_1;
	private String  NetworkIPs_2;
	private String NetworkIPs_3;
	private String  NetworkIPs_4;
	private String  NetworkIPs_5;
	private String  LAN_Helper1_1;
	private String  LAN_Helper_2;
	private String  SNMP_Read_Access;
	private String  SNMP_Server_IP_2;
	private String  IPv6_1LANIP;
	private String  IPv6_1LAN_Helper_1;
	private String  LANNet_1;
	private String  LANWildcardMask_1;
	private String  LANPort_2;
	private String  LANMask_2;
	private String  LANInterface_3;
	private String  LANIP_3;
	private String  VirtualIP_3;
	private String  NetworkMask_1;
	private String  NetworkMask_2;
	private String  NetworkMask_3;
	private String  NetworkMask_4;
	private String  NetworkMask_5;
	private String  LAN_Helper1_2;
	private String  LAN_Helper3_1;
	private String  SNMP_Community;

	private String SNMP_Server_Mask_1;
	private String IPv6_1LANMask_Lengh;
	private String  IPv6_1LANSubNet;
	private String  IPv6_1LAN_Helper_2;













	public String getLANWildcardMask_3() {
		return LANWildcardMask_3;
	}
	public void setLANWildcardMask_3(String lANWildcardMask_3) {
		LANWildcardMask_3 = lANWildcardMask_3;
	}
	public String getNetworkIPs_1() {
		return NetworkIPs_1;
	}
	public void setNetworkIPs_1(String networkIPs_1) {
		NetworkIPs_1 = networkIPs_1;
	}
	public String getNetworkIPs_2() {
		return NetworkIPs_2;
	}
	public void setNetworkIPs_2(String networkIPs_2) {
		NetworkIPs_2 = networkIPs_2;
	}
	public String getNetworkIPs_3() {
		return NetworkIPs_3;
	}
	public void setNetworkIPs_3(String networkIPs_3) {
		NetworkIPs_3 = networkIPs_3;
	}
	public String getNetworkIPs_4() {
		return NetworkIPs_4;
	}
	public void setNetworkIPs_4(String networkIPs_4) {
		NetworkIPs_4 = networkIPs_4;
	}
	public String getNetworkIPs_5() {
		return NetworkIPs_5;
	}
	public void setNetworkIPs_5(String networkIPs_5) {
		NetworkIPs_5 = networkIPs_5;
	}
	public String getLAN_Helper1_1() {
		return LAN_Helper1_1;
	}
	public void setLAN_Helper1_1(String lAN_Helper1_1) {
		LAN_Helper1_1 = lAN_Helper1_1;
	}
	public String getLAN_Helper_2() {
		return LAN_Helper_2;
	}
	public void setLAN_Helper_2(String lAN_Helper_2) {
		LAN_Helper_2 = lAN_Helper_2;
	}
	public String getSNMP_Read_Access() {
		return SNMP_Read_Access;
	}
	public void setSNMP_Read_Access(String sNMP_Read_Access) {
		SNMP_Read_Access = sNMP_Read_Access;
	}
	public String getSNMP_Server_IP_2() {
		return SNMP_Server_IP_2;
	}
	public void setSNMP_Server_IP_2(String sNMP_Server_IP_2) {
		SNMP_Server_IP_2 = sNMP_Server_IP_2;
	}
	public String getIPv6_1LANIP() {
		return IPv6_1LANIP;
	}
	public void setIPv6_1LANIP(String iPv6_1LANIP) {
		IPv6_1LANIP = iPv6_1LANIP;
	}
	public String getIPv6_1LAN_Helper_1() {
		return IPv6_1LAN_Helper_1;
	}
	public void setIPv6_1LAN_Helper_1(String iPv6_1LAN_Helper_1) {
		IPv6_1LAN_Helper_1 = iPv6_1LAN_Helper_1;
	}
	public String getLANNet_1() {
		return LANNet_1;
	}
	public void setLANNet_1(String lANNet_1) {
		LANNet_1 = lANNet_1;
	}
	public String getLANWildcardMask_1() {
		return LANWildcardMask_1;
	}
	public void setLANWildcardMask_1(String lANWildcardMask_1) {
		LANWildcardMask_1 = lANWildcardMask_1;
	}
	public String getLANPort_2() {
		return LANPort_2;
	}
	public void setLANPort_2(String lANPort_2) {
		LANPort_2 = lANPort_2;
	}
	public String getLANMask_2() {
		return LANMask_2;
	}
	public void setLANMask_2(String lANMask_2) {
		LANMask_2 = lANMask_2;
	}
	public String getLANInterface_3() {
		return LANInterface_3;
	}
	public void setLANInterface_3(String lANInterface_3) {
		LANInterface_3 = lANInterface_3;
	}
	public String getLANIP_3() {
		return LANIP_3;
	}
	public void setLANIP_3(String lANIP_3) {
		LANIP_3 = lANIP_3;
	}
	public String getVirtualIP_3() {
		return VirtualIP_3;
	}
	public void setVirtualIP_3(String virtualIP_3) {
		VirtualIP_3 = virtualIP_3;
	}
	public String getNetworkMask_1() {
		return NetworkMask_1;
	}
	public void setNetworkMask_1(String networkMask_1) {
		NetworkMask_1 = networkMask_1;
	}
	public String getNetworkMask_2() {
		return NetworkMask_2;
	}
	public void setNetworkMask_2(String networkMask_2) {
		NetworkMask_2 = networkMask_2;
	}
	public String getNetworkMask_3() {
		return NetworkMask_3;
	}
	public void setNetworkMask_3(String networkMask_3) {
		NetworkMask_3 = networkMask_3;
	}
	public String getNetworkMask_4() {
		return NetworkMask_4;
	}
	public void setNetworkMask_4(String networkMask_4) {
		NetworkMask_4 = networkMask_4;
	}
	public String getNetworkMask_5() {
		return NetworkMask_5;
	}
	public void setNetworkMask_5(String networkMask_5) {
		NetworkMask_5 = networkMask_5;
	}
	public String getLAN_Helper1_2() {
		return LAN_Helper1_2;
	}
	public void setLAN_Helper1_2(String lAN_Helper1_2) {
		LAN_Helper1_2 = lAN_Helper1_2;
	}
	public String getLAN_Helper3_1() {
		return LAN_Helper3_1;
	}
	public void setLAN_Helper3_1(String lAN_Helper3_1) {
		LAN_Helper3_1 = lAN_Helper3_1;
	}
	public String getSNMP_Community() {
		return SNMP_Community;
	}
	public void setSNMP_Community(String sNMP_Community) {
		SNMP_Community = sNMP_Community;
	}
	public String getSNMP_Server_Mask_1() {
		return SNMP_Server_Mask_1;
	}
	public void setSNMP_Server_Mask_1(String sNMP_Server_Mask_1) {
		SNMP_Server_Mask_1 = sNMP_Server_Mask_1;
	}
	public String getIPv6_1LANMask_Lengh() {
		return IPv6_1LANMask_Lengh;
	}
	public void setIPv6_1LANMask_Lengh(String iPv6_1LANMask_Lengh) {
		IPv6_1LANMask_Lengh = iPv6_1LANMask_Lengh;
	}
	public String getIPv6_1LANSubNet() {
		return IPv6_1LANSubNet;
	}
	public void setIPv6_1LANSubNet(String iPv6_1LANSubNet) {
		IPv6_1LANSubNet = iPv6_1LANSubNet;
	}
	public String getIPv6_1LAN_Helper_2() {
		return IPv6_1LAN_Helper_2;
	}
	public void setIPv6_1LAN_Helper_2(String iPv6_1LAN_Helper_2) {
		IPv6_1LAN_Helper_2 = iPv6_1LAN_Helper_2;
	}
	public String getLANInterface_1() {
		return LANInterface_1;
	}
	public void setLANInterface_1(String lANInterface_1) {
		LANInterface_1 = lANInterface_1;
	}
	public String getLANIP_1() {
		return LANIP_1;
	}
	public void setLANIP_1(String lANIP_1) {
		LANIP_1 = lANIP_1;
	}
	public String getVirtualIP_1() {
		return VirtualIP_1;
	}
	public void setVirtualIP_1(String virtualIP_1) {
		VirtualIP_1 = virtualIP_1;
	}
	public String getLANNet_2() {
		return LANNet_2;
	}
	public void setLANNet_2(String lANNet_2) {
		LANNet_2 = lANNet_2;
	}
	public String getLANWildcardMask_2() {
		return LANWildcardMask_2;
	}
	public void setLANWildcardMask_2(String lANWildcardMask_2) {
		LANWildcardMask_2 = lANWildcardMask_2;
	}
	public String getLANPort_3() {
		return LANPort_3;
	}
	public void setLANPort_3(String lANPort_3) {
		LANPort_3 = lANPort_3;
	}
	public String getLANMask_3() {
		return LANMask_3;
	}
	public void setLANMask_3(String lANMask_3) {
		LANMask_3 = lANMask_3;
	}
	public String getRoutingType_2() {
		return RoutingType_2;
	}
	public void setRoutingType_2(String routingType_2) {
		RoutingType_2 = routingType_2;
	}
	public String getLANNext_HopIP_1() {
		return LANNext_HopIP_1;
	}
	public void setLANNext_HopIP_1(String lANNext_HopIP_1) {
		LANNext_HopIP_1 = lANNext_HopIP_1;
	}
	public String getLANNext_HopIP_2() {
		return LANNext_HopIP_2;
	}
	public void setLANNext_HopIP_2(String lANNext_HopIP_2) {
		LANNext_HopIP_2 = lANNext_HopIP_2;
	}
	public String getLANNext_HopIP_3() {
		return LANNext_HopIP_3;
	}
	public void setLANNext_HopIP_3(String lANNext_HopIP_3) {
		LANNext_HopIP_3 = lANNext_HopIP_3;
	}
	public String getLANNext_HopIP_4() {
		return LANNext_HopIP_4;
	}
	public void setLANNext_HopIP_4(String lANNext_HopIP_4) {
		LANNext_HopIP_4 = lANNext_HopIP_4;
	}
	public String getLANNext_HopIP_5() {
		return LANNext_HopIP_5;
	}
	public void setLANNext_HopIP_5(String lANNext_HopIP_5) {
		LANNext_HopIP_5 = lANNext_HopIP_5;
	}
	public String getLAN_Helper2_1() {
		return LAN_Helper2_1;
	}
	public void setLAN_Helper2_1(String lAN_Helper2_1) {
		LAN_Helper2_1 = lAN_Helper2_1;
	}
	public String getLAN_Helper3_2() {
		return LAN_Helper3_2;
	}
	public void setLAN_Helper3_2(String lAN_Helper3_2) {
		LAN_Helper3_2 = lAN_Helper3_2;
	}
	public String getSNMP_Server_IP_1() {
		return SNMP_Server_IP_1;
	}
	public void setSNMP_Server_IP_1(String sNMP_Server_IP_1) {
		SNMP_Server_IP_1 = sNMP_Server_IP_1;
	}
	public String getSNMP_Server_Mask_2() {
		return SNMP_Server_Mask_2;
	}
	public void setSNMP_Server_Mask_2(String sNMP_Server_Mask_2) {
		SNMP_Server_Mask_2 = sNMP_Server_Mask_2;
	}
	public String getIPv6_1LANInterface() {
		return IPv6_1LANInterface;
	}
	public void setIPv6_1LANInterface(String iPv6_1LANInterface) {
		IPv6_1LANInterface = iPv6_1LANInterface;
	}
	public String getIPv6_1LANWildcardMask() {
		return IPv6_1LANWildcardMask;
	}
	public void setIPv6_1LANWildcardMask(String iPv6_1LANWildcardMask) {
		IPv6_1LANWildcardMask = iPv6_1LANWildcardMask;
	}
	public String getLANPort_1() {
		return LANPort_1;
	}
	public void setLANPort_1(String lANPort_1) {
		LANPort_1 = lANPort_1;
	}
	public String getLANMask_1() {
		return LANMask_1;
	}
	public void setLANMask_1(String lANMask_1) {
		LANMask_1 = lANMask_1;
	}
	public String getLANInterface_2() {
		return LANInterface_2;
	}
	public void setLANInterface_2(String lANInterface_2) {
		LANInterface_2 = lANInterface_2;
	}
	public String getLANIP_2() {
		return LANIP_2;
	}
	public void setLANIP_2(String lANIP_2) {
		LANIP_2 = lANIP_2;
	}
	public String getVirtualIP_2() {
		return VirtualIP_2;
	}
	public void setVirtualIP_2(String virtualIP_2) {
		VirtualIP_2 = virtualIP_2;
	}
	public String getLANNet_3() {
		return LANNet_3;
	}
	public void setLANNet_3(String lANNet_3) {
		LANNet_3 = lANNet_3;
	}

}
