/**
 * 
 */
package com.bt.nga.jsonBean;

/**
 * @author Ajit Pawar
 *
 */
public class PEDetails {

	 private String interFace;
	 private String klm;
	 private String timeSlots;
	 private String pe;
	 private String partner_IP;
	 private String router_Type;
	 private String port_adaptor;
	 private String port;
	 private String slot;
	 private String access_Speed;
	 private String port_Speed;
	 private String pe_Type;
	 private String resilience;
	 private String routing_Type;
	 private String vpn_Name;
	 private String loopback_200;
	 private String service_Role;
	 private String pe_Vpi;
	 private String pe_Vci;
	 private String pe_Dlci_phone;
	 private String vlan;
	 private String gpop_Id_email;
	 private String gpop_add;
	 private String  ipV6_loopback;
	 private String ip_Version;
	 private String vpn_Id;
	 private String vpn_Index;
	 private String connectivity_mode;
	 private String ipv4_max_Prefix;
	 private String  ipv6_max_Prefix;
	 private String switch_Node;
	 private String gateWay;

	public PEDetails() {
		// TODO Auto-generated constructor stub
	}

	public PEDetails(String interFace, String klm, String timeSlots, String pe, String partner_IP, String router_Type,
			String port_adaptor, String port, String slot, String access_Speed, String port_Speed, String pe_Type,
			String resilience, String routing_Type, String vpn_Name, String loopback_200, String service_Role,
			String pe_Vpi, String pe_Vci, String pe_Dlci_phone, String vlan, String gpop_Id_email, String gpop_add,
			String ipV6_loopback, String ip_Version, String vpn_Id, String vpn_Index, String connectivity_mode,
			String ipv4_max_Prefix, String ipv6_max_Prefix, String switch_Node, String gateWay) {
		super();
		this.interFace = interFace;
		this.klm = klm;
		this.timeSlots = timeSlots;
		this.pe = pe;
		this.partner_IP = partner_IP;
		this.router_Type = router_Type;
		this.port_adaptor = port_adaptor;
		this.port = port;
		this.slot = slot;
		this.access_Speed = access_Speed;
		this.port_Speed = port_Speed;
		this.pe_Type = pe_Type;
		this.resilience = resilience;
		this.routing_Type = routing_Type;
		this.vpn_Name = vpn_Name;
		this.loopback_200 = loopback_200;
		this.service_Role = service_Role;
		this.pe_Vpi = pe_Vpi;
		this.pe_Vci = pe_Vci;
		this.pe_Dlci_phone = pe_Dlci_phone;
		this.vlan = vlan;
		this.gpop_Id_email = gpop_Id_email;
		this.gpop_add = gpop_add;
		this.ipV6_loopback = ipV6_loopback;
		this.ip_Version = ip_Version;
		this.vpn_Id = vpn_Id;
		this.vpn_Index = vpn_Index;
		this.connectivity_mode = connectivity_mode;
		this.ipv4_max_Prefix = ipv4_max_Prefix;
		this.ipv6_max_Prefix = ipv6_max_Prefix;
		this.switch_Node = switch_Node;
		this.gateWay = gateWay;
	}

	public String getInterFace() {
		return interFace;
	}

	public void setInterFace(String interFace) {
		this.interFace = interFace;
	}

	public String getKlm() {
		return klm;
	}

	public void setKlm(String klm) {
		this.klm = klm;
	}

	public String getTimeSlots() {
		return timeSlots;
	}

	public void setTimeSlots(String timeSlots) {
		this.timeSlots = timeSlots;
	}

	public String getPe() {
		return pe;
	}

	public void setPe(String pe) {
		this.pe = pe;
	}

	public String getPartner_IP() {
		return partner_IP;
	}

	public void setPartner_IP(String partner_IP) {
		this.partner_IP = partner_IP;
	}

	public String getRouter_Type() {
		return router_Type;
	}

	public void setRouter_Type(String router_Type) {
		this.router_Type = router_Type;
	}

	public String getPort_adaptor() {
		return port_adaptor;
	}

	public void setPort_adaptor(String port_adaptor) {
		this.port_adaptor = port_adaptor;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getSlot() {
		return slot;
	}

	public void setSlot(String slot) {
		this.slot = slot;
	}

	public String getAccess_Speed() {
		return access_Speed;
	}

	public void setAccess_Speed(String access_Speed) {
		this.access_Speed = access_Speed;
	}

	public String getPort_Speed() {
		return port_Speed;
	}

	public void setPort_Speed(String port_Speed) {
		this.port_Speed = port_Speed;
	}

	public String getPe_Type() {
		return pe_Type;
	}

	public void setPe_Type(String pe_Type) {
		this.pe_Type = pe_Type;
	}

	public String getResilience() {
		return resilience;
	}

	public void setResilience(String resilience) {
		this.resilience = resilience;
	}

	public String getRouting_Type() {
		return routing_Type;
	}

	public void setRouting_Type(String routing_Type) {
		this.routing_Type = routing_Type;
	}

	public String getVpn_Name() {
		return vpn_Name;
	}

	public void setVpn_Name(String vpn_Name) {
		this.vpn_Name = vpn_Name;
	}

	public String getLoopback_200() {
		return loopback_200;
	}

	public void setLoopback_200(String loopback_200) {
		this.loopback_200 = loopback_200;
	}

	public String getService_Role() {
		return service_Role;
	}

	public void setService_Role(String service_Role) {
		this.service_Role = service_Role;
	}

	public String getPe_Vpi() {
		return pe_Vpi;
	}

	public void setPe_Vpi(String pe_Vpi) {
		this.pe_Vpi = pe_Vpi;
	}

	public String getPe_Vci() {
		return pe_Vci;
	}

	public void setPe_Vci(String pe_Vci) {
		this.pe_Vci = pe_Vci;
	}

	public String getPe_Dlci_phone() {
		return pe_Dlci_phone;
	}

	public void setPe_Dlci_phone(String pe_Dlci_phone) {
		this.pe_Dlci_phone = pe_Dlci_phone;
	}

	public String getVlan() {
		return vlan;
	}

	public void setVlan(String vlan) {
		this.vlan = vlan;
	}

	public String getGpop_Id_email() {
		return gpop_Id_email;
	}

	public void setGpop_Id_email(String gpop_Id_email) {
		this.gpop_Id_email = gpop_Id_email;
	}

	public String getGpop_add() {
		return gpop_add;
	}

	public void setGpop_add(String gpop_add) {
		this.gpop_add = gpop_add;
	}

	public String getIpV6_loopback() {
		return ipV6_loopback;
	}

	public void setIpV6_loopback(String ipV6_loopback) {
		this.ipV6_loopback = ipV6_loopback;
	}

	public String getIp_Version() {
		return ip_Version;
	}

	public void setIp_Version(String ip_Version) {
		this.ip_Version = ip_Version;
	}

	public String getVpn_Id() {
		return vpn_Id;
	}

	public void setVpn_Id(String vpn_Id) {
		this.vpn_Id = vpn_Id;
	}

	public String getVpn_Index() {
		return vpn_Index;
	}

	public void setVpn_Index(String vpn_Index) {
		this.vpn_Index = vpn_Index;
	}

	public String getConnectivity_mode() {
		return connectivity_mode;
	}

	public void setConnectivity_mode(String connectivity_mode) {
		this.connectivity_mode = connectivity_mode;
	}

	public String getIpv4_max_Prefix() {
		return ipv4_max_Prefix;
	}

	public void setIpv4_max_Prefix(String ipv4_max_Prefix) {
		this.ipv4_max_Prefix = ipv4_max_Prefix;
	}

	public String getIpv6_max_Prefix() {
		return ipv6_max_Prefix;
	}

	public void setIpv6_max_Prefix(String ipv6_max_Prefix) {
		this.ipv6_max_Prefix = ipv6_max_Prefix;
	}

	public String getSwitch_Node() {
		return switch_Node;
	}

	public void setSwitch_Node(String switch_Node) {
		this.switch_Node = switch_Node;
	}

	public String getGateWay() {
		return gateWay;
	}

	public void setGateWay(String gateWay) {
		this.gateWay = gateWay;
	}

}
