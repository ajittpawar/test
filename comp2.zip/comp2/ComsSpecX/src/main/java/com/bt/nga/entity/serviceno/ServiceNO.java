package com.bt.nga.entity.serviceno;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="SERVICE_NO")
public class ServiceNO {

	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	
	@Column(name="SELLid")
	private String sell_id;

	@Column(name="PROD_CUST_ID")
	private String prod_cust_id;
	

	@Column(name="PROD_CUST_NAME")
	private String prod_cust_name;
	

	@Column(name="PROD_CUST_FR_NAME")
	private String prod_cust_fr_name;
	

	@Column(name="ORDER_SITE_ID")
	private String order_site_id;

	@Column(name="PROD_SITE_ID")
	private String prod_site_id;

	@Column(name="CLASSIC_ORDER_NO")
	private String classic_order_no;

	@Column(name="CLASSIC_ORDER_TYPE")
	private String classic_order_type;

	@Column(name="INSERT_DATE")
	private String insert_date;

	@Column(name="CLASSIC_IMPORT")
	private String classic_import;

	@Column(name="PPR_IMPORT")
	private String ppr_import;
	
	@Column(name="LOOPBACK_10")
	private String loopback_10;

	@Column(name="PE_NAME")
	private String pe_name;

	@Column(name="PE_PORT")
	private String pe_port;
	
	@Column(name="VPN_NAME")
	private String vpn_name;

	@Column(name="Final_Host_Name")
	private String final_host_name;

	@Column(name="SERVICE_NO")
	private String service_no;
	
	
	@Column(name="CPEID")
	private String cpeid;
	
	@Column(name="SITE_CITY")
	private String site_city;
	
	@Column(name="SITE_COUNTRY")
	private String site_country;
	
	@Column(name="OLD_ORDER_NO")
	private String old_order_no;
	
	@Column(name="LINK_ORDER_NO")
	private String link_order_no;
	
	@Column(name="CONN_CLASS")
	private String conn_class;
	
	@Column(name="ORDER_STATE")
	private String order_state;
	
	@Column(name="TIMESTAMP")
	private Number timestamp;
	
	@Column(name="CUS_SERVICE_TYPE")
	private String cus_service_type;
	
	@Column(name="CT_OPTION")
	private String ct_option;
	
	@Column(name="CONFIG_TEMP1")
	private String config_temp1;
	
	
	@Column(name="CONFIG_TEMP2")
	private String config_temp2;

	@Column(name="CONFIG_TEMP3")
	private String config_temp3;
	
	@Column(name="CONFIG_TEMP4")
	private String config_temp4;
	
	@Column(name="CONFIG_TEMP5")
	private String config_temp5;
	
	@Column(name="CONFIG_TEMP6")
	private String config_temp6;
	
	@Column(name="CONFIG_TEMP7")
	private String config_temp7;
	
	@Column(name="CONFIG_TEMP8")
	private String config_temp8;
	
	@Column(name="CONFIG_TEMP9")
	private String config_temp9;
	
	@Column(name="CONFIG_TEMP10")
	private String config_temp10;
	
	
	@Column(name="SERVICE_TYPE")
	private String service_type;
	
	@Column(name="NETWORK_TYPE")
	private String network_type;
	
	@Column(name="ACC_TYPE")
	private String acc_type;
	
	@Column(name="PROD_TYPE")
	private String prod_type;
	
	@Column(name="STATUS_BTN_0")
	private String status_btn_0;
	
	@Column(name="STATUS_BTN_1")
	private String status_btn_1;
	
	@Column(name="STATUS_BTN_2")
	private String status_btn_2;
	
	@Column(name="STATUS_BTN_3")
	private String status_btn_3;
	
	@Column(name="STATUS_BTN_4")
	private String status_btn_4;
	
	@Column(name="TimeStamp_BTN_0")
	private String timestamp_btn_0;

	@Column(name="TimeStamp_BTN_1")
	private Number timestamp_btn_1;

	@Column(name="TimeStamp_BTN_2")
	private Number timestamp_btn_2;

	@Column(name="TimeStamp_BTN_3")
	private Number timestamp_btn_3;

	@Column(name="TimeStamp_BTN_4")
	private Number timestamp_btn_4;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSell_id() {
		return sell_id;
	}

	public void setSell_id(String sell_id) {
		this.sell_id = sell_id;
	}

	public String getProd_cust_id() {
		return prod_cust_id;
	}

	public void setProd_cust_id(String prod_cust_id) {
		this.prod_cust_id = prod_cust_id;
	}

	public String getProd_cust_name() {
		return prod_cust_name;
	}

	public void setProd_cust_name(String prod_cust_name) {
		this.prod_cust_name = prod_cust_name;
	}

	public String getProd_cust_fr_name() {
		return prod_cust_fr_name;
	}

	public void setProd_cust_fr_name(String prod_cust_fr_name) {
		this.prod_cust_fr_name = prod_cust_fr_name;
	}

	public String getOrder_site_id() {
		return order_site_id;
	}

	public void setOrder_site_id(String order_site_id) {
		this.order_site_id = order_site_id;
	}

	public String getProd_site_id() {
		return prod_site_id;
	}

	public void setProd_site_id(String prod_site_id) {
		this.prod_site_id = prod_site_id;
	}

	public String getClassic_order_no() {
		return classic_order_no;
	}

	public void setClassic_order_no(String classic_order_no) {
		this.classic_order_no = classic_order_no;
	}

	public String getClassic_order_type() {
		return classic_order_type;
	}

	public void setClassic_order_type(String classic_order_type) {
		this.classic_order_type = classic_order_type;
	}

	public String getInsert_date() {
		return insert_date;
	}

	public void setInsert_date(String insert_date) {
		this.insert_date = insert_date;
	}

	public String getClassic_import() {
		return classic_import;
	}

	public void setClassic_import(String classic_import) {
		this.classic_import = classic_import;
	}

	public String getPpr_import() {
		return ppr_import;
	}

	public void setPpr_import(String ppr_import) {
		this.ppr_import = ppr_import;
	}

	public String getLoopback_10() {
		return loopback_10;
	}

	public void setLoopback_10(String loopback_10) {
		this.loopback_10 = loopback_10;
	}

	public String getPe_name() {
		return pe_name;
	}

	public void setPe_name(String pe_name) {
		this.pe_name = pe_name;
	}

	public String getPe_port() {
		return pe_port;
	}

	public void setPe_port(String pe_port) {
		this.pe_port = pe_port;
	}

	public String getVpn_name() {
		return vpn_name;
	}

	public void setVpn_name(String vpn_name) {
		this.vpn_name = vpn_name;
	}

	public String getFinal_host_name() {
		return final_host_name;
	}

	public void setFinal_host_name(String final_host_name) {
		this.final_host_name = final_host_name;
	}

	public String getService_no() {
		return service_no;
	}

	public void setService_no(String service_no) {
		this.service_no = service_no;
	}

	public String getCpeid() {
		return cpeid;
	}

	public void setCpeid(String cpeid) {
		this.cpeid = cpeid;
	}

	public String getSite_city() {
		return site_city;
	}

	public void setSite_city(String site_city) {
		this.site_city = site_city;
	}

	public String getSite_country() {
		return site_country;
	}

	public void setSite_country(String site_country) {
		this.site_country = site_country;
	}

	public String getOld_order_no() {
		return old_order_no;
	}

	public void setOld_order_no(String old_order_no) {
		this.old_order_no = old_order_no;
	}

	public String getLink_order_no() {
		return link_order_no;
	}

	public void setLink_order_no(String link_order_no) {
		this.link_order_no = link_order_no;
	}

	public String getConn_class() {
		return conn_class;
	}

	public void setConn_class(String conn_class) {
		this.conn_class = conn_class;
	}

	public String getOrder_state() {
		return order_state;
	}

	public void setOrder_state(String order_state) {
		this.order_state = order_state;
	}

	public Number getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Number timestamp) {
		this.timestamp = timestamp;
	}

	public String getCus_service_type() {
		return cus_service_type;
	}

	public void setCus_service_type(String cus_service_type) {
		this.cus_service_type = cus_service_type;
	}

	public String getCt_option() {
		return ct_option;
	}

	public void setCt_option(String ct_option) {
		this.ct_option = ct_option;
	}

	public String getConfig_temp1() {
		return config_temp1;
	}

	public void setConfig_temp1(String config_temp1) {
		this.config_temp1 = config_temp1;
	}

	public String getConfig_temp2() {
		return config_temp2;
	}

	public void setConfig_temp2(String config_temp2) {
		this.config_temp2 = config_temp2;
	}

	public String getConfig_temp3() {
		return config_temp3;
	}

	public void setConfig_temp3(String config_temp3) {
		this.config_temp3 = config_temp3;
	}

	public String getConfig_temp4() {
		return config_temp4;
	}

	public void setConfig_temp4(String config_temp4) {
		this.config_temp4 = config_temp4;
	}

	public String getConfig_temp5() {
		return config_temp5;
	}

	public void setConfig_temp5(String config_temp5) {
		this.config_temp5 = config_temp5;
	}

	public String getConfig_temp6() {
		return config_temp6;
	}

	public void setConfig_temp6(String config_temp6) {
		this.config_temp6 = config_temp6;
	}

	public String getConfig_temp7() {
		return config_temp7;
	}

	public void setConfig_temp7(String config_temp7) {
		this.config_temp7 = config_temp7;
	}

	public String getConfig_temp8() {
		return config_temp8;
	}

	public void setConfig_temp8(String config_temp8) {
		this.config_temp8 = config_temp8;
	}

	public String getConfig_temp9() {
		return config_temp9;
	}

	public void setConfig_temp9(String config_temp9) {
		this.config_temp9 = config_temp9;
	}

	public String getConfig_temp10() {
		return config_temp10;
	}

	public void setConfig_temp10(String config_temp10) {
		this.config_temp10 = config_temp10;
	}

	public String getService_type() {
		return service_type;
	}

	public void setService_type(String service_type) {
		this.service_type = service_type;
	}

	public String getNetwork_type() {
		return network_type;
	}

	public void setNetwork_type(String network_type) {
		this.network_type = network_type;
	}

	public String getAcc_type() {
		return acc_type;
	}

	public void setAcc_type(String acc_type) {
		this.acc_type = acc_type;
	}

	public String getProd_type() {
		return prod_type;
	}

	public void setProd_type(String prod_type) {
		this.prod_type = prod_type;
	}

	public String getStatus_btn_0() {
		return status_btn_0;
	}

	public void setStatus_btn_0(String status_btn_0) {
		this.status_btn_0 = status_btn_0;
	}

	public String getStatus_btn_1() {
		return status_btn_1;
	}

	public void setStatus_btn_1(String status_btn_1) {
		this.status_btn_1 = status_btn_1;
	}

	public String getStatus_btn_2() {
		return status_btn_2;
	}

	public void setStatus_btn_2(String status_btn_2) {
		this.status_btn_2 = status_btn_2;
	}

	public String getStatus_btn_3() {
		return status_btn_3;
	}

	public void setStatus_btn_3(String status_btn_3) {
		this.status_btn_3 = status_btn_3;
	}

	public String getStatus_btn_4() {
		return status_btn_4;
	}

	public void setStatus_btn_4(String status_btn_4) {
		this.status_btn_4 = status_btn_4;
	}

	public String getTimestamp_btn_0() {
		return timestamp_btn_0;
	}

	public void setTimestamp_btn_0(String timestamp_btn_0) {
		this.timestamp_btn_0 = timestamp_btn_0;
	}

	public Number getTimestamp_btn_1() {
		return timestamp_btn_1;
	}

	public void setTimestamp_btn_1(Number timestamp_btn_1) {
		this.timestamp_btn_1 = timestamp_btn_1;
	}

	public Number getTimestamp_btn_2() {
		return timestamp_btn_2;
	}

	public void setTimestamp_btn_2(Number timestamp_btn_2) {
		this.timestamp_btn_2 = timestamp_btn_2;
	}

	public Number getTimestamp_btn_3() {
		return timestamp_btn_3;
	}

	public void setTimestamp_btn_3(Number timestamp_btn_3) {
		this.timestamp_btn_3 = timestamp_btn_3;
	}

	public Number getTimestamp_btn_4() {
		return timestamp_btn_4;
	}

	public void setTimestamp_btn_4(Number timestamp_btn_4) {
		this.timestamp_btn_4 = timestamp_btn_4;
	}
	
}
