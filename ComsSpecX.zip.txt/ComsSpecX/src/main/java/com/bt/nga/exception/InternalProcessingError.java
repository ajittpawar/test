package com.bt.nga.exception;

/**
 * @author Sagar Chavan
 * @aim To generate error response if exception occurs	
 * @created Nov 30, 2016 
 * @modified Nov 30, 2016
 * @modified_by Sagar Chavan
 * @description This exception should be thrown for internal request process error
 */


@SuppressWarnings("serial")
public class InternalProcessingError extends RuntimeException {
    private String msg;
    private String code;


	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public InternalProcessingError(String message) {
		super(message);		
        this.msg=message;
    	
         
    }

   
}