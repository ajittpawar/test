/**
 * 
 */
package com.bt.nga.jsonBean;

import java.util.List;

/**
 * @author Ajit Pawar
 *
 */
public class OrderRequestCriteria {
	private String order_id;
	private String cust_name;
	private List<String> cpe_ids;
	
	public OrderRequestCriteria(){
		
	}
	
	public OrderRequestCriteria(String order_id, String cust_name, List<String> cpe_ids){
		this.order_id = order_id;
		this.cust_name = cust_name;
		this.cpe_ids = cpe_ids;
		
	}
	
	public String getOrder_id() {
		return order_id;
	}
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}
	
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	
	public List<String> getCpe_ids() {
		return cpe_ids;
	}
	public void setCpe_ids(List<String> cpe_ids) {
		this.cpe_ids = cpe_ids;
	}
}
