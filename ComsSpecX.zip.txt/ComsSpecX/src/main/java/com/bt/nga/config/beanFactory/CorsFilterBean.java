/**
 * 
 */
package com.bt.nga.config.beanFactory;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * @author Sagar Chavan
 * @aim Provied Global CORS configuration	
 * @created Nov 29, 2016 
 * @modified Nov 29, 2016
 * @modified_by Sagar Chavan
 * @description An alternative to fine-grained annotation-based configuration
 *  This is similar to using a Filter based solution, but can be declared within 
 *  Spring MVC and combined with fine-grained @CrossOrigin configuration. 
 *  By default all origins and GET, HEAD and POST methods are allowed
 */

@Configuration
public class CorsFilterBean {

	private final static Logger logger = Logger.getLogger(CorsFilterBean.class);
	
	
	/**
	 * Creates CORS origin
	 * @return WebMvcConfigurer
	 */
	
	@Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurerAdapter() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
            	logger.debug("Adding CORS configuration to CorsRegistry");
                registry.addMapping("/").allowedOrigins("http://localhost:9000");
            }
        };
    }
}
