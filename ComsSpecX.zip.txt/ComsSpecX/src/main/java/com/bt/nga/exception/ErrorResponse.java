/**
 * 
 */
package com.bt.nga.exception;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * @author Sagar Chavan
 * @aim To generate error response if exception occurs	
 * @created Nov 30, 2016 
 * @modified Nov 30, 2016
 * @modified_by Sagar Chavan
 * @description 
 */

@Component
@Scope("prototype")
public class ErrorResponse {
	private String code;

	private String message;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
}
