/**
 * 
 */
package com.bt.nga.jsonBean;

/**
 * @author Ajit Pawar
 *
 */
public class Customer {
	private String cust_name;
	private String cust_id;
	private String order_no;
	private String loopback;
	private String pe_name;
	private String pe_port;
	private String hostname;
	private String city;
	private String order_state;
	
	public Customer() {
	}
	
	public Customer(String cust_name, String cust_id, String order_no, String loopback, String pe_name, String pe_port, String hostname, String city, String order_state) {
		this.cust_name = cust_name;
		this.cust_id = cust_id;
		this.order_no = order_no;
		this.loopback = loopback;
		this.pe_name = pe_name;
		this.pe_port = pe_port;
		this.hostname = hostname;
		this.city = city;
		this.order_state = order_state;
			
	}
	
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	
	public String getCust_id() {
		return cust_id;
	}
	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}
	
	public String getOrder_no() {
		return order_no;
	}
	public void setOrder_no(String order_no) {
		this.order_no = order_no;
	}
	
	public String getLoopback() {
		return loopback;
	}
	public void setLoopback(String loopback) {
		this.loopback = loopback;
	}
	
	public String getPe_name() {
		return pe_name;
	}
	public void setPe_name(String pe_name) {
		this.pe_name = pe_name;
	}
	
	public String getPe_port() {
		return pe_port;
	}
	public void setPe_port(String pe_port) {
		this.pe_port = pe_port;
	}
	public String getHostname() {
		return hostname;
	}
	
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public String getCity() {
		return city;
	}
	
	public void setCity(String city) {
		this.city = city;
	}
	public String getOrder_state() {
		return order_state;
	}
	
	public void setOrder_state(String order_state) {
		this.order_state = order_state;
	}
}
