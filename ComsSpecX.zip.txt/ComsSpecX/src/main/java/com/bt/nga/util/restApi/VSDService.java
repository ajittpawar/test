package com.bt.nga.util.restApi;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import com.bt.nga.jsonBean.AccessDetails;
import com.bt.nga.jsonBean.COSDetails;
import com.bt.nga.jsonBean.CPEDetails;
import com.bt.nga.jsonBean.CustWanDetails;
import com.bt.nga.jsonBean.FinanceDetails;
import com.bt.nga.jsonBean.FrFDetails;
import com.bt.nga.jsonBean.GeneralDetails;
import com.bt.nga.jsonBean.ISDNDetails;
import com.bt.nga.jsonBean.PEDetails;
import com.bt.nga.jsonBean.ReportingDetails;
import com.bt.nga.jsonBean.ServiceDetails;
import com.bt.nga.jsonBean.StandardDetails;
import com.bt.nga.jsonBean.TechnicalDetails;
import com.bt.nga.xmlBean.Attribute;
import com.bt.nga.xmlBean.Object;
import com.bt.nga.xmlBean.Operation;
import com.bt.nga.xmlBean.OrderForm;
import com.bt.nga.xmlBean.Properties;

public class VSDService {

	public String provideBasicConfig(ServiceDetails details){


		TechnicalDetails technicalDetails=details .getTechnicalData();

		String service_no=technicalDetails.getService_no();
		GeneralDetails general_info=technicalDetails.getGeneral_info();
		PEDetails pe_info=technicalDetails.getPe_info();
		AccessDetails access_info=technicalDetails.getAccess_info();
		CPEDetails cpe_info=technicalDetails.getCpe_info();
		COSDetails cos_info=technicalDetails.getCos_info();
		ISDNDetails isdn_bkup=technicalDetails.getIsdn_bkup();
		//private CustLanDetails cust_lan;
		StandardDetails std_info=technicalDetails.getStd_info();
		ReportingDetails reporting_info=technicalDetails.getReporting_info();
		CustWanDetails cust_wan=technicalDetails.getCust_wan();
		FinanceDetails finance_vertical=technicalDetails.getFinance_vertical();
		FrFDetails frf_16_info=technicalDetails.getFrf_16_info();

		Operation operation=new Operation();
		operation.setName("EnhancedCreatePhysicalCircuit");

		Attribute attribute=new Attribute();
		attribute.setName("caller");
		attribute.setContent("<![CDATA[vserve]]>");

		Attribute attribute1=new Attribute();
		attribute1.setName("MA_atmInterfaceNumber");
		attribute1.setContent(service_no);

		Attribute attribute2=new Attribute();
		attribute2.setContent(cpe_info.getiPv6_Mgmt_IP());
		attribute2.setName("MA_celoopbackaddress");

		Attribute attribute3=new Attribute();
		attribute3.setContent(cpe_info.getHostname_Extn());
		attribute3.setName("MA_hostname");

		Attribute attribute4=new Attribute();
		attribute4.setContent(pe_info.getPartner_IP());
		attribute4.setName("MA_peWanInterfaceAddress");

		Attribute attribute5=new Attribute();
		attribute5.setContent(cust_wan.getPpp_passwd());
		attribute5.setName("MA_pppPassword");

		Attribute attribute6=new Attribute();
		attribute6.setContent(cust_wan.getPpp_host());
		attribute6.setName("MA_pppUsername");

		Attribute attribute7=new Attribute();
		attribute7.setContent(pe_info.getPe_Vci());
		attribute7.setName("MA_vci");

		Attribute attribute8=new Attribute();
		attribute8.setContent(pe_info.getPe_Vpi());
		attribute8.setName("MA_vpi");

		Attribute attribute9=new Attribute();
		attribute9.setContent(pe_info.getPort());
		attribute9.setName("MA_wanInterfaceDescription1");

		Attribute attribute10=new Attribute();
		attribute10.setContent(service_no);
		attribute10.setName("MA_atmInterfaceNumber");

		Attribute attribute11=new Attribute();
		attribute11.setContent(cpe_info.getiPv6_Mgmt_IP());
		attribute11.setName("MA_celoopbackaddress");

		Attribute attribute12=new Attribute();
		attribute12.setContent(cpe_info.getHostname_Extn());
		attribute12.setName("MA_hostname");

		Attribute attribute13=new Attribute();
		attribute13.setContent(pe_info.getPartner_IP());
		attribute13.setName("MA_peWanInterfaceAddress");

		Attribute attribute14=new Attribute();
		attribute14.setContent(cust_wan.getPpp_passwd());
		attribute14.setName("MA_pppPassword");

		Attribute attribute15=new Attribute();
		attribute15.setContent(cust_wan.getPpp_host());
		attribute15.setName("MA_pppUsername");

		Attribute attribute16=new Attribute();
		attribute16.setContent(pe_info.getPe_Vci());
		attribute16.setName("MA_vci");

		Attribute attribute17=new Attribute();
		attribute17.setContent(pe_info.getPe_Vpi());
		attribute17.setName("MA_vpi");

		Attribute attribute18=new Attribute();
		attribute18.setContent(pe_info.getPort());
		attribute18.setName("MA_wanInterfaceDescription");

		Attribute attribute19=new Attribute();
		attribute19.setContent("<![CDATA[Service:IGNITE MPLS,CID:18102016,SR:4649,CE:CE-NOIPS-PSG1K-DSL-46,Speed:1024,on 18-10-2016 ,by User:omsadmin]]>");
		attribute19.setName("MA_description");

		Attribute attribute20=new Attribute();
		attribute20.setContent("<![CDATA[power2bt-rtt#]]>");
		attribute20.setName("MA_linePassword");

		Attribute attribute21=new Attribute();
		attribute21.setContent("<![CDATA[power2bt-rtt#]]>");
		attribute21.setName("MA_enableSecret");

		Attribute attribute22=new Attribute();
		attribute22.setContent("<![CDATA[1024]]>");
		attribute22.setName("MA_bandwidth");

		Attribute attribute23=new Attribute();
		attribute23.setContent("<![CDATA[1024]]>");
		attribute23.setName("MA_peakRate");

		Attribute attribute24=new Attribute();
		attribute24.setContent("<![CDATA[1024]]>");
		attribute24.setName("MA_sustainedRate");

		Attribute attribute25=new Attribute();
		attribute25.setContent("<![CDATA[PPPoA]]>");
		attribute25.setName("OA_btgsDslEncapsulation");

		Attribute attribute26=new Attribute();
		attribute26.setContent("<![CDATA[Y]]>");
		attribute26.setName("OA_btgsSdslCheck");

		Attribute attribute27=new Attribute();
		attribute27.setContent(pe_info.getAccess_Speed());
		attribute27.setName("OA_peBandwidth");

		Attribute attribute28=new Attribute();
		attribute28.setContent(pe_info.getRouter_Type());
		attribute28.setName("MA_routerModel");

		Attribute attribute29=new Attribute();
		attribute29.setContent("<![CDATA[A]]>");
		attribute29.setName("OA_dslAnnex");


		Attribute[] attributes=new Attribute[30];
		attributes[0]=attribute;
		attributes[1]=attribute1;
		attributes[2]=attribute1;
		attributes[3]=attribute1;
		attributes[4]=attribute1;
		attributes[5]=attribute1;
		attributes[6]=attribute1;
		attributes[7]=attribute1;
		attributes[8]=attribute1;
		attributes[9]=attribute1;
		attributes[10]=attribute1;
		attributes[11]=attribute1;
		attributes[12]=attribute1;
		attributes[13]=attribute1;
		attributes[14]=attribute1;
		attributes[15]=attribute1;
		attributes[16]=attribute1;
		attributes[17]=attribute1;
		attributes[18]=attribute1;
		attributes[19]=attribute1;
		attributes[20]=attribute1;
		attributes[21]=attribute1;
		attributes[22]=attribute1;
		attributes[23]=attribute1;
		attributes[24]=attribute1;
		attributes[25]=attribute1;
		attributes[26]=attribute1;
		attributes[27]=attribute1;
		attributes[28]=attribute1;
		attributes[29]=attribute1;

		Properties properties=new Properties();
		properties.typeId="Mpls/properties/Release46";

		Object object=new Object();
		object.setOperation(operation);
		object.setAttribute(attributes);

		OrderForm orderForm=new OrderForm();
		orderForm.setProperties(properties);
		orderForm.setObject(object);

		String basicConfig=getResStringFrmVSD(orderForm);	


		return basicConfig;

	}

	private String getResStringFrmVSD(OrderForm orderForm){

		RestTemplate restTemplate = new RestTemplate();
		//VSD url
		String url="http://10.54.9.198:61000/RTEJMSClientService/rte/trigger";

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_XML);
		HttpEntity<OrderForm> request = new HttpEntity<>(orderForm, headers);
		final ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
		String	responseString=response.getBody().toString();

		return responseString;
	}


}
