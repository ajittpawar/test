package com.bt.nga.jsonBean;

/**
 * @author Ajit Pawar
 *
 */
public class COSDetails {

	 private String info_rate;
	 private String af1_Cipr;
	 private String af1_Mipr;
	 private String af2_Cipr;
	 private String af2_Mipr;
	 private String af3_Cipr;
	 private String af3_Mipr;
	 private String af4_Cipr;
	 private String af4_Mipr;
	 private String ClassDEMIPR;
	 private String ef_CIPR ;
	 private String mgmt_CIPR ;
	 private String mgmt_MIPR;
	 private String model;
	 private String level;
	 private String remarking;
	 private String multimedia_Af;
	 private String assignment;
	 private String class_type;
	 private String engg_Required;

	public COSDetails() {
		// TODO Auto-generated constructor stub
	}

	public COSDetails(String info_rate, String af1_Cipr, String af1_Mipr, String af2_Cipr, String af2_Mipr,
			String af3_Cipr, String af3_Mipr, String af4_Cipr, String af4_Mipr, String classDEMIPR, String ef_CIPR,
			String mgmt_CIPR, String mgmt_MIPR, String model, String level, String remarking, String multimedia_Af,
			String assignment, String class_type, String engg_Required) {
		super();
		this.info_rate = info_rate;
		this.af1_Cipr = af1_Cipr;
		this.af1_Mipr = af1_Mipr;
		this.af2_Cipr = af2_Cipr;
		this.af2_Mipr = af2_Mipr;
		this.af3_Cipr = af3_Cipr;
		this.af3_Mipr = af3_Mipr;
		this.af4_Cipr = af4_Cipr;
		this.af4_Mipr = af4_Mipr;
		ClassDEMIPR = classDEMIPR;
		this.ef_CIPR = ef_CIPR;
		this.mgmt_CIPR = mgmt_CIPR;
		this.mgmt_MIPR = mgmt_MIPR;
		this.model = model;
		this.level = level;
		this.remarking = remarking;
		this.multimedia_Af = multimedia_Af;
		this.assignment = assignment;
		this.class_type = class_type;
		this.engg_Required = engg_Required;
	}

	public String getInfo_rate() {
		return info_rate;
	}

	public void setInfo_rate(String info_rate) {
		this.info_rate = info_rate;
	}

	public String getAf1_Cipr() {
		return af1_Cipr;
	}

	public void setAf1_Cipr(String af1_Cipr) {
		this.af1_Cipr = af1_Cipr;
	}

	public String getAf1_Mipr() {
		return af1_Mipr;
	}

	public void setAf1_Mipr(String af1_Mipr) {
		this.af1_Mipr = af1_Mipr;
	}

	public String getAf2_Cipr() {
		return af2_Cipr;
	}

	public void setAf2_Cipr(String af2_Cipr) {
		this.af2_Cipr = af2_Cipr;
	}

	public String getAf2_Mipr() {
		return af2_Mipr;
	}

	public void setAf2_Mipr(String af2_Mipr) {
		this.af2_Mipr = af2_Mipr;
	}

	public String getAf3_Cipr() {
		return af3_Cipr;
	}

	public void setAf3_Cipr(String af3_Cipr) {
		this.af3_Cipr = af3_Cipr;
	}

	public String getAf3_Mipr() {
		return af3_Mipr;
	}

	public void setAf3_Mipr(String af3_Mipr) {
		this.af3_Mipr = af3_Mipr;
	}

	public String getAf4_Cipr() {
		return af4_Cipr;
	}

	public void setAf4_Cipr(String af4_Cipr) {
		this.af4_Cipr = af4_Cipr;
	}

	public String getAf4_Mipr() {
		return af4_Mipr;
	}

	public void setAf4_Mipr(String af4_Mipr) {
		this.af4_Mipr = af4_Mipr;
	}

	public String getClassDEMIPR() {
		return ClassDEMIPR;
	}

	public void setClassDEMIPR(String classDEMIPR) {
		ClassDEMIPR = classDEMIPR;
	}

	public String getEf_CIPR() {
		return ef_CIPR;
	}

	public void setEf_CIPR(String ef_CIPR) {
		this.ef_CIPR = ef_CIPR;
	}

	public String getMgmt_CIPR() {
		return mgmt_CIPR;
	}

	public void setMgmt_CIPR(String mgmt_CIPR) {
		this.mgmt_CIPR = mgmt_CIPR;
	}

	public String getMgmt_MIPR() {
		return mgmt_MIPR;
	}

	public void setMgmt_MIPR(String mgmt_MIPR) {
		this.mgmt_MIPR = mgmt_MIPR;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getRemarking() {
		return remarking;
	}

	public void setRemarking(String remarking) {
		this.remarking = remarking;
	}

	public String getMultimedia_Af() {
		return multimedia_Af;
	}

	public void setMultimedia_Af(String multimedia_Af) {
		this.multimedia_Af = multimedia_Af;
	}

	public String getAssignment() {
		return assignment;
	}

	public void setAssignment(String assignment) {
		this.assignment = assignment;
	}

	public String getClass_type() {
		return class_type;
	}

	public void setClass_type(String class_type) {
		this.class_type = class_type;
	}

	public String getEngg_Required() {
		return engg_Required;
	}

	public void setEngg_Required(String engg_Required) {
		this.engg_Required = engg_Required;
	}

}
