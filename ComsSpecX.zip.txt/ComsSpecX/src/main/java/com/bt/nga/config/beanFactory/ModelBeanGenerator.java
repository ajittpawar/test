/**
 * 
 */
package com.bt.nga.config.beanFactory;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.bt.nga.entity.SampleModel;

/**
 * @author Sagar Chavan
 * @aim Provide sample modele exampel	
 * @created Nov 30, 2016 
 * @modified Nov 30, 2016
 * @modified_by Sagar Chavan
 * @description 
 */
@Configuration
public class ModelBeanGenerator {

	@Bean
	@Scope("prototype")
	public SampleModel sampleModel(){
		SampleModel model = new SampleModel("Sample Model 1");
		return model;
	}
	
}
