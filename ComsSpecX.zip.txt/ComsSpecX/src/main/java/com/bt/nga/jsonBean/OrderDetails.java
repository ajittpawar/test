/**
 * 
 */
package com.bt.nga.jsonBean;

import java.util.List;

/**
 * @author Ajit Pawar
 *
 */
public class OrderDetails {
	private String order_id;
	private Customer cust_details;
	private List<String> service_Id_list;
	
	public OrderDetails(){
		
	}
	
	public OrderDetails(String order_id, Customer cust_details, List<String> service_Id_list){
		this.order_id = order_id;
		this.cust_details = cust_details;
		this.setService_Id_list(service_Id_list);
		
	}
	
	public String getOrder_id() {
		return order_id;
	}
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}
	
	public Customer getCust_details() {
		return cust_details;
	}
	public void setCust_details(Customer cust_details) {
		this.cust_details = cust_details;
	}

	/**
	 * @return the service_Id_list
	 */
	public List<String> getService_Id_list() {
		return service_Id_list;
	}

	/**
	 * @param service_Id_list the service_Id_list to set
	 */
	public void setService_Id_list(List<String> service_Id_list) {
		this.service_Id_list = service_Id_list;
	}
	
}
