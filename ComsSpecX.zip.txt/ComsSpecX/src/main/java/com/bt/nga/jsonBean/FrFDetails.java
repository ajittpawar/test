/**
 * 
 */
package com.bt.nga.jsonBean;

/**
 * @author Ajit Pawar
 *
 */
public class FrFDetails {

	private String   Id;
	private String   pe_Name;
	private String   pe_PortNo;
	private String   pe_SlotNo;
	private String   port_Speed;
	private String   ports_No;

	public FrFDetails() {
		// TODO Auto-generated constructor stub
	}

	public FrFDetails(String id, String pe_Name, String pe_PortNo, String pe_SlotNo, String port_Speed,
			String ports_No) {
		super();
		Id = id;
		this.pe_Name = pe_Name;
		this.pe_PortNo = pe_PortNo;
		this.pe_SlotNo = pe_SlotNo;
		this.port_Speed = port_Speed;
		this.ports_No = ports_No;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getPe_Name() {
		return pe_Name;
	}

	public void setPe_Name(String pe_Name) {
		this.pe_Name = pe_Name;
	}

	public String getPe_PortNo() {
		return pe_PortNo;
	}

	public void setPe_PortNo(String pe_PortNo) {
		this.pe_PortNo = pe_PortNo;
	}

	public String getPe_SlotNo() {
		return pe_SlotNo;
	}

	public void setPe_SlotNo(String pe_SlotNo) {
		this.pe_SlotNo = pe_SlotNo;
	}

	public String getPort_Speed() {
		return port_Speed;
	}

	public void setPort_Speed(String port_Speed) {
		this.port_Speed = port_Speed;
	}

	public String getPorts_No() {
		return ports_No;
	}

	public void setPorts_No(String ports_No) {
		this.ports_No = ports_No;
	}

}
