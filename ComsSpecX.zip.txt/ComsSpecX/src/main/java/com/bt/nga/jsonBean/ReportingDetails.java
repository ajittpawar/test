/**
 * 
 */
package com.bt.nga.jsonBean;

/**
 * @author Ajit Pawar
 *
 */
public class ReportingDetails {

	 private String   date;
	 private String   notes;
	 private String   order_no;
	 private String   record_Id;
	 private String   activationFlag;

	public ReportingDetails() {
		// TODO Auto-generated constructor stub
	}

	public ReportingDetails(String date, String notes, String order_no, String record_Id, String activationFlag) {
		super();
		this.date = date;
		this.notes = notes;
		this.order_no = order_no;
		this.record_Id = record_Id;
		this.activationFlag = activationFlag;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getOrder_no() {
		return order_no;
	}

	public void setOrder_no(String order_no) {
		this.order_no = order_no;
	}

	public String getRecord_Id() {
		return record_Id;
	}

	public void setRecord_Id(String record_Id) {
		this.record_Id = record_Id;
	}

	public String getActivationFlag() {
		return activationFlag;
	}

	public void setActivationFlag(String activationFlag) {
		this.activationFlag = activationFlag;
	}

}
