package com.bt.nga.controller;


import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
//import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bt.nga.config.property.MailProperty;
import com.bt.nga.entity.SampleModel;
import com.bt.nga.service.SampleService;


/**
 * @author Sagar Chavan
 * @aim To show initial running environment of ComSpec	
 * @created Nov 29, 2016 
 * @modified Nov 29, 2016
 * @modified_by Sagar Chavan
 * @description 
 */

@RestController
public class InitController {
	private final static Logger logger = Logger.getLogger(InitController.class);
	
	
	@Autowired private SampleService sampleService;
	@Autowired private MailProperty mailProps;
	
	//@CrossOrigin(origins = "http://localhost:8090")
	
	@RequestMapping(value = "/", method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
	public String init( ) {
		
		logger.info("Displaying intial ComSpec environment");
		String initMsg="Welcome to ComSpec1.8JEE"
				+ "\n"
				+ "Mail Props: "+mailProps.getFrom()
				+"\n"
				+ "Sample Service Name:"+sampleService.getServiceName()
				+
				"";
		return initMsg;
	}
	@RequestMapping(value = "/init1", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String init1( ) {
		
		logger.info("Displaying intial ComSpec environment");
		String initMsg="Welcome to ComSpec"
				+ "\n"
				+ "Mail Props: "+mailProps.getFrom()
				+"\n"
				+ "Sample Service Name:"+sampleService.getServiceName()
				+
				"";
		return initMsg;
	}
	
	@RequestMapping(value = "/testmodel", method = RequestMethod.GET, headers = "Accept=application/json",produces = MediaType.APPLICATION_JSON_VALUE)
	public SampleModel modelTest( ) {
		logger.info("Displaying Sample model");
		 
		SampleModel model = new SampleModel("test model");
		
		return model;
	}
}
