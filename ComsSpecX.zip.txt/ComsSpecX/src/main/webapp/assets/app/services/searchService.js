/**
 *  Search Service
 */

(function(){
    'use strict';
    
    angular
            .module('MyApp')
            .factory('searchService', searchService);
    
    searchService.$inject = [ "$http"];
    
    function searchService($http){
    	var resultData = {};
        return {
			searchOrder:function (search){
            return $http.get('OrderDetails?orderId='+search.orderId+'&customerText='+search.customerText);
			},
			setResult: function(data){
				resultData = data;
			},
			getResult: function(){
				return resultData;
			}
            
        };
    }
    
})();