/**
 * Login Service
 * @returns {undefined}
 */

 (function(){
    'use strict';
    
    angular
        .module('MyApp')
        .factory('loginService', loginService);

        loginService.$inject = [ "$localStorage", "$sessionStorage", "$http"];

        function loginService($localStorage, $sessionStorage, $http){
            return {
                login : function(loginObj){
                    if(loginObj.remember){
                        $localStorage.userName = loginObj.userName;
                        $localStorage.password = loginObj.password;
                    }else{
                        delete $localStorage.userName;
                        delete $localStorage.password;
                    }
                    $sessionStorage.userName = loginObj.userName;
                    //return true;
                    return $http.post('authUser', {username:loginObj.userName, password:loginObj.password});
                },
                getRemember : function(){
                    if($localStorage.userName){
                        return {
                        	userName:$localStorage.userName,
                            password:$localStorage.password,
                            remember:true
                        };
                    }else{
                        return {};
                    }
                },
                isLogedin : function(){
                    if($sessionStorage.userName)
                        return true;
                    else
                        return false;
                },
                logout : function(){
                    console.log('logout...');
                    delete $sessionStorage.userName;
                    return true;
                },
                getUserName : function(){
                    if($sessionStorage.userName)
                        return $sessionStorage.userName;
                    else
                        return "Guest";
                },
                setUserName : function(userName){
                    $sessionStorage.userName = userName;
                    
                }
            };
        };

})();

