/**
 * Search Controller
 */

(function () {
    'use strict';

    angular
            .module('MyApp')
            .controller('searchByBulkFeedCtrl', searchCtrl);

    searchCtrl.$inject = ['$scope', 'searchService', '$state', '$filter', 'toastr', '$window'];
    
    function searchCtrl($scope, searchService, $state, $filter, toastr, $window) {

        /** ***** Date Picker ****** */
        $scope.today = function () {
            $scope.date = new Date();
        };
        $scope.today();
        
        $scope.clear = function () {
            $scope.date = null;
        };
        $scope.selection="";
        $scope.opened = false;

        var date=new Date();
        date.setMonth(date.getMonth() - 1);
        $scope.dateOptions = {
            // dateDisabled: disabled,
            formatYear: 'yy',
            maxDate: new Date(),
            minDate: date,
            startingDay: 1
        };

        // Disable weekend selection
        function disabled(data) {
            var date = data.date,
                    mode = data.mode;
            return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
        }

        $scope.formats = ['dd-MM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
        $scope.format = $scope.formats[0];
        // $scope.flowid_1=$scope.flowid_1?undefined:$("#flowid_1").val();
        $scope.loading = false;
        $scope.emailOrZip = "email";


        $scope.searchBulkIds= function(date,flowid, emailOrZip){
         $scope.user.email='';
         $scope.loading = true;
         $scope.date = date;
         $scope.flowid_1 = flowid;
         $scope.flowIds = [];
         $scope.emailOrZip = emailOrZip;
            var date = $filter('date')(date, $scope.format);
            searchService.bulkSearch({date:date, flowId:flowid}).then(function (response) {
               
                $scope.loading = false;
                $scope.selection = 'flowid';
                $scope.flowIds = response.data.result.data;
                $scope.flowIdResponse = response.data;
            }).catch(function (response) {
                $scope.loading = false;
                toastr.error('Error :' + response.data.message);
                console.log(response);
            });
        }
        $scope.searhformInvalid=false;
        $scope.checkdata=function(data){
        	if(angular.isDefined(data )){
        		var count = (data.match(/,/g) || []).length;
            	if(count>29){
            		$scope.searhformInvalid=true;
            	}else{
            		$scope.searhformInvalid=false;
            	}
        	}
        	
        }
        
        function validateEmail(email) {
            var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
            return re.test(email);
        }

        $scope.invalidEmailIds = false;
        $scope.emailValidation = function(){
        	var str = $scope.user.email;
        	$scope.invalidEmailIds = false;   
        	$scope.emailinvalid = false;
        	$scope.commacheck = false;
        	if(str === null || str === undefined){
        		return;
        	}
        	
        	if(str.indexOf(",")>-1){
        		$scope.commacheck = true;
        		return;
        	}

                var emails = str.split(';');
                
                if(emails.length > 5){
                	$scope.emailLimitOverflow = true;
                	$scope.invalidEmailIds = true;
                	return;
                }

                var invalidEmails = [];
                
                angular.forEach(emails, function(email){
                	$scope.emailLimitOverflow = false;
                	if(!validateEmail(email.trim())){
                		invalidEmails.push(email);
                		
                		
                	}
                });
                return invalidEmails;
        }

      
        $scope.user = {};
        
        $scope.sendMail= function(){
        	// $scope.email_id;
        	$scope.invalidemailids = $scope.emailValidation();
        	if($scope.invalidemailids.length > 0){
        		$scope.emailinvalid = true;
        		return;
        	}
        		
        	searchService.sendMail($scope.user.email,{ result:$scope.flowIdResponse,flowId:$scope.flowid_1}).then(function (response) {
            	console.log(response);
            	toastr.success(response.data.message);
               
            }).catch(function (response) {
                $scope.loading = false;
                toastr.error('Error :' + response.data.message);
                console.log(response);
            });
        		
        	
        };
        
        $scope.zipDownload = function(){
        	
        	searchService.zipDownload($scope.flowIdResponse).then(function (response) {
                
        		console.log(response);
        		
        		/**var a = document.createElement('a');
        		var blob = new Blob([response.data], {'type':"application/arraybuffer"});
        		a.href = URL.createObjectURL(blob);
        		a.download = "filename.zip";
        		a.click();**/
        		
        		var zipinput = new Blob([response.data],{ type: 'application/zip' }); 
        		window.navigator.msSaveOrOpenBlob(zipinput, 'report.zip'); 

                
            }).catch(function (response) {
                $scope.loading = false;
                toastr.error('Error :' + response.status.message);
                console.log(response);
            });
        };
        
        
        $scope.selectFlowId = function (href) {
            $scope.loading = true;
            searchService.selectAnyId(href).then(function (response) {
                $scope.loading = false;
                $scope.selection = 'xml';
                $scope.xmlIds = response.data.result.data;
            }).catch(function (response) {
                $scope.loading = false;
                toastr.error('Error :' + response.statusText);
                console.log(response);
            });
        };

        $scope.showPage = function (value) {
            $scope.selection = value;
        };

        // $scope.xmlIds = searchService.getXmlIds();

        $scope.selectXmlId = function (href) {
            $window.open(href, "XML Document", "width=600,scrollbars=yes,resizable=yes");
            searchService.selectAnyId(href).then(function (response) {
                // var myWindow = $window.open("", "XML Document",
				// "width=600,height=400");
                // myWindow.document.write(response.data);
                // $scope.loading = false;
                // $scope.selection = 'xml';
                // $scope.xmlIds = response.data.result.data;
            }).catch(function (response) {
                // $scope.loading = false;
                toastr.error('Error :' + response.statusText);
                console.log(response);
            });

        };


    }
    
})();