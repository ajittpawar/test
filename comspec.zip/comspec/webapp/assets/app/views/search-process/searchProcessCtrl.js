
(function () {
	'use strict';

	angular.module('MyApp').controller('searchProcessCtrl', searchProcessCtrl);
	searchProcessCtrl.$inject = ['$scope', 'searchService', '$state', '$filter', 'toastr', '$window'];

	function searchProcessCtrl($scope, searchService, $state, $filter, toastr, $window) {
		
		function loadSearchProcessServices() {
			searchService.getSeacrhVisibility({}).then(function (response) {
				$scope.searchVisibility = response.data.technicalData;

				console.log("resposne  :", $scope.searchProcess);
			},function(error) {


			});
			
			searchService.getOrderDetails({}).then(function (response) {
				$scope.searchProcess = response.data.technicalData;

				console.log("resposne  :", $scope.searchProcess);
			},function(error) {


			});
			
		}
		
		loadSearchProcessServices();
		
	}

})();