/**
 * Search Controller
 */

(function () {
    'use strict';

    angular
            .module('MyApp')
            .controller('searchCtrl', searchCtrl);

    searchCtrl.$inject = ['$scope', 'searchService', '$state', '$filter', 'toastr', '$window'];
    
    function searchCtrl($scope, searchService, $state, $filter, toastr, $window) {

        $scope.loading = false;
		console.log("come here");
		
		
		$scope.search = {};
		
		$scope.searchFn = function () {
			
			 searchService.searchOrder($scope.search).then(function (response) {
                
                $scope.loading = false;
				$scope.searchResponse = response.data;
				searchService.setResult(response.data);
				$state.go('searchResult');
                
				
            }).catch(function (response) {
                $scope.loading = false;
                toastr.error('Error :' + response.data.message);
                console.log(response);
            });

			
			
		}
    
        
    }
    
})();