/**
 * Search Controller
 */

(function () {
    'use strict';

    angular
            .module('MyApp')
            .controller('searchResultCtrl', searchResultCtrl);

    searchResultCtrl.$inject = ['$scope', 'searchService', '$state', '$filter', 'toastr', '$window'];
    
    function searchResultCtrl($scope, searchService, $state, $filter, toastr, $window) {

       $scope.resultData = searchService.getResult();
		
		
			
		
    
        
    }
    
})();